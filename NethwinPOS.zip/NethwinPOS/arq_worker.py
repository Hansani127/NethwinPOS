from arq.connections import RedisSettings

from app.config import settings
from app.database import init_db
from app.models.order import Order
from app.services.email_service import send_order_confirmation, send_email_task


class WorkerSettings:
    redis_settings = RedisSettings.from_dsn(settings.REDIS_URL)

    functions = [
        "process_order_after_payment",
        "send_email_task_worker",
    ]


async def process_order_after_payment(ctx: dict, order_id: str) -> None:
    await init_db()
    order = await Order.get(order_id)
    if order:
        await send_order_confirmation(order)


async def send_email_task_worker(ctx: dict, to: str, subject: str, html: str) -> None:
    await send_email_task(to, subject, html)
