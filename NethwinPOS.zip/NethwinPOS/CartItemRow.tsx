import { Link } from '../../utils/router-compat'

import { Minus, Plus, Trash2 } from 'lucide-react'
import type { CartItem } from '../../types'
import { cleanImageUrl } from '../../utils/imageUrl'
import { formatCurrency } from '../../utils/formatCurrency'
import Button from '../common/Button'
import { useCart } from '../../hooks/useCart'

interface CartItemRowProps {
  item: CartItem
}

export default function CartItemRow({ item }: CartItemRowProps) {
  const { updateCartQuantity, removeFromCart } = useCart()
  const lineTotal = +(item.priceAtPurchase * item.quantity).toFixed(2)
  const isBook = item.book.productType === 'book' || !!item.book.author
  const productType = isBook ? 'book' : 'stationery'
  const coverSrc = cleanImageUrl(item.book.coverImage || item.book.thumbnail || (item.book as any).image, item.book.title, productType)

  return (
    <div className="flex gap-4 py-5 border-b border-cream-200 last:border-b-0">
      <Link href={`/books/${item.bookId}`}
        className="flex-shrink-0 w-24 h-36 sm:w-28 sm:h-40 rounded-xl overflow-hidden bg-cream-100 border border-cream-200"
      >
        <img
          src={coverSrc}
          alt={item.book.title}
          className="w-full h-full object-cover"
          onError={(e) => {
            ;(e.currentTarget as HTMLImageElement).src = cleanImageUrl('', item.book.title, productType)
          }}
        />
      </Link>

      <div className="flex-1 flex flex-col sm:flex-row sm:items-center gap-4 min-w-0">
        <div className="flex-1 min-w-0">
          <h4 className="font-serif text-lg font-semibold text-primary-950 line-clamp-1">
            <Link href={`/books/${item.bookId}`} className="hover:text-primary-700 transition-colors">
              {item.book.title}
            </Link>
          </h4>
          <p className="text-sm text-primary-800/70 mt-0.5 line-clamp-1">
            by {item.book.author}
          </p>
          <p className="text-sm font-semibold text-primary-700 mt-2">
            {formatCurrency(item.priceAtPurchase)} <span className="text-primary-800/50 font-normal">each</span>
          </p>
        </div>

        <div className="flex items-center justify-between sm:flex-col sm:items-end gap-4">
          <div className="flex items-center border border-cream-300 rounded-xl overflow-hidden bg-white">
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9 rounded-none"
              onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
              aria-label="Decrease quantity"
              disabled={item.quantity <= 1}
            >
              <Minus className="w-3.5 h-3.5" />
            </Button>
            <span className="min-w-[2.5rem] text-center text-sm font-semibold text-primary-900 tabular-nums">
              {item.quantity}
            </span>
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9 rounded-none"
              onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
              aria-label="Increase quantity"
              disabled={item.quantity >= item.book.stock}
            >
              <Plus className="w-3.5 h-3.5" />
            </Button>
          </div>

          <div className="flex items-center gap-3">
            <span className="font-serif text-lg font-bold text-primary-800 tabular-nums">
              {formatCurrency(lineTotal)}
            </span>
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9 text-red-500 hover:bg-red-50 hover:text-red-600"
              onClick={() => removeFromCart(item.id)}
              aria-label="Remove item"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
