from fastapi import APIRouter, UploadFile, File, HTTPException, Depends

from app.core.security import current_superuser
from app.models.user import User
from app.schemas import UploadResponse
from app.services import upload_image as cloudinary_upload_image

router = APIRouter(prefix="/upload", tags=["upload"])


@router.post("/image", response_model=UploadResponse)
async def upload_image(
    file: UploadFile = File(...),
    _: User = Depends(current_superuser),
):
    if not file.content_type or not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="File must be an image")

    contents = await file.read()
    if len(contents) > 10 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="Image too large (max 10MB)")

    try:
        secure_url, public_id = await cloudinary_upload_image(contents)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")

    return UploadResponse(secure_url=secure_url, public_id=public_id)
