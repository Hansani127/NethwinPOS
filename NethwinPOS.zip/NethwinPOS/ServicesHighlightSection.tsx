"use client";

import { Printer, BookOpenCheck, ShieldCheck, Sparkles } from 'lucide-react'
import Badge from '../common/Badge'

const SERVICES = [
  {
    icon: <Printer className="w-7 h-7 text-primary-700" />,
    title: 'Precision Book Printing',
    description: 'Specialized in manufacturing high-quality fiction novels, textbook series, and custom leatherbound volumes with gold gilt detailing.',
  },
  {
    icon: <BookOpenCheck className="w-7 h-7 text-primary-700" />,
    title: 'Stationery Manufacturing',
    description: 'High-volume production of premium school notebooks, drawing books, customized academic diaries, and institutional stationery.',
  },
  {
    icon: <ShieldCheck className="w-7 h-7 text-primary-700" />,
    title: 'Commercial Printing & Binding',
    description: 'Expert finishing services including perfect binding, saddle stitching, catalog printing, brochures, and bespoke brand packaging.',
  },
]

export default function ServicesHighlightSection() {
  return (
    <section className="py-20 sm:py-24 bg-cream-200/50 relative overflow-hidden border-y border-cream-200">
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%2300a651' fill-opacity='0.15' fill-rule='evenodd'%3E%3Ccircle cx='3' cy='3' r='1.5'/%3E%3C/g%3E%3C/svg%3E\")",
        }}
      />
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-14 max-w-2xl mx-auto">
          <Badge variant="primary" size="md" className="mb-4 uppercase tracking-wider bg-primary-100 text-primary-800 border-primary-200">
            <Sparkles className="w-3 h-3 mr-1 text-primary-700" />
            Nethwin Press
          </Badge>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-primary-950">
            State-of-the-Art <span className="italic text-primary-700">Printing Services</span>
          </h2>
          <p className="mt-4 text-primary-800/70 leading-relaxed">
            Combining master craftsmanship with advanced technology to deliver premium publications, office supplies, and school stationery.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {SERVICES.map((s, i) => (
            <div
              key={i}
              className="bg-white rounded-2xl border border-cream-300 p-8 shadow-sm transition-all duration-300 hover:shadow-xl hover:shadow-primary-950/5 hover:-translate-y-1 hover:border-primary-200"
            >
              <div className="w-14 h-14 rounded-2xl bg-primary-50 border border-primary-100 flex items-center justify-center mb-6 transition-transform duration-300 hover:scale-105">
                {s.icon}
              </div>
              <h3 className="font-serif text-xl font-semibold text-primary-950 mb-3">
                {s.title}
              </h3>
              <p className="text-sm text-primary-800/65 leading-relaxed">
                {s.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
