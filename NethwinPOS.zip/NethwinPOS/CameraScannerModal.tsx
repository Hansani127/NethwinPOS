import { useEffect, useRef, useState } from 'react'
import { Html5Qrcode } from 'html5-qrcode'
import { Camera, X } from 'lucide-react'
import Modal from '../common/Modal'
import Button from '../common/Button'

interface CameraScannerModalProps {
  isOpen: boolean
  onClose: () => void
  onScan: (code: string) => void
}

export default function CameraScannerModal({ isOpen, onClose, onScan }: CameraScannerModalProps) {
  const [cameras, setCameras] = useState<{ id: string; label: string }[]>([])
  const [selectedCameraId, setSelectedCameraId] = useState<string>('')
  const [error, setError] = useState<string>('')
  const scannerRef = useRef<Html5Qrcode | null>(null)
  const isScanningRef = useRef<boolean>(false)

  useEffect(() => {
    if (!isOpen) return

    Html5Qrcode.getCameras()
      .then((devices) => {
        if (devices && devices.length > 0) {
          setCameras(devices)
          setSelectedCameraId(devices[0].id)
        } else {
          setError('No cameras found. Please check permissions.')
        }
      })
      .catch((err) => {
        setError('Failed to request camera list: ' + err.message)
      })

    return () => {
      stopScanner()
    }
  }, [isOpen])

  useEffect(() => {
    if (!isOpen || !selectedCameraId) return

    startScanner(selectedCameraId)

    return () => {
      stopScanner()
    }
  }, [isOpen, selectedCameraId])

  const startScanner = async (cameraId: string) => {
    setError('')
    await stopScanner()

    try {
      const html5QrCode = new Html5Qrcode('qr-reader')
      scannerRef.current = html5QrCode
      isScanningRef.current = true

      await html5QrCode.start(
        cameraId,
        {
          fps: 10,
          qrbox: (width, height) => {
            const boxWidth = Math.min(width * 0.8, 300)
            const boxHeight = Math.min(height * 0.4, 150)
            return { x: (width - boxWidth) / 2, y: (height - boxHeight) / 2, width: boxWidth, height: boxHeight }
          },
          aspectRatio: 1.0,
        },
        (decodedText) => {
          playBeep()
          onScan(decodedText)
          onClose()
        },
        () => {}
      )
    } catch (err: any) {
      setError('Could not start camera scan: ' + err.message)
    }
  }

  const stopScanner = async () => {
    if (scannerRef.current && isScanningRef.current) {
      try {
        isScanningRef.current = false
        await scannerRef.current.stop()
      } catch (e) {
        console.error('Failed to stop scanner:', e)
      }
      scannerRef.current = null
    }
  }

  const playBeep = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext
      if (!AudioCtx) return
      const audioCtx = new AudioCtx()
      const osc = audioCtx.createOscillator()
      const gain = audioCtx.createGain()
      osc.type = 'sine'
      osc.frequency.value = 1200
      osc.connect(gain)
      gain.connect(audioCtx.destination)
      gain.gain.setValueAtTime(0.3, audioCtx.currentTime)
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.15)
      osc.start(audioCtx.currentTime)
      osc.stop(audioCtx.currentTime + 0.15)
    } catch (e) {
      console.warn('Audio Context error:', e)
    }
  }

  return (
    <Modal open={isOpen} onClose={onClose} title="Camera Barcode Scanner">
      <div className="flex flex-col gap-4">
        {cameras.length > 1 && (
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-primary-700">Select Camera:</span>
            <select
              className="flex-1 text-xs border border-cream-300 rounded-xl px-3 py-1.5 bg-cream-50 focus:outline-none focus:ring-2 focus:ring-primary-500/20"
              value={selectedCameraId}
              onChange={(e) => setSelectedCameraId(e.target.value)}
            >
              {cameras.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label || `Camera ${c.id}`}
                </option>
              ))}
            </select>
          </div>
        )}

        <div className="relative aspect-square w-full max-w-[340px] mx-auto rounded-2xl overflow-hidden bg-primary-950 border border-primary-900 shadow-inner flex items-center justify-center">
          <div id="qr-reader" className="w-full h-full" />
          
          {isScanningRef.current && !error && (
            <div className="absolute left-[10%] right-[10%] top-[48%] h-0.5 bg-red-500 shadow-[0_0_10px_2px_rgba(239,68,68,0.7)] animate-pulse z-10 pointer-events-none" />
          )}

          {error && (
            <div className="absolute inset-0 bg-primary-950/90 flex flex-col items-center justify-center p-6 text-center text-cream-100 gap-3 z-20">
              <Camera className="w-8 h-8 text-primary-400" />
              <p className="text-sm font-semibold">{error}</p>
              <Button size="sm" variant="accent" onClick={() => selectedCameraId && startScanner(selectedCameraId)}>
                Retry
              </Button>
            </div>
          )}
        </div>

        <p className="text-center text-xs text-primary-800/60 max-w-[280px] mx-auto leading-relaxed">
          Position the book or stationery barcode within the viewfinder box. It will scan and add it to the cart automatically.
        </p>

        <div className="flex justify-end pt-2">
          <Button variant="ghost" onClick={onClose}>
            Close
          </Button>
        </div>
      </div>
    </Modal>
  )
}
