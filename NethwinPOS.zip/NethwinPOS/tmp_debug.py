import asyncio
from app.database import init_db, get_database
from app.models.book import Book

async def main():
    await init_db()
    db = await get_database()
    col = db["books"]
    raw = await col.find_one({"title": "Gilead"})
    print("RAW Gilead doc keys:", sorted(raw.keys()))
    print("RAW category:", repr(raw.get("category")))
    print("RAW thumbnailUrl:", repr(raw.get("thumbnailUrl"))[:80] if raw.get("thumbnailUrl") else None)
    print("RAW featured:", repr(raw.get("featured")))

    # Now manually construct a Book via model_validate (this is what beanie does internally)
    print("\nManual Pydantic validation of Book model:")
    try:
        parsed = Book.model_validate(raw)
        print("Parsed OK!")
        print("  title:", parsed.title)
        print("  category_names:", parsed.category_names)
        print("  thumbnail:", bool(parsed.thumbnail))
        print("  authors:", parsed.authors)
        print("  is_featured:", parsed.is_featured)
        print("  is_adult:", parsed.is_adult)
    except Exception as e:
        import traceback
        traceback.print_exc()


asyncio.run(main())
