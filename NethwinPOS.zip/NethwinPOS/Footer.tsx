import { Link } from '../../utils/router-compat'

import { BookOpen, Mail, Phone, MapPin, Globe, MessageCircle, Camera, Radio } from 'lucide-react'
import Button from '../common/Button'
import { useState } from 'react'
import { toast } from 'sonner'

export default function Footer() {
  const [email, setEmail] = useState('')

  const handleNewsletter = (e: React.FormEvent) => {
    e.preventDefault()
    toast.success(`Subscribed ${email} to our newsletter!`)
    setEmail('')
  }

  const shopLinks = [
    { href: '/books', label: 'All Books' },
    { href: '/books?category=new', label: 'New Arrivals' },
    { href: '/books?category=bestsellers', label: 'Bestsellers' },
    { href: '/books?category=deals', label: 'Special Offers' },
  ]

  const infoLinks = [
    { href: '#about', label: 'About Us' },
    { href: '#contact', label: 'Contact' },
    { href: '#faq', label: 'FAQ' },
    { href: '#shipping', label: 'Shipping Policy' },
    { href: '#returns', label: 'Returns' },
  ]

  const socials = [
    { Icon: Globe, label: 'Website' },
    { Icon: MessageCircle, label: 'Twitter' },
    { Icon: Camera, label: 'Instagram' },
    { Icon: Radio, label: 'Youtube' },
  ]

  return (
    <footer className="bg-primary-950 text-cream-100 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 py-16">
          <div>
            <Link href="/" className="flex items-center mb-6 bg-white/5 p-2.5 rounded-xl border border-white/10 w-fit">
              <img src="/logo.svg" alt="Nethwin Printers Logo" className="h-10 w-auto" />
            </Link>
            <p className="text-sm text-cream-300/80 leading-relaxed mb-6">
              Curated literature, luxury editions, and timeless classics. Discover your next beloved read at Nethwin.
            </p>
            <div className="flex items-center gap-3 text-cream-300/80 text-sm mb-2">
              <MapPin className="w-4 h-4 text-accent-400 flex-shrink-0" />
              No. 832, "Dalanda Sevane Api" Foundation, Gatambe Junction, 20000
            </div>
            <div className="flex items-center gap-3 text-cream-300/80 text-sm mb-2">
              <Mail className="w-4 h-4 text-accent-400 flex-shrink-0" />
              hello@nethwinbookshop.com
            </div>
            <div className="flex items-center gap-3 text-cream-300/80 text-sm">
              <Phone className="w-4 h-4 text-accent-400 flex-shrink-0" />
              081 238 6908
            </div>
          </div>

          <div>
            <h4 className="font-serif text-lg font-semibold text-white mb-5">Shop</h4>
            <ul className="space-y-3">
              {shopLinks.map((l) => (
                <li key={l.href}>
                  <Link href={l.href}
                    className="text-sm text-cream-300/80 hover:text-accent-400 transition-colors"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-serif text-lg font-semibold text-white mb-5">Information</h4>
            <ul className="space-y-3">
              {infoLinks.map((l) => (
                <li key={l.href}>
                  <Link href={l.href}
                    className="text-sm text-cream-300/80 hover:text-accent-400 transition-colors"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
            <div className="flex items-center gap-3 mt-8">
              {socials.map(({ Icon, label }, i) => (
                <a
                  key={i}
                  href="#"
                  aria-label={label}
                  className="w-9 h-9 rounded-full bg-primary-900 flex items-center justify-center text-cream-300/70 hover:text-accent-400 hover:bg-primary-800 transition-colors"
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-serif text-lg font-semibold text-white mb-5">Newsletter</h4>
            <p className="text-sm text-cream-300/80 mb-4">
              Subscribe for new releases, exclusive deals, and literary events.
            </p>
            <form onSubmit={handleNewsletter} className="space-y-3">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-4 py-2.5 bg-primary-900 border border-primary-800 rounded-lg text-sm text-cream-100 placeholder:text-cream-300/50 focus:outline-none focus:ring-2 focus:ring-accent-500/30 focus:border-accent-500"
              />
              <Button variant="accent" className="w-full" type="submit">
                Subscribe
              </Button>
            </form>
          </div>
        </div>

        <div className="border-t border-primary-900 py-6 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-sm text-cream-300/60">
            © {new Date().getFullYear()} Nethwin Bookshop. All rights reserved.
          </p>
          <div className="flex items-center gap-6 text-sm text-cream-300/60">
            <a href="#" className="hover:text-accent-400 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-accent-400 transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  )
}
