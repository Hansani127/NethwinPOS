import { useEffect, useRef } from 'react'
import { ScanLine, Search } from 'lucide-react'
import { cn } from '../../utils/cn'

interface ScannerInputProps {
  value: string
  onChange: (v: string) => void
  onSubmit?: (v: string) => void
  placeholder?: string
  className?: string
}

export default function ScannerInput({
  value,
  onChange,
  onSubmit,
  placeholder,
  className,
}: ScannerInputProps) {
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    inputRef.current?.focus()
  }, [])

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && onSubmit && value.trim()) {
      onSubmit(value.trim())
      inputRef.current?.focus()
    }
  }

  return (
    <div className="relative w-full">
      <div className="absolute left-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5 pointer-events-none">
        <ScanLine className="w-4.5 h-4.5 text-primary-700" />
        <div className="w-px h-4 bg-cream-200" />
        <Search className="w-4 h-4 text-primary-900/40" />
      </div>
      <input
        ref={inputRef}
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder={placeholder || 'Scan / Search items (barcode, SKU, ISBN, title)'}
        className={cn(
          'w-full h-12 pl-24 pr-4 rounded-2xl border border-cream-300 bg-white text-base text-primary-900 placeholder:text-primary-900/40 shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500/30 focus-visible:border-primary-500',
          className,
        )}
      />
    </div>
  )
}
