from beanie import init_beanie
from motor.motor_asyncio import AsyncIOMotorClient

from app.config import settings
from app.models.user import User
from app.models.book import Book
from app.models.stationery import Stationery
from app.models.category import Category
from app.models.cart import Cart
from app.models.order import Order
from app.models.ledger import PointsTransaction
from app.models.preorder import PreOrder

motor_client: AsyncIOMotorClient | None = None


async def get_database():
    global motor_client
    if motor_client is None:
        motor_client = AsyncIOMotorClient(settings.MONGO_URI)
    return motor_client[settings.DATABASE_NAME]


async def init_db() -> None:
    global motor_client
    motor_client = AsyncIOMotorClient(settings.MONGO_URI)
    db = motor_client[settings.DATABASE_NAME]
    await init_beanie(
        database=db,
        document_models=[
            User,
            Book,
            Stationery,
            Category,
            Cart,
            Order,
            PointsTransaction,
            PreOrder,
        ],
    )


def get_motor_client() -> AsyncIOMotorClient:
    global motor_client
    assert motor_client is not None, "Motor client not initialized"
    return motor_client
