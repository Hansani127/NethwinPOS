from fastapi import APIRouter, HTTPException, Depends, Query
from typing import Optional
import math
from bson import ObjectId
from beanie.odm.operators.find.logical import Or

from app.core.security import current_superuser
from app.models.category import Category
from app.models.user import User
from app.schemas import CategoryCreate, CategoryUpdate, CategoryRead, PaginatedCategories

router = APIRouter(prefix="/categories", tags=["categories"])


def _category_to_read(cat: Category) -> CategoryRead:
    parent = None
    if cat.parent_category is not None:
        if isinstance(cat.parent_category, (str, ObjectId)):
            parent = str(cat.parent_category)
        else:
            parent = str(cat.parent_category.id)
    return CategoryRead(
        id=str(cat.id),
        name=cat.name,
        slug=cat.slug,
        description=cat.description,
        parent_category=parent,
        created_at=cat.created_at,
        imageUrl=None,
    )


@router.get("", response_model=PaginatedCategories)
async def list_categories(
    page: int = Query(1, ge=1),
    page_size: int = Query(100, ge=1, le=200),
):
    total = await Category.find_all().count()
    total_pages = max(1, math.ceil(total / page_size))
    skip = (page - 1) * page_size
    cats = await Category.find_all().sort(Category.name).skip(skip).limit(page_size).to_list()
    items = [_category_to_read(c) for c in cats]
    return PaginatedCategories(
        total=total,
        page=page,
        page_size=page_size,
        pages=total_pages,
        items=items,
        data=items,
        limit=page_size,
        totalPages=total_pages,
    )


@router.get("/{category_id}", response_model=CategoryRead)
async def get_category(category_id: str):
    cat = await Category.get(category_id)
    if not cat:
        raise HTTPException(status_code=404, detail="Category not found")
    return _category_to_read(cat)


@router.post("", response_model=CategoryRead)
async def create_category(
    data: CategoryCreate,
    _: User = Depends(current_superuser),
):
    existing = await Category.find_one(Category.slug == data.slug)
    if existing:
        raise HTTPException(status_code=400, detail="Category with this slug already exists")

    parent = None
    if data.parent_category:
        parent = await Category.get(data.parent_category)
        if not parent:
            parent = await Category.find_one(Or(Category.slug == data.parent_category))
        if not parent:
            raise HTTPException(status_code=404, detail="Parent category not found")

    cat = Category(
        name=data.name,
        slug=data.slug,
        description=data.description,
        parent_category=parent,
    )
    await cat.insert()
    return _category_to_read(cat)


@router.patch("/{category_id}", response_model=CategoryRead)
async def update_category(
    category_id: str,
    data: CategoryUpdate,
    _: User = Depends(current_superuser),
):
    cat = await Category.get(category_id)
    if not cat:
        raise HTTPException(status_code=404, detail="Category not found")

    update_data = data.model_dump(exclude_unset=True)

    if "parent_category" in update_data:
        parent_ident = update_data.pop("parent_category")
        if parent_ident:
            parent = await Category.get(parent_ident)
            if not parent:
                parent = await Category.find_one(Or(Category.slug == parent_ident))
            if not parent:
                raise HTTPException(status_code=404, detail="Parent category not found")
            cat.parent_category = parent
        else:
            cat.parent_category = None

    if "slug" in update_data:
        existing = await Category.find_one(Category.slug == update_data["slug"], Category.id != ObjectId(category_id))
        if existing:
            raise HTTPException(status_code=400, detail="Category with this slug already exists")

    for key, value in update_data.items():
        setattr(cat, key, value)

    await cat.save()
    return _category_to_read(cat)


@router.delete("/{category_id}")
async def delete_category(
    category_id: str,
    _: User = Depends(current_superuser),
):
    cat = await Category.get(category_id)
    if not cat:
        raise HTTPException(status_code=404, detail="Category not found")
    await cat.delete()
    return {"detail": "Category deleted successfully"}
