import { forwardRef, type ButtonHTMLAttributes, type ReactElement, cloneElement, isValidElement, Children } from 'react'
import { cn } from '../../utils/cn'
import { Loader2 } from 'lucide-react'

type Variant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'accent'
type Size = 'sm' | 'md' | 'lg' | 'icon'

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant
  size?: Size
  isLoading?: boolean
  leftIcon?: React.ReactNode
  rightIcon?: React.ReactNode
  asChild?: boolean
}

const variantStyles: Record<Variant, string> = {
  primary:
    'bg-primary-700 text-white hover:bg-primary-600 focus-visible:ring-primary-500/40 shadow-sm shadow-primary-700/10',
  secondary:
    'bg-cream-100 text-primary-900 hover:bg-cream-200 focus-visible:ring-primary-500/30 border border-cream-200',
  outline:
    'bg-transparent text-primary-700 border border-primary-300 hover:bg-primary-50 hover:border-primary-400 focus-visible:ring-primary-500/30',
  ghost:
    'bg-transparent text-primary-800 hover:bg-cream-200/70 focus-visible:ring-primary-500/30',
  accent:
    'bg-accent-500 text-white hover:bg-accent-600 focus-visible:ring-accent-500/40 shadow-sm shadow-accent-500/20',
}

const sizeStyles: Record<Size, string> = {
  sm: 'h-9 px-3.5 text-sm gap-1.5',
  md: 'h-11 px-5 text-sm gap-2',
  lg: 'h-12 px-7 text-base gap-2.5',
  icon: 'h-10 w-10 p-0',
}

const baseStyles =
  'inline-flex items-center justify-center font-medium rounded-xl transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-cream-50 disabled:pointer-events-none disabled:opacity-50 active:scale-[0.98]'

const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      className,
      variant = 'primary',
      size = 'md',
      isLoading = false,
      disabled,
      leftIcon,
      rightIcon,
      asChild = false,
      children,
      ...props
    },
    ref,
  ) => {
    const combinedClasses = cn(
      baseStyles,
      variantStyles[variant],
      sizeStyles[size],
      className,
    )

    const content = isLoading ? (
      <Loader2 className="w-4 h-4 animate-spin" />
    ) : (
      <>
        {leftIcon && <span className="flex-shrink-0">{leftIcon}</span>}
        {children}
        {rightIcon && <span className="flex-shrink-0">{rightIcon}</span>}
      </>
    )

    if (asChild && isValidElement(children)) {
      const child = Children.only(children as ReactElement)
      return cloneElement(child as ReactElement<any>, {
        className: cn(
          combinedClasses,
          (child as ReactElement<any>).props?.className,
        ),
        'aria-disabled': disabled || isLoading || undefined,
        disabled: disabled || isLoading,
      })
    }

    return (
      <button
        ref={ref}
        disabled={disabled || isLoading}
        className={combinedClasses}
        {...props}
      >
        {content}
      </button>
    )
  },
)

Button.displayName = 'Button'

export default Button
