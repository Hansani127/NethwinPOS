from typing import Tuple
from io import BytesIO

import cloudinary
import cloudinary.uploader

from app.config import settings


def init_cloudinary() -> None:
    if settings.CLOUDINARY_URL:
        cloudinary.config(cloudinary_url=settings.CLOUDINARY_URL)


async def upload_image(file_bytes: bytes, folder: str = "books") -> Tuple[str, str]:
    init_cloudinary()
    result = cloudinary.uploader.upload(
        file_bytes,
        folder=folder,
        format="jpg",
        quality="auto:good",
    )
    return result["secure_url"], result["public_id"]


async def delete_image(public_id: str) -> None:
    init_cloudinary()
    cloudinary.uploader.destroy(public_id)
