from beanie import Document, Indexed
from datetime import datetime
from typing import Optional, Any
from pydantic import Field, field_validator
from decimal import Decimal
from bson import Decimal128


def _to_decimal(v: Any) -> Any:
    if isinstance(v, Decimal128):
        return v.to_decimal()
    return v


class Stationery(Document):
    sku: Indexed(str, unique=True)
    name: str
    category: Indexed(str)
    price: Decimal = Field(gt=0, max_digits=10, decimal_places=2)
    stock: int = Field(ge=0, default=0)
    description: Optional[str] = None
    image: Optional[str] = None
    barcode: Optional[str] = None
    brand: Optional[str] = None
    is_active: bool = True
    is_featured: bool = False
    is_preorder: bool = False
    preorder_release_date: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    class Settings:
        name = "stationeries"

    @field_validator("price", mode="before")
    @classmethod
    def _price_to_decimal(cls, v: Any) -> Any:
        return _to_decimal(v)

    @field_validator("updated_at")
    @classmethod
    def set_updated_at(cls, v: datetime) -> datetime:
        return v or datetime.utcnow()
