from fastapi import APIRouter, HTTPException, Depends, Query
from typing import Optional
import math
import random
import string
from datetime import datetime
from decimal import Decimal
from bson import ObjectId

from app.core.security import current_user, current_superuser, current_optional_user
from app.models.user import User
from app.models.book import Book
from app.models.stationery import Stationery
from app.models.preorder import PreOrder, PreOrderStatus
from app.models.order import ShippingAddress
from app.models.ledger import PointsTransaction, TransactionType
from app.services import (
    tier_from_spent,
    points_earned_for,
    discount_from_points,
    max_points_for_order,
    TIER_EARN_MULTIPLIERS,
)
from app.config import settings
from app.schemas import (
    PreOrderCreate,
    PreOrderUpdate,
    PreOrderRead,
    PaginatedPreOrders,
    PreOrderStatusUpdate,
    PayDepositRequest,
    ShippingAddressBase,
)

router = APIRouter(prefix="/preorders", tags=["preorders"])


def _generate_preorder_number() -> str:
    date_part = datetime.utcnow().strftime("%Y%m%d")
    suffix = "".join(random.choices(string.ascii_uppercase + string.digits, k=6))
    return f"PRE-{date_part}-{suffix}"


def _preorder_to_read(po: PreOrder) -> PreOrderRead:
    user_id_str = None
    if po.user_id:
        if hasattr(po.user_id, "id"):
            user_id_str = str(po.user_id.id)
        else:
            user_id_str = str(po.user_id)
    ship_addr = None
    if po.shipping_address:
        ship_addr = ShippingAddressBase(
            name=po.shipping_address.name,
            line1=po.shipping_address.line1,
            line2=po.shipping_address.line2,
            city=po.shipping_address.city,
            state=po.shipping_address.state,
            postal_code=po.shipping_address.postal_code,
            country=po.shipping_address.country,
            phone=po.shipping_address.phone,
        )
    return PreOrderRead(
        id=str(po.id),
        user_id=user_id_str,
        product_type=po.product_type,
        product_id=po.product_id,
        quantity=po.quantity,
        unit_price=po.unit_price,
        deposit_amount=po.deposit_amount,
        total_amount=po.total_amount,
        amount_paid=po.amount_paid,
        status=po.status,
        release_date=po.release_date,
        customer_name=po.customer_name,
        email=po.email,
        phone=po.phone,
        shipping_address=ship_addr,
        order_number=po.order_number,
        notes=po.notes,
        created_at=po.created_at,
        updated_at=po.updated_at,
        expected_fulfillment_date=po.expected_fulfillment_date,
    )


@router.get("", response_model=PaginatedPreOrders)
async def list_preorders(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    product_type: Optional[str] = None,
    product_id: Optional[str] = None,
    _: Optional[User] = Depends(current_optional_user),
):
    query_filters = []
    if product_type:
        query_filters.append(PreOrder.product_type == product_type)
    if product_id:
        query_filters.append(PreOrder.product_id == product_id)

    total = await PreOrder.find(*query_filters).count()
    total_pages = max(1, math.ceil(total / page_size))
    skip = (page - 1) * page_size
    pos = await PreOrder.find(*query_filters).sort(-PreOrder.created_at).skip(skip).limit(page_size).to_list()
    items = [_preorder_to_read(po) for po in pos]

    return PaginatedPreOrders(
        total=total,
        page=page,
        page_size=page_size,
        pages=total_pages,
        items=items,
        data=items,
        limit=page_size,
        totalPages=total_pages,
    )


@router.get("/me", response_model=PaginatedPreOrders)
async def my_preorders(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    status: Optional[PreOrderStatus] = None,
    user: User = Depends(current_user),
):
    user_oid = ObjectId(user.id)
    query_filters = [PreOrder.user_id == user_oid]
    if status:
        query_filters.append(PreOrder.status == status)

    total = await PreOrder.find(*query_filters).count()
    total_pages = max(1, math.ceil(total / page_size))
    skip = (page - 1) * page_size
    pos = await PreOrder.find(*query_filters).sort(-PreOrder.created_at).skip(skip).limit(page_size).to_list()
    items = [_preorder_to_read(po) for po in pos]

    return PaginatedPreOrders(
        total=total,
        page=page,
        page_size=page_size,
        pages=total_pages,
        items=items,
        data=items,
        limit=page_size,
        totalPages=total_pages,
    )


@router.get("/admin/all", response_model=PaginatedPreOrders)
async def admin_all_preorders(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    status: Optional[PreOrderStatus] = None,
    _: User = Depends(current_superuser),
):
    query_filters = []
    if status:
        query_filters.append(PreOrder.status == status)

    total = await PreOrder.find(*query_filters).count()
    total_pages = max(1, math.ceil(total / page_size))
    skip = (page - 1) * page_size
    pos = await PreOrder.find(*query_filters).sort(-PreOrder.created_at).skip(skip).limit(page_size).to_list()
    items = [_preorder_to_read(po) for po in pos]

    return PaginatedPreOrders(
        total=total,
        page=page,
        page_size=page_size,
        pages=total_pages,
        items=items,
        data=items,
        limit=page_size,
        totalPages=total_pages,
    )


@router.get("/{preorder_id}", response_model=PreOrderRead)
async def get_preorder(preorder_id: str, user: Optional[User] = Depends(current_user)):
    po = await PreOrder.get(preorder_id)
    if not po:
        raise HTTPException(status_code=404, detail="Pre-order not found")

    if user and not user.is_superuser:
        user_oid = ObjectId(user.id)
        po_user_oid = None
        if po.user_id:
            if hasattr(po.user_id, "id"):
                po_user_oid = ObjectId(str(po.user_id.id))
            else:
                po_user_oid = ObjectId(str(po.user_id))
        if po_user_oid and po_user_oid != user_oid:
            raise HTTPException(status_code=403, detail="Forbidden")

    return _preorder_to_read(po)


@router.post("", response_model=PreOrderRead)
async def create_preorder(
    data: PreOrderCreate,
    user: Optional[User] = Depends(current_optional_user),
):
    product = None
    release_date = None
    if data.product_type == "book":
        product = await Book.get(data.product_id)
        if product:
            release_date = product.preorder_release_date
    elif data.product_type == "stationery":
        product = await Stationery.get(data.product_id)
        if product:
            release_date = product.preorder_release_date
    else:
        raise HTTPException(status_code=400, detail="Invalid product_type")

    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    unit_price = product.price
    total_amount = (unit_price * data.quantity).quantize(Decimal("0.01"))

    points_discount = Decimal("0")
    points_applied = 0
    if data.redeem_points > 0 and user is not None:
        max_allowed = max_points_for_order(total_amount)
        points_applied = min(data.redeem_points, user.loyalty_points, max_allowed)
        if points_applied > 0:
            points_discount = discount_from_points(points_applied)
            total_amount = (total_amount - points_discount).quantize(Decimal("0.01"))
            if total_amount < Decimal("0"):
                total_amount = Decimal("0")

    deposit = data.deposit_amount
    if deposit > total_amount:
        deposit = total_amount

    ship_addr = None
    if data.shipping_address:
        ship_addr = ShippingAddress(
            name=data.shipping_address.name,
            line1=data.shipping_address.line1,
            line2=data.shipping_address.line2,
            city=data.shipping_address.city,
            state=data.shipping_address.state,
            postal_code=data.shipping_address.postal_code,
            country=data.shipping_address.country,
            phone=data.shipping_address.phone,
        )

    user_ref = ObjectId(user.id) if user else None
    status = PreOrderStatus.RESERVED
    amount_paid = Decimal("0")
    if deposit > 0:
        status = PreOrderStatus.DEPOSIT_PAID
        amount_paid = deposit

    po = PreOrder(
        user_id=user_ref,
        product_type=data.product_type,
        product_id=data.product_id,
        quantity=data.quantity,
        unit_price=unit_price,
        deposit_amount=deposit,
        total_amount=total_amount,
        amount_paid=amount_paid,
        status=status,
        release_date=release_date,
        customer_name=data.customer_name,
        email=data.email,
        phone=data.phone,
        shipping_address=ship_addr,
        order_number=_generate_preorder_number(),
        notes=data.notes,
        expected_fulfillment_date=release_date,
    )
    await po.insert()

    if user is not None and points_applied > 0:
        user.loyalty_points = max(0, user.loyalty_points - points_applied)
        user.points_redeemed_total += points_applied
        await user.save()
        tx = PointsTransaction(
            user_id=ObjectId(user.id),
            type=TransactionType.REDEEM,
            points=-points_applied,
            balance_after=user.loyalty_points,
            source=f"preorder:{po.order_number}",
            description=f"Points redeemed on pre-order {po.order_number}",
        )
        await tx.insert()

    return _preorder_to_read(po)


@router.patch("/{preorder_id}/status", response_model=PreOrderRead)
async def update_preorder_status(
    preorder_id: str,
    data: PreOrderStatusUpdate,
    _: User = Depends(current_superuser),
):
    po = await PreOrder.get(preorder_id)
    if not po:
        raise HTTPException(status_code=404, detail="Pre-order not found")

    po.status = data.status
    po.updated_at = datetime.utcnow()
    if data.status == PreOrderStatus.RELEASED_SHIPPED and not po.shipped_at:
        pass
    if data.status == PreOrderStatus.FULLY_PAID:
        if po.amount_paid < po.total_amount:
            pass
    await po.save()
    return _preorder_to_read(po)


@router.post("/{preorder_id}/pay-deposit", response_model=PreOrderRead)
async def pay_deposit(
    preorder_id: str,
    data: PayDepositRequest,
    user: Optional[User] = Depends(current_user),
):
    po = await PreOrder.get(preorder_id)
    if not po:
        raise HTTPException(status_code=404, detail="Pre-order not found")

    if user is not None and not user.is_superuser:
        user_oid = ObjectId(user.id)
        po_user_oid = None
        if po.user_id:
            if hasattr(po.user_id, "id"):
                po_user_oid = ObjectId(str(po.user_id.id))
            else:
                po_user_oid = ObjectId(str(po.user_id))
        if po_user_oid and po_user_oid != user_oid:
            raise HTTPException(status_code=403, detail="Forbidden")

    amount = data.amount if data.amount is not None else (po.total_amount - po.amount_paid)
    if amount <= Decimal("0"):
        raise HTTPException(status_code=400, detail="No amount due")
    if amount > (po.total_amount - po.amount_paid):
        amount = po.total_amount - po.amount_paid

    po.amount_paid = (po.amount_paid + amount).quantize(Decimal("0.01"))
    if po.amount_paid >= po.total_amount:
        po.status = PreOrderStatus.FULLY_PAID
        if po.user_id:
            user_obj_oid = ObjectId(str(po.user_id.id)) if hasattr(po.user_id, "id") else ObjectId(str(po.user_id))
            u = await User.get(str(user_obj_oid))
            if u:
                tier = tier_from_spent(u.total_spent)
                earned = points_earned_for(po.total_amount, tier)
                if earned > 0:
                    u.loyalty_points += earned
                    u.points_earned_total += earned
                    u.total_spent = (u.total_spent + po.total_amount).quantize(Decimal("0.01"))
                    new_tier = tier_from_spent(u.total_spent)
                    u.membership_tier = new_tier
                    await u.save()
                    tx = PointsTransaction(
                        user_id=user_obj_oid,
                        type=TransactionType.EARN,
                        points=earned,
                        balance_after=u.loyalty_points,
                        source=f"preorder:{po.order_number}",
                        description=f"Points earned from pre-order {po.order_number}",
                    )
                    await tx.insert()
    elif po.amount_paid > Decimal("0"):
        po.status = PreOrderStatus.DEPOSIT_PAID

    po.updated_at = datetime.utcnow()
    await po.save()
    return _preorder_to_read(po)
