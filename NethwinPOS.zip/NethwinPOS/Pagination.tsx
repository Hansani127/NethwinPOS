import { cn } from '../../utils/cn'
import { ChevronLeft, ChevronRight, MoreHorizontal } from 'lucide-react'

interface PaginationProps {
  currentPage: number
  totalPages: number
  onPageChange: (page: number) => void
  className?: string
}

export default function Pagination({
  currentPage,
  totalPages,
  onPageChange,
  className,
}: PaginationProps) {
  if (totalPages <= 1) return null

  const getPages = (): (number | 'dots')[] => {
    const pages: (number | 'dots')[] = []
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) pages.push(i)
      return pages
    }
    pages.push(1)
    if (currentPage > 3) pages.push('dots')
    const start = Math.max(2, currentPage - 1)
    const end = Math.min(totalPages - 1, currentPage + 1)
    for (let i = start; i <= end; i++) pages.push(i)
    if (currentPage < totalPages - 2) pages.push('dots')
    pages.push(totalPages)
    return pages
  }

  const btnBase =
    'inline-flex items-center justify-center h-10 min-w-10 px-3 rounded-xl text-sm font-medium transition-all'
  const pageBtn =
    'border border-cream-200 bg-white text-primary-800 hover:bg-cream-100 hover:border-cream-300'
  const activeBtn =
    'bg-primary-700 text-white border border-primary-700 shadow-sm shadow-primary-700/20'
  const disabledBtn = 'opacity-40 cursor-not-allowed pointer-events-none'

  return (
    <nav className={cn('flex items-center justify-center gap-2 flex-wrap', className)}>
      <button
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
        className={cn(btnBase, pageBtn, currentPage === 1 && disabledBtn)}
        aria-label="Previous page"
      >
        <ChevronLeft className="w-4 h-4" />
      </button>

      {getPages().map((p, i) =>
        p === 'dots' ? (
          <span
            key={`dots-${i}`}
            className="inline-flex items-center justify-center h-10 w-10 text-primary-700/60"
          >
            <MoreHorizontal className="w-4 h-4" />
          </span>
        ) : (
          <button
            key={p}
            onClick={() => onPageChange(p)}
            className={cn(btnBase, p === currentPage ? activeBtn : pageBtn)}
            aria-current={p === currentPage ? 'page' : undefined}
          >
            {p}
          </button>
        ),
      )}

      <button
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
        className={cn(btnBase, pageBtn, currentPage === totalPages && disabledBtn)}
        aria-label="Next page"
      >
        <ChevronRight className="w-4 h-4" />
      </button>
    </nav>
  )
}
