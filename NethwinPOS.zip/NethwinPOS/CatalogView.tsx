"use client";

import { useSearchParams } from '../../utils/router-compat'
import { useState, useEffect, useMemo } from 'react'

import BookFilters from './BookFilters'
import BookCard from './BookCard'
import Pagination from '../common/Pagination'
import EmptyState from '../common/EmptyState'
import { useCatalogSearch } from '../../hooks/useBooks'
import { useCategories } from '../../hooks/useCategories'
import type { BookFilters as BookFiltersType, CatalogProduct, Category, PaginatedResponse } from '../../types'
import {
  SlidersHorizontal,
  Layers,
  BookOpen,
  PenTool,
  ChevronRight,
  FilterX,
  Grid3X3,
  List,
  LayoutList,
  TrendingUp,
  BookMarked,
} from 'lucide-react'
import Button from '../common/Button'
import Select from '../common/Select'
import Badge from '../common/Badge'
import Input from '../common/Input'
import { Search } from 'lucide-react'
import { cn } from '../../utils/cn'
import React from 'react'

type BrowseTab = 'all' | 'books' | 'stationery'
type ViewMode = 'grid' | 'list' | 'compact'

interface CatalogViewProps {
  defaultTab?: BrowseTab
  hideTabs?: boolean
  title?: string
  sub?: string
}

const SORT_OPTIONS = [
  { value: '', label: 'Recommended' },
  { value: 'newest', label: 'Newest' },
  { value: 'price-asc', label: 'Price ↑' },
  { value: 'price-desc', label: 'Price ↓' },
  { value: 'rating-desc', label: 'Top Rated' },
  { value: 'name-asc', label: 'A → Z' },
]

function extractCategories(data: Category[] | PaginatedResponse<Category> | undefined): Category[] {
  if (!data) return []
  if (Array.isArray(data)) return data
  return (data as any).items || (data as any).data || []
}

function tabToProductType(t: BrowseTab): BookFiltersType['productType'] {
  if (t === 'books') return 'book'
  if (t === 'stationery') return 'stationery'
  return 'all'
}

function formatProductCount(count: number, tab: BrowseTab) {
  const noun =
    tab === 'books' ? 'title' : tab === 'stationery' ? 'item' : 'product'
  return `${count} ${noun}${count === 1 ? '' : 's'}`
}

function Skeleton({ viewMode }: { viewMode: ViewMode }) {
  if (viewMode === 'grid') {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
        {Array.from({ length: 9 }).map((_, i) => (
          <div
            key={i}
            className="bg-white rounded-2xl border border-cream-200 overflow-hidden"
          >
            <div className="aspect-[2/3] bg-cream-100 animate-pulse" />
            <div className="p-4 space-y-3">
              <div className="h-4 w-2/3 bg-cream-100 rounded animate-pulse" />
              <div className="h-3 w-1/2 bg-cream-100 rounded animate-pulse" />
              <div className="flex items-center justify-between pt-2">
                <div className="h-5 w-20 bg-cream-100 rounded animate-pulse" />
                <div className="h-9 w-20 bg-cream-100 rounded-full animate-pulse" />
              </div>
            </div>
          </div>
        ))}
      </div>
    )
  }
  return (
    <div className="space-y-4">
      {Array.from({ length: 6 }).map((_, i) => (
        <div
          key={i}
          className="bg-white rounded-2xl border border-cream-200 p-4 flex gap-4"
        >
          <div className="w-24 h-32 sm:w-28 sm:h-40 bg-cream-100 rounded-xl animate-pulse flex-shrink-0" />
          <div className="flex-1 space-y-3 py-1">
            <div className="h-5 w-1/2 bg-cream-100 rounded animate-pulse" />
            <div className="h-3 w-1/3 bg-cream-100 rounded animate-pulse" />
            <div className="h-3 w-5/6 bg-cream-100 rounded animate-pulse" />
            <div className="h-3 w-4/6 bg-cream-100 rounded animate-pulse" />
            <div className="flex items-center justify-between pt-2">
              <div className="h-6 w-24 bg-cream-100 rounded animate-pulse" />
              <div className="h-10 w-32 bg-cream-100 rounded-full animate-pulse" />
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

function ListCard({ product }: { product: CatalogProduct }) {
  const p = product as any
  const isBook = !!((p as any).author || (p as any).isbn || (p as any).productType === 'book')
  return <BookCard book={product} unified={!isBook} />
}

export default function CatalogView({ defaultTab = 'all', hideTabs = false, title, sub }: CatalogViewProps) {
  const [searchParams, setSearchParams] = useSearchParams()
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false)
  const [viewMode, setViewMode] = useState<ViewMode>('grid')
  const [searchInput, setSearchInput] = useState('')

  const urlTab = (searchParams.get('tab') as BrowseTab) || null
  const initialTab: BrowseTab =
    urlTab && ['all', 'books', 'stationery'].includes(urlTab)
      ? (urlTab as BrowseTab)
      : defaultTab
  const [tab, setTab] = useState<BrowseTab>(initialTab)

  useEffect(() => {
    if (!hideTabs && urlTab && ['all', 'books', 'stationery'].includes(urlTab)) {
      setTab(urlTab as BrowseTab)
    }
  }, [urlTab, hideTabs])

  const initialPageSize = Number(searchParams.get('page_size')) || 12
  const initialPage = Number(searchParams.get('page')) || 1

  const [filters, setFilters] = useState<BookFiltersType>({
    page: initialPage,
    page_size: initialPageSize,
    search: searchParams.get('search') || undefined,
    sort: (searchParams.get('sort') as BookFiltersType['sort']) || undefined,
    category: searchParams.get('category') || undefined,
    featured: searchParams.get('featured') === 'true' ? true : undefined,
    minPrice: searchParams.get('minPrice') ? Number(searchParams.get('minPrice')) : undefined,
    maxPrice: searchParams.get('maxPrice') ? Number(searchParams.get('maxPrice')) : undefined,
    productType: tabToProductType(initialTab),
  })

  useEffect(() => {
    setSearchInput(filters.search || '')
  }, [filters.search])

  // Debounced search for the top bar
  useEffect(() => {
    const t = setTimeout(() => {
      const cur = filters.search || ''
      if (searchInput !== cur) {
        handleFilterChange({ ...filters, search: searchInput || undefined, page: 1 })
      }
    }, 400)
    return () => clearTimeout(t)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchInput])

  const switchTab = (newTab: BrowseTab) => {
    setTab(newTab)
    const qs = new URLSearchParams(searchParams.toString())
    qs.set('tab', newTab)
    qs.delete('category')
    qs.delete('search')
    qs.delete('featured')
    qs.delete('minPrice')
    qs.delete('maxPrice')
    qs.delete('sort')
    qs.set('page', '1')
    setSearchParams(qs, { replace: true })
    setFilters(f => ({
      ...f,
      productType: tabToProductType(newTab),
      category: undefined,
      categoryId: undefined,
      search: undefined,
      featured: undefined,
      minPrice: undefined,
      maxPrice: undefined,
      sort: undefined,
      page: 1,
    }))
    setSearchInput('')
  }

  const syncUrl = (next: BookFiltersType) => {
    const params = new URLSearchParams(searchParams.toString())
    const setOrDel = (k: string, v: string | number | undefined) => {
      if (v === undefined || v === '' || v === null) params.delete(k)
      else params.set(k, String(v))
    }
    if (!hideTabs) params.set('tab', tab)
    setOrDel('search', next.search)
    setOrDel('category', next.category)
    setOrDel('sort', next.sort)
    setOrDel('featured', next.featured ? 'true' : undefined)
    setOrDel('minPrice', next.minPrice)
    setOrDel('maxPrice', next.maxPrice)
    setOrDel('page', next.page)
    setOrDel('page_size', next.page_size)
    setSearchParams(params, { replace: true })
  }

  const handleFilterChange = (newFilters: BookFiltersType) => {
    setFilters(newFilters)
    syncUrl(newFilters)
  }

  const { data: rawCategories } = useCategories()
  const categories = extractCategories(rawCategories)

  const { data: catalogData, isLoading } = useCatalogSearch({
    search: filters.search,
    category: filters.category,
    page: filters.page,
    page_size: filters.page_size,
    sort: filters.sort,
    productType: filters.productType,
    minPrice: filters.minPrice,
    maxPrice: filters.maxPrice,
    featured: filters.featured,
  })

  const products: CatalogProduct[] = useMemo(() => {
    if (!catalogData) return []
    return (catalogData as any).items || (catalogData as any).data || []
  }, [catalogData])

  const total = (catalogData as any)?.total ?? 0
  const totalPages =
    (catalogData as any)?.totalPages || (catalogData as any)?.pages || 1
  const stats = (catalogData as any)?.stats
  const booksCount: number = stats?.books_count ?? 0
  const stationeryCount: number = stats?.stationery_count ?? 0
  const availableCategories: string[] = stats?.categories_available ?? []

  const headings: Record<BrowseTab, { title: string; sub: string; icon: React.ReactNode }> = {
    all: {
      title: 'Our Collection',
      sub: 'Curated books and fine stationery for the passionate reader.',
      icon: <Layers className="w-5 h-5 text-accent-500" />,
    },
    books: {
      title: 'Books Catalog',
      sub: 'Hand-picked first editions, signed copies and modern classics.',
      icon: <BookOpen className="w-5 h-5 text-accent-500" />,
    },
    stationery: {
      title: 'Stationery Collection',
      sub: 'Luxury pens, leather journals and desk essentials.',
      icon: <PenTool className="w-5 h-5 text-accent-500" />,
    },
  }

  const pageTitle = title || headings[tab].title
  const pageSub = sub || headings[tab].sub
  const pageIcon = headings[tab].icon

  const TABS: { key: BrowseTab; label: string; icon: React.ReactNode; hint: string }[] = [
    { key: 'all', label: 'All Products', icon: <Layers className="w-4 h-4" />, hint: `${total} items` },
    { key: 'books', label: 'Books', icon: <BookOpen className="w-4 h-4" />, hint: `${booksCount} titles` },
    { key: 'stationery', label: 'Stationery', icon: <PenTool className="w-4 h-4" />, hint: `${stationeryCount} items` },
  ]

  const activeFilterLabels: { label: string; onRemove: () => void }[] = []
  if (filters.search) {
    activeFilterLabels.push({
      label: `“${filters.search}”`,
      onRemove: () => handleFilterChange({ ...filters, search: undefined, page: 1 }),
    })
  }
  if (filters.category) {
    activeFilterLabels.push({
      label: filters.category,
      onRemove: () =>
        handleFilterChange({ ...filters, category: undefined, categoryId: undefined, page: 1 }),
    })
  }
  if (filters.minPrice != null || filters.maxPrice != null) {
    activeFilterLabels.push({
      label: `Price filter`,
      onRemove: () =>
        handleFilterChange({ ...filters, minPrice: undefined, maxPrice: undefined, page: 1 }),
    })
  }
  if (filters.featured) {
    activeFilterLabels.push({
      label: `Featured only`,
      onRemove: () => handleFilterChange({ ...filters, featured: undefined, page: 1 }),
    })
  }

  const clearAllFilters = () => {
    setSearchInput('')
    handleFilterChange({
      categoryId: undefined,
      category: undefined,
      search: undefined,
      minPrice: undefined,
      maxPrice: undefined,
      sort: undefined,
      featured: undefined,
      productType: tabToProductType(tab),
      page: 1,
      page_size: filters.page_size,
    })
  }

  return (
    <div className="bg-cream-50 min-h-[calc(100vh-5rem)]">
      {/* HERO HEADER */}
      <div className="relative overflow-hidden border-b border-cream-200 bg-gradient-to-br from-white via-cream-50 to-white">
        <div
          className="absolute inset-0 opacity-[0.35] pointer-events-none"
          style={{
            backgroundImage:
              "radial-gradient(circle at 15% 20%, rgba(251,191,36,0.18) 0, transparent 45%), radial-gradient(circle at 85% 75%, rgba(30,58,138,0.12) 0, transparent 45%)",
          }}
        />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-8">
          <nav className="flex items-center gap-1.5 text-xs font-medium text-primary-800/60 mb-6">
            <a href="/" className="hover:text-primary-800 transition-colors">Home</a>
            <ChevronRight className="w-3 h-3" />
            <span className="text-primary-800/90">
              {tab === 'all' ? 'Catalog' : tab === 'books' ? 'Books' : 'Stationery'}
            </span>
            {filters.category && (
              <>
                <ChevronRight className="w-3 h-3" />
                <span className="text-primary-800">{filters.category}</span>
              </>
            )}
          </nav>

          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
            <div className="max-w-2xl">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-accent-50 border border-accent-200/70 text-accent-800 text-xs font-semibold uppercase tracking-[0.14em] mb-4">
                {pageIcon}
                {tab === 'all' ? 'Browse Everything' : tab === 'books' ? 'Readers Corner' : 'Desk Boutique'}
              </div>
              <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-semibold tracking-tight text-primary-950 leading-[1.05]">
                {pageTitle.split(' ')[0]}{' '}
                <span className="italic text-primary-700">
                  {pageTitle.split(' ').slice(1).join(' ') || 'Collection'}
                </span>
              </h1>
              <p className="mt-4 text-primary-800/75 text-base leading-relaxed max-w-xl">
                {pageSub}
              </p>
            </div>

            <div className="w-full lg:w-[420px]">
              <div className="relative">
                <Input
                  placeholder="Search titles, authors, ISBN or brand…"
                  leftIcon={<Search className="w-4 h-4" />}
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                  className="h-14 !rounded-2xl !pl-12 !text-base shadow-sm"
                />
                {searchInput && (
                  <button
                    onClick={() => {
                      setSearchInput('')
                      handleFilterChange({ ...filters, search: undefined, page: 1 })
                    }}
                    className="absolute right-3 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-cream-100 hover:bg-cream-200 flex items-center justify-center text-primary-800/70"
                    aria-label="Clear search"
                  >
                    <svg viewBox="0 0 20 20" fill="currentColor" className="w-3.5 h-3.5">
                      <path d="M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z" />
                    </svg>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Tab switcher */}
          {!hideTabs && (
            <div className="mt-8 flex items-center gap-2 flex-wrap">
              {TABS.map(t => {
                const active = tab === t.key
                return (
                  <button
                    key={t.key}
                    onClick={() => switchTab(t.key)}
                    className={cn(
                      'group flex items-center gap-2 h-11 px-5 rounded-full text-sm font-semibold transition-all border',
                      active
                        ? 'bg-primary-900 text-white border-primary-900 shadow-lg shadow-primary-900/20'
                        : 'bg-white text-primary-800/85 border-cream-200 hover:bg-cream-50 hover:border-cream-300',
                    )}
                  >
                    <span className={cn(active ? 'text-accent-400' : 'text-primary-600')}>
                      {t.icon}
                    </span>
                    <span>{t.label}</span>
                    <span
                      className={cn(
                        'text-[10px] px-2 py-0.5 rounded-full font-bold tracking-wider',
                        active
                          ? 'bg-white/15 text-white'
                          : 'bg-cream-100 text-primary-800/70',
                      )}
                    >
                      {t.key === 'all'
                        ? total
                        : t.key === 'books'
                          ? booksCount
                          : stationeryCount}
                    </span>
                  </button>
                )
              })}
            </div>
          )}
        </div>
      </div>

      {/* STICKY TOOLBAR */}
      <div className="sticky top-16 z-30 bg-cream-50/80 backdrop-blur-md border-b border-cream-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex items-center gap-2 text-sm">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white border border-cream-200 text-primary-900 font-semibold text-xs tabular-nums shadow-sm">
                <TrendingUp className="w-3.5 h-3.5 text-accent-600" />
                {formatProductCount(total, tab)}
              </span>
              {tab === 'all' && catalogData && (booksCount > 0 || stationeryCount > 0) && (
                <>
                  <span className="text-primary-900/30">·</span>
                  <span className="inline-flex items-center gap-1 text-xs text-primary-800/70">
                    <BookMarked className="w-3.5 h-3.5 text-primary-600" />
                    <span className="font-semibold text-primary-900 tabular-nums">{booksCount}</span>
                    <span className="text-primary-800/60">books</span>
                    <span className="text-primary-900/30">·</span>
                    <span className="font-semibold text-primary-900 tabular-nums">{stationeryCount}</span>
                    <span className="text-primary-800/60">stationery</span>
                  </span>
                </>
              )}
            </div>

            {activeFilterLabels.length > 0 && (
              <div className="hidden md:flex items-center gap-1.5 min-w-0 overflow-x-auto">
                {activeFilterLabels.map((f, i) => (
                  <button
                    key={i}
                    onClick={f.onRemove}
                    className="inline-flex items-center gap-1 pl-2 pr-1 h-6 rounded-full bg-white border border-cream-200 text-[11px] font-semibold text-primary-800 whitespace-nowrap hover:bg-cream-50 hover:border-cream-300 transition-colors shadow-sm"
                  >
                    {f.label}
                    <span className="w-4 h-4 rounded-full bg-cream-100 flex items-center justify-center">
                      <svg viewBox="0 0 20 20" fill="currentColor" className="w-2.5 h-2.5 text-primary-800/70">
                        <path d="M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z" />
                      </svg>
                    </span>
                  </button>
                ))}
                <button
                  onClick={clearAllFilters}
                  className="inline-flex items-center gap-1 pl-2 pr-2 h-6 rounded-full text-[11px] font-semibold text-primary-700 hover:text-primary-900 whitespace-nowrap transition-colors"
                >
                  <FilterX className="w-3 h-3" />
                  Clear all
                </button>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <div className="hidden sm:block w-44">
              <Select
                options={SORT_OPTIONS}
                value={filters.sort || ''}
                onChange={(e) =>
                  handleFilterChange({
                    ...filters,
                    sort: (e.target.value as BookFiltersType['sort']) || undefined,
                    page: 1,
                  })
                }
              />
            </div>

            <div className="hidden sm:flex items-center p-1 rounded-xl bg-white border border-cream-200 shadow-sm">
              {(
                [
                  { mode: 'grid' as const, Icon: Grid3X3, label: 'Grid' },
                  { mode: 'list' as const, Icon: List, label: 'List' },
                  { mode: 'compact' as const, Icon: LayoutList, label: 'Compact' },
                ]
              ).map(({ mode, Icon, label }) => {
                const active = viewMode === mode
                return (
                  <button
                    key={mode}
                    onClick={() => setViewMode(mode)}
                    className={cn(
                      'w-9 h-9 flex items-center justify-center rounded-lg text-xs font-semibold transition-all',
                      active
                        ? 'bg-primary-700 text-white shadow-sm'
                        : 'text-primary-800/60 hover:text-primary-800 hover:bg-cream-50',
                    )}
                    title={label}
                  >
                    <Icon className="w-4 h-4" />
                  </button>
                )
              })}
            </div>

            <div className="sm:hidden flex items-center">
              <Button
                variant="secondary"
                size="sm"
                className="gap-2 h-10"
                onClick={() => setMobileFiltersOpen(true)}
              >
                <SlidersHorizontal className="w-4 h-4" />
                Filters
                {activeFilterLabels.length > 0 && (
                  <span className="ml-1 inline-flex items-center justify-center w-5 h-5 rounded-full bg-primary-700 text-white text-[10px] font-bold">
                    {activeFilterLabels.length}
                  </span>
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* MAIN LAYOUT */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-10">
        {activeFilterLabels.length > 0 && (
          <div className="md:hidden mb-6 flex flex-wrap gap-2">
            {activeFilterLabels.map((f, i) => (
              <button
                key={i}
                onClick={f.onRemove}
                className="inline-flex items-center gap-1 pl-2.5 pr-1.5 py-1 rounded-full bg-white border border-cream-200 text-xs font-semibold text-primary-800 hover:bg-cream-50 hover:border-cream-300 shadow-sm"
              >
                {f.label}
                <span className="w-4 h-4 rounded-full bg-cream-100 flex items-center justify-center">
                  <svg viewBox="0 0 20 20" fill="currentColor" className="w-2.5 h-2.5 text-primary-800/70">
                    <path d="M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z" />
                  </svg>
                </span>
              </button>
            ))}
            <button
              onClick={clearAllFilters}
              className="inline-flex items-center gap-1.5 pl-2.5 pr-2.5 py-1 rounded-full text-xs font-semibold text-primary-700 bg-primary-50 border border-primary-200 hover:bg-primary-100"
            >
              <FilterX className="w-3 h-3" />
              Clear all filters
            </button>
          </div>
        )}

        <div className="grid lg:grid-cols-[300px_1fr] gap-8">
          {/* Desktop sidebar */}
          <div className="hidden lg:block lg:sticky lg:top-36 lg:self-start">
            <BookFilters
              categories={categories}
              filters={filters}
              onFilterChange={handleFilterChange}
              includeProductType={false}
              availableCategories={availableCategories}
              totalCount={total}
              booksCount={booksCount}
              stationeryCount={stationeryCount}
              viewMode={viewMode}
              onViewModeChange={setViewMode}
            />
          </div>

          {/* Mobile sidebar overlay */}
          {mobileFiltersOpen && (
            <div
              className="fixed inset-0 z-50 bg-primary-950/60 backdrop-blur-sm lg:hidden"
              onClick={() => setMobileFiltersOpen(false)}
            >
              <div
                className="absolute right-0 top-0 bottom-0 w-[90%] max-w-md bg-cream-50 overflow-y-auto shadow-2xl flex flex-col"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="sticky top-0 z-10 flex items-center justify-between px-5 py-4 bg-white/90 backdrop-blur border-b border-cream-200">
                  <div className="flex items-center gap-2">
                    <SlidersHorizontal className="w-5 h-5 text-primary-600" />
                    <h3 className="font-serif text-lg font-semibold text-primary-950">Filters</h3>
                    {activeFilterLabels.length > 0 && (
                      <Badge variant="primary" className="h-5 px-1.5 text-[10px]">
                        {activeFilterLabels.length}
                      </Badge>
                    )}
                  </div>
                  <button
                    onClick={() => setMobileFiltersOpen(false)}
                    className="w-9 h-9 rounded-full hover:bg-cream-100 flex items-center justify-center"
                    aria-label="Close filters"
                  >
                    <svg viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5 text-primary-800">
                      <path d="M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z" />
                    </svg>
                  </button>
                </div>
                <div className="p-5 flex-1 overflow-y-auto">
                  <BookFilters
                    categories={categories}
                    filters={filters}
                    onFilterChange={(f: BookFiltersType) => {
                      handleFilterChange(f)
                    }}
                    includeProductType={false}
                    availableCategories={availableCategories}
                    totalCount={total}
                    booksCount={booksCount}
                    stationeryCount={stationeryCount}
                    viewMode={viewMode}
                    onViewModeChange={setViewMode}
                  />
                </div>
                <div className="sticky bottom-0 bg-white/95 backdrop-blur border-t border-cream-200 p-4 flex gap-3">
                  <Button
                    variant="ghost"
                    className="flex-1"
                    onClick={clearAllFilters}
                  >
                    Reset
                  </Button>
                  <Button
                    variant="accent"
                    className="flex-1"
                    onClick={() => setMobileFiltersOpen(false)}
                  >
                    Show {total} results
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Product area */}
          <div className="space-y-8 min-w-0">
            {isLoading && products.length === 0 ? (
              <div className="pt-2">
                <Skeleton viewMode={viewMode} />
              </div>
            ) : products.length === 0 ? (
              <EmptyState
                variant="books"
                title="Nothing matched your filters"
                description="Try broadening your search, removing a category filter, or exploring our featured picks."
                action={{
                  label: 'Clear All Filters',
                  onClick: clearAllFilters,
                }}
              />
            ) : viewMode === 'grid' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5 sm:gap-6">
                {products.map(p => (
                  <BookCard key={String(p.id)} book={p} unified={tab !== 'books'} />
                ))}
              </div>
            ) : viewMode === 'list' ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-6">
                {products.map(p => (
                  <ListCard key={String(p.id)} product={p} />
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4">
                {products.map(p => (
                  <BookCard key={String(p.id)} book={p} unified={tab !== 'books'} />
                ))}
              </div>
            )}

            {totalPages > 1 && (
              <Pagination
                currentPage={filters.page || 1}
                totalPages={totalPages}
                onPageChange={(page) => {
                  handleFilterChange({ ...filters, page })
                  window.scrollTo({ top: 0, behavior: 'smooth' })
                }}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
