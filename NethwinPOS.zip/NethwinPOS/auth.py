from fastapi import APIRouter, HTTPException, Depends

from app.core.security import (
    fastapi_users,
    auth_backend,
    bearer_auth_backend,
    UserCreate,
    UserRead,
    UserUpdate,
    get_user_manager,
    get_jwt_strategy,
    user_to_response,
    current_user,
)
from app.models.user import User
from app.schemas import LoginRequest, RegisterRequest

auth_router = APIRouter()


@auth_router.post("/auth/login")
async def custom_login(
    data: LoginRequest,
    user_manager=Depends(get_user_manager),
):
    class _Creds:
        username: str
        password: str
        def __init__(self, username: str, password: str):
            self.username = username
            self.password = password

    credentials = _Creds(username=data.email, password=data.password)
    user = await user_manager.authenticate(credentials)
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="Invalid email or password")
    strategy = get_jwt_strategy()
    token = await strategy.write_token(user)
    return {
        "accessToken": token,
        "tokenType": "bearer",
        "user": user_to_response(user),
    }


@auth_router.post("/auth/register")
async def custom_register(
    data: RegisterRequest,
    user_manager=Depends(get_user_manager),
):
    parts = data.name.split(" ", 1)
    first_name = parts[0] if parts else ""
    last_name = parts[1] if len(parts) > 1 else None

    user_create = UserCreate(
        email=data.email,
        password=data.password,
        first_name=first_name,
        last_name=last_name,
    )
    user = await user_manager.create(user_create, safe=True)
    strategy = get_jwt_strategy()
    token = await strategy.write_token(user)
    return {
        "accessToken": token,
        "tokenType": "bearer",
        "user": user_to_response(user),
    }


@auth_router.get("/auth/me")
async def custom_me(user: User = Depends(current_user)):
    return user_to_response(user)


@auth_router.post("/auth/logout")
async def custom_logout():
    return {"detail": "Logged out successfully"}


auth_router.include_router(
    fastapi_users.get_auth_router(auth_backend, requires_verification=False),
    prefix="/auth",
    tags=["auth"],
)

auth_router.include_router(
    fastapi_users.get_auth_router(bearer_auth_backend, requires_verification=False),
    prefix="/auth/bearer",
    tags=["auth"],
)

auth_router.include_router(
    fastapi_users.get_register_router(UserRead, UserCreate),
    prefix="/auth/fastapi",
    tags=["auth"],
)

auth_router.include_router(
    fastapi_users.get_reset_password_router(),
    prefix="/auth",
    tags=["auth"],
)

auth_router.include_router(
    fastapi_users.get_verify_router(UserRead),
    prefix="/auth",
    tags=["auth"],
)

auth_router.include_router(
    fastapi_users.get_users_router(UserRead, UserUpdate, requires_verification=False),
    prefix="/auth/fastapi-users",
    tags=["auth"],
)
