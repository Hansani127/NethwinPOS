import { Link } from '../../utils/router-compat'

import { ArrowRight, Crown } from 'lucide-react'
import Button from '../common/Button'
import BookGrid from '../books/BookGrid'
import { useFeaturedBooks } from '../../hooks/useBooks'
import { useMemo } from 'react'
import type { Book } from '../../types'
import { cleanImageUrl } from '../../utils/imageUrl'

export default function FeaturedBooks() {
  const { data, isLoading, error } = useFeaturedBooks()

  const displayBooks = useMemo((): Book[] => {
    const apiBooks = data?.items || data?.data
    if (apiBooks && apiBooks.length > 0) return apiBooks.slice(0, 8)
    return Array.from({ length: 8 }, (_, i) => ({
      id: String(i + 1),
      title: [
        'The Silent Echo',
        'Whispers of the Past',
        'The Art of Stillness',
        'Lost in Translation',
        'Echoes of Eternity',
        'The Velvet Hour',
        'Paper Lanterns',
        'Atlas of Dreams',
      ][i],
      slug: 'book',
      author: [
        'Elena Hartwell',
        'Marcus Thorne',
        'Isabella Chen',
        'Dr. James Whitmore',
        'Aria Nightingale',
        'Thomas Blackwood',
        'Yuki Tanaka',
        'Sophia Laurent',
      ][i],
      description: 'A timeless tale of wonder and discovery.',
      price: [2490.00, 3250.00, 1800.00, 2990.00, 1950.00, 3800.00, 1550.00, 4500.00][i],
      coverImage: cleanImageUrl('', ['The Silent Echo', 'Whispers of the Past', 'The Art of Stillness', 'Lost in Translation', 'Echoes of Eternity', 'The Velvet Hour', 'Paper Lanterns', 'Atlas of Dreams'][i], 'book'),
      stock: 10,
      rating: [4.8, 4.6, 4.9, 4.7, 4.5, 4.9, 4.4, 4.8][i],
      reviewCount: [128, 342, 89, 215, 467, 73, 156, 98][i],
      isFeatured: true,
      categoryId: '1',
      authors: [],
      category_names: [],
      thumbnail: null,
      images: [],
      pages: 0,
      isbn: '',
    }))
  }, [data])

  return (
    <section className="py-20 sm:py-24 bg-cream-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary-50 border border-primary-100 text-primary-700 text-xs font-semibold uppercase tracking-wider mb-4">
              <Crown className="w-3.5 h-3.5 text-accent-600" />
              Hand-Picked For You
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-primary-950">
              Featured &amp; <span className="italic text-primary-700">Bestselling</span>
            </h2>
            <p className="mt-3 text-primary-800/70 max-w-xl">
              Our editors' most loved selections — from prize-winning fiction to rare collectibles.
            </p>
          </div>

          <Button
            asChild
            variant="outline"
            size="lg"
            className="w-full sm:w-auto rounded-full"
          >
            <Link href="/books">
              View All Books
              <ArrowRight className="w-4 h-4" />
            </Link>
          </Button>
        </div>

        <BookGrid books={displayBooks} isLoading={isLoading} error={error} columns={4} />
      </div>
    </section>
  )
}
