import { cn } from '../../utils/cn'
import { Loader2 } from 'lucide-react'

type Size = 'sm' | 'md' | 'lg' | 'xl'

interface LoadingSpinnerProps {
  size?: Size
  label?: string
  className?: string
}

const sizeMap: Record<Size, string> = {
  sm: 'w-5 h-5',
  md: 'w-8 h-8',
  lg: 'w-12 h-12',
  xl: 'w-16 h-16',
}

const labelSizeMap: Record<Size, string> = {
  sm: 'text-xs',
  md: 'text-sm',
  lg: 'text-base',
  xl: 'text-lg',
}

export default function LoadingSpinner({
  size = 'md',
  label,
  className,
}: LoadingSpinnerProps) {
  return (
    <div
      className={cn(
        'flex flex-col items-center justify-center gap-3',
        className,
      )}
      role="status"
      aria-label={label || 'Loading'}
    >
      <Loader2
        className={cn('animate-spin text-primary-600', sizeMap[size])}
      />
      {label && (
        <p className={cn('text-primary-700/80 font-medium', labelSizeMap[size])}>
          {label}
        </p>
      )}
      <span className="sr-only">Loading...</span>
    </div>
  )
}
