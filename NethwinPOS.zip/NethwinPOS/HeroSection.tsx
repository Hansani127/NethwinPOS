import { Link } from '../../utils/router-compat'

import { ArrowRight, BookOpen, Sparkles, Award } from 'lucide-react'
import Button from '../common/Button'
import { cleanImageUrl } from '../../utils/imageUrl'

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary-900 via-primary-800 to-primary-700" />
      <div
        className="absolute inset-0 opacity-30"
        style={{
          backgroundImage:
            'radial-gradient(circle at 20% 20%, rgba(251, 191, 36, 0.15) 0, transparent 40%), radial-gradient(circle at 80% 60%, rgba(165, 180, 252, 0.25) 0, transparent 45%)',
        }}
      />
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")",
        }}
      />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 sm:py-28 lg:py-36">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div className="space-y-8 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/15 text-cream-100 text-sm font-medium">
              <Sparkles className="w-4 h-4 text-accent-400" />
              Nethwin Printers (Pvt) Ltd. — Premium Publishing & Supplies
            </div>

            <div>
              <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-semibold tracking-tight text-white leading-[1.05]">
                Crafting Stories.
                <br />
                <span className="italic text-accent-400"> Printing </span>
                Excellence.
              </h1>
              <p className="mt-6 text-lg text-cream-200/90 leading-relaxed max-w-xl mx-auto lg:mx-0">
                Explore luxury publications, custom notebooks, stationery, and expert printing services by Nethwin Printers. We bring quality craftsmanship to every single sheet.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
              <Button
                asChild
                variant="accent"
                size="lg"
                className="w-full sm:w-auto rounded-full px-8 shadow-lg shadow-accent-500/25"
              >
                <Link href="/books">
                  Browse Catalog
                  <ArrowRight className="w-4.5 h-4.5" />
                </Link>
              </Button>
              <Button
                asChild
                variant="ghost"
                size="lg"
                className="w-full sm:w-auto rounded-full px-8 text-white border border-white/20 hover:bg-white/10 hover:text-white"
              >
                <Link href="/books?tab=stationery">
                  <BookOpen className="w-4.5 h-4.5" />
                  Stationery Store
                </Link>
              </Button>
            </div>

            <div className="flex items-center justify-center lg:justify-start gap-8 pt-4">
              <div className="flex items-center gap-2 text-cream-200/90">
                <Award className="w-5 h-5 text-accent-400" />
                <div>
                  <p className="text-sm font-semibold text-white">50K+</p>
                  <p className="text-xs text-cream-200/70">Happy Readers</p>
                </div>
              </div>
              <div className="h-10 w-px bg-white/15" />
              <div className="text-cream-200/90">
                <p className="text-sm font-semibold text-white">10,000+</p>
                <p className="text-xs text-cream-200/70">Curated Titles</p>
              </div>
              <div className="h-10 w-px bg-white/15 hidden sm:block" />
              <div className="text-cream-200/90 hidden sm:block">
                <p className="text-sm font-semibold text-white">Free</p>
                <p className="text-xs text-cream-200/70">Shipping Rs. 10,000+</p>
              </div>
            </div>
          </div>

          <div className="relative hidden lg:block">
            <div className="relative h-[500px] w-full">
              <div className="absolute top-8 right-8 w-64 h-96 rounded-2xl shadow-2xl shadow-primary-950/40 rotate-6 transition-transform duration-700 hover:rotate-3 hover:-translate-y-1 overflow-hidden">
                <img
                  src={cleanImageUrl('', 'classic book collection', 'book')}
                  alt="Classic book collection"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute top-24 left-4 w-56 h-80 rounded-2xl shadow-2xl shadow-primary-950/40 -rotate-6 transition-transform duration-700 hover:-rotate-3 hover:-translate-y-1 overflow-hidden">
                <img
                  src={cleanImageUrl('', 'cozy reading nook books', 'book')}
                  alt="Cozy reading nook books"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute bottom-0 left-24 w-60 h-84 rounded-2xl shadow-2xl shadow-primary-950/40 rotate-2 transition-transform duration-700 hover:rotate-0 hover:-translate-y-1 overflow-hidden">
                <img
                  src={cleanImageUrl('', 'rare first edition', 'book')}
                  alt="Rare first edition"
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="absolute bottom-8 right-0 bg-white rounded-2xl shadow-xl shadow-primary-950/30 p-4 w-64 rotate-3 transition-transform hover:-rotate-1">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-full bg-accent-100 flex items-center justify-center text-accent-700">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-primary-950 uppercase tracking-wider text-primary-800/60">
                      Editor's Pick
                    </p>
                    <p className="text-sm font-semibold text-primary-950">The Midnight Library</p>
                  </div>
                </div>
                <p className="text-xs text-primary-800/70">
                  "A stunning meditation on the lives we could have lived."
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="relative h-16 bg-gradient-to-b from-transparent to-cream-100" />
    </section>
  )
}
