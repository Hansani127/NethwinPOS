from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List, Union, Literal, Annotated
from datetime import datetime
from decimal import Decimal
from bson import ObjectId

from app.models.order import OrderStatus, PaymentStatus
from app.models.ledger import TransactionType
from app.models.preorder import PreOrderStatus


class LoginRequest(BaseModel):
    email: str
    password: str


class RegisterRequest(BaseModel):
    name: str
    email: str
    password: str


class CategoryBase(BaseModel):
    name: str
    slug: str
    description: Optional[str] = None
    parent_category: Optional[str] = None


class CategoryCreate(CategoryBase):
    pass


class CategoryUpdate(BaseModel):
    name: Optional[str] = None
    slug: Optional[str] = None
    description: Optional[str] = None
    parent_category: Optional[str] = None


class CategoryRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    slug: str
    description: Optional[str] = None
    parent_category: Optional[str] = None
    created_at: datetime
    imageUrl: Optional[str] = None


class BookBase(BaseModel):
    title: str
    subtitle: Optional[str] = None
    isbn13: Optional[str] = None
    isbn10: Optional[str] = None
    authors: List[str] = Field(default_factory=list)
    categories: List[str] = Field(default_factory=list)
    description: Optional[str] = None
    published_year: Optional[int] = None
    num_pages: Optional[int] = None
    average_rating: Optional[float] = None
    ratings_count: Optional[int] = None
    price: Decimal = Field(gt=0, max_digits=10, decimal_places=2)
    stock: int = Field(ge=0, default=0)
    thumbnail: Optional[str] = None
    images: List[str] = Field(default_factory=list)
    is_featured: bool = False
    is_active: bool = True
    is_preorder: bool = False
    preorder_release_date: Optional[datetime] = None


class BookCreate(BookBase):
    pass


class BookUpdate(BaseModel):
    title: Optional[str] = None
    subtitle: Optional[str] = None
    isbn13: Optional[str] = None
    isbn10: Optional[str] = None
    authors: Optional[List[str]] = None
    categories: Optional[List[str]] = None
    description: Optional[str] = None
    published_year: Optional[int] = None
    num_pages: Optional[int] = None
    average_rating: Optional[float] = None
    ratings_count: Optional[int] = None
    price: Optional[Decimal] = Field(default=None, gt=0, max_digits=10, decimal_places=2)
    stock: Optional[int] = Field(default=None, ge=0)
    thumbnail: Optional[str] = None
    images: Optional[List[str]] = None
    is_featured: Optional[bool] = None
    is_active: Optional[bool] = None
    is_preorder: Optional[bool] = None
    preorder_release_date: Optional[datetime] = None


class BookRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    title: str
    subtitle: Optional[str] = None
    isbn13: Optional[str] = None
    isbn10: Optional[str] = None
    authors: List[str] = Field(default_factory=list)
    category_names: List[str] = Field(default_factory=list)
    description: Optional[str] = None
    published_year: Optional[int] = None
    num_pages: Optional[int] = None
    average_rating: Optional[float] = None
    ratings_count: Optional[int] = None
    price: Decimal
    stock: int
    thumbnail: Optional[str] = None
    images: List[str] = Field(default_factory=list)
    is_featured: bool
    is_active: bool
    is_preorder: bool = False
    preorder_release_date: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime
    author: str = ""
    coverImage: Optional[str] = None
    rating: Optional[float] = None
    reviewCount: Optional[int] = None
    pages: Optional[int] = None
    isbn: Optional[str] = None
    slug: Optional[str] = None
    categoryId: Optional[str] = None
    productType: Literal["book"] = "book"


class PaginatedBooks(BaseModel):
    total: int
    page: int
    page_size: int
    pages: int
    items: List[BookRead]
    data: List[BookRead] = Field(default_factory=list)
    limit: int = 0
    totalPages: int = 0


class StationeryBase(BaseModel):
    sku: str
    name: str
    category: str
    price: Decimal = Field(gt=0, max_digits=10, decimal_places=2)
    stock: int = Field(ge=0, default=0)
    description: Optional[str] = None
    image: Optional[str] = None
    barcode: Optional[str] = None
    brand: Optional[str] = None
    is_active: bool = True
    is_featured: bool = False
    is_preorder: bool = False
    preorder_release_date: Optional[datetime] = None


class StationeryCreate(StationeryBase):
    pass


class StationeryUpdate(BaseModel):
    sku: Optional[str] = None
    name: Optional[str] = None
    category: Optional[str] = None
    price: Optional[Decimal] = Field(default=None, gt=0, max_digits=10, decimal_places=2)
    stock: Optional[int] = Field(default=None, ge=0)
    description: Optional[str] = None
    image: Optional[str] = None
    barcode: Optional[str] = None
    brand: Optional[str] = None
    is_active: Optional[bool] = None
    is_featured: Optional[bool] = None
    is_preorder: Optional[bool] = None
    preorder_release_date: Optional[datetime] = None


class StationeryRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    sku: str
    name: str
    category: str
    price: Decimal
    stock: int
    description: Optional[str] = None
    image: Optional[str] = None
    barcode: Optional[str] = None
    brand: Optional[str] = None
    is_active: bool
    is_featured: bool
    is_preorder: bool = False
    preorder_release_date: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime
    productType: Literal["stationery"] = "stationery"
    coverImage: Optional[str] = None
    rating: int = 0
    reviewCount: int = 0
    pages: Optional[int] = None
    isbn: str = ""
    slug: str = ""
    categoryId: str = ""
    author: str = ""
    title: str = ""
    thumbnail: Optional[str] = None


class PaginatedStationeries(BaseModel):
    total: int
    page: int
    page_size: int
    pages: int
    items: List[StationeryRead]
    data: List[StationeryRead] = Field(default_factory=list)
    limit: int = 0
    totalPages: int = 0


UnifiedProduct = Annotated[
    Union[BookRead, StationeryRead],
    Field(discriminator="productType"),
]


class CartItemBase(BaseModel):
    book_id: str
    quantity: int = Field(ge=1, default=1)


class CartItemCreate(CartItemBase):
    pass


class CartItemUpdate(BaseModel):
    quantity: int = Field(ge=1)


class CartItemRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    book_id: str
    quantity: int
    price_at_time: Decimal


class CartRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    user_id: str
    items: List[CartItemRead]
    created_at: datetime
    updated_at: datetime


class CartItemDetail(BaseModel):
    id: str
    book: BookRead
    quantity: int
    price_at_time: Decimal
    subtotal: Decimal


class CartDetail(BaseModel):
    id: str
    items: List[CartItemDetail]
    subtotal: Decimal
    tax: Decimal
    shipping: Decimal
    total: Decimal
    created_at: datetime
    updated_at: datetime


class ShippingAddressBase(BaseModel):
    name: str
    line1: str
    line2: Optional[str] = None
    city: str
    state: Optional[str] = None
    postal_code: str
    country: str
    phone: Optional[str] = None


class OrderItemRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    product_type: str = "book"
    title: str
    isbn: Optional[str] = None
    sku: Optional[str] = None
    quantity: int
    unit_price: Decimal
    subtotal: Decimal


class OrderItemCreate(BaseModel):
    product_type: Literal["book", "stationery"] = "book"
    product_id: str
    quantity: int = Field(ge=1, default=1)
    price_at_time: Optional[Decimal] = Field(default=None, gt=0, max_digits=10, decimal_places=2)


class OrderBase(BaseModel):
    shipping_address: Optional[ShippingAddressBase] = None
    notes: Optional[str] = None


class OrderCreate(OrderBase):
    redeem_points: int = 0
    items: Optional[List[OrderItemCreate]] = None


class OrderUpdateStatus(BaseModel):
    status: OrderStatus
    tracking_number: Optional[str] = None


class OrderRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    order_number: str
    items: List[OrderItemRead]
    subtotal: Decimal
    tax: Decimal
    shipping: Decimal
    redeem_points_applied: int = 0
    points_discount: Decimal = Decimal("0")
    points_earned: int = 0
    total: Decimal
    status: OrderStatus
    shipping_address: Optional[ShippingAddressBase] = None
    payment_status: PaymentStatus
    tracking_number: Optional[str] = None
    notes: Optional[str] = None
    source: str = "web"
    created_at: datetime
    updated_at: datetime
    paid_at: Optional[datetime] = None
    shipped_at: Optional[datetime] = None
    delivered_at: Optional[datetime] = None
    paymentMethod: str = "stripe"
    userId: Optional[str] = None
    address: Optional[ShippingAddressBase] = None


class PaginatedOrders(BaseModel):
    total: int
    page: int
    page_size: int
    pages: int
    items: List[OrderRead]
    data: List[OrderRead] = Field(default_factory=list)
    limit: int = 0
    totalPages: int = 0


class PointsTransactionRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    type: TransactionType
    points: int
    balance_after: int
    source: str
    description: Optional[str] = None
    created_at: datetime


class PaginatedPointsHistory(BaseModel):
    total: int
    page: int
    page_size: int
    pages: int
    items: List[PointsTransactionRead]
    data: List[PointsTransactionRead] = Field(default_factory=list)
    limit: int = 0
    totalPages: int = 0


class LoyaltyMeResponse(BaseModel):
    tier: str
    points: int
    total_spent: Decimal
    earned_total: int
    redeemed_total: int
    next_tier: Optional[str] = None
    points_to_next_tier: Optional[Decimal] = None
    tier_multiplier: float


class RedeemPreviewRequest(BaseModel):
    points: int
    order_subtotal: Decimal


class RedeemPreviewResponse(BaseModel):
    points_applied: int
    dollar_discount: Decimal
    max_allowed_points: int


class PreOrderCreate(BaseModel):
    product_type: Literal["book", "stationery"]
    product_id: str
    quantity: int = Field(ge=1)
    deposit_amount: Decimal = Field(default=Decimal("0"), ge=0, max_digits=10, decimal_places=2)
    customer_name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    shipping_address: Optional[ShippingAddressBase] = None
    notes: Optional[str] = None
    redeem_points: int = 0


class PreOrderUpdate(BaseModel):
    quantity: Optional[int] = Field(default=None, ge=1)
    deposit_amount: Optional[Decimal] = None
    customer_name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    shipping_address: Optional[ShippingAddressBase] = None
    notes: Optional[str] = None


class PreOrderStatusUpdate(BaseModel):
    status: PreOrderStatus
    tracking_number: Optional[str] = None


class PreOrderRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    user_id: Optional[str] = None
    product_type: str
    product_id: str
    quantity: int
    unit_price: Decimal
    deposit_amount: Decimal
    total_amount: Decimal
    amount_paid: Decimal
    status: PreOrderStatus
    release_date: Optional[datetime] = None
    customer_name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    shipping_address: Optional[ShippingAddressBase] = None
    order_number: str
    notes: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    expected_fulfillment_date: Optional[datetime] = None


class PaginatedPreOrders(BaseModel):
    total: int
    page: int
    page_size: int
    pages: int
    items: List[PreOrderRead]
    data: List[PreOrderRead] = Field(default_factory=list)
    limit: int = 0
    totalPages: int = 0


class PayDepositRequest(BaseModel):
    amount: Optional[Decimal] = None
    payment_token: Optional[str] = None


class CatalogSearchStats(BaseModel):
    books_count: int
    stationery_count: int
    categories_available: List[str]


class CatalogSearchResponse(BaseModel):
    total: int
    page: int
    page_size: int
    pages: int
    items: List[UnifiedProduct]
    data: List[UnifiedProduct] = Field(default_factory=list)
    limit: int = 0
    totalPages: int = 0
    stats: CatalogSearchStats


class POSLookupProductRequest(BaseModel):
    code: str


class POSLookupProductResponse(BaseModel):
    product: UnifiedProduct
    status: Literal["in_stock", "preorder", "out_of_stock"]


class POSCartItem(BaseModel):
    product_id: str
    product_type: Literal["book", "stationery"]
    qty: int = Field(ge=1)


class POSCartCalculateRequest(BaseModel):
    items: List[POSCartItem]
    user_email: Optional[str] = None
    redeem_points: int = 0


class POSCartItemValidated(BaseModel):
    product_id: str
    product_type: str
    qty: int
    title: str
    unit_price: Decimal
    subtotal: Decimal
    in_stock: bool


class POSCartCalculateResponse(BaseModel):
    items_validated: List[POSCartItemValidated]
    subtotal: Decimal
    tax: Decimal
    shipping: Decimal
    points_discount: Decimal
    total: Decimal
    loyalty_points_to_earn: int
    member_tier: Optional[str] = None
    member_points_balance: Optional[int] = None


class POSQuickPayRequest(BaseModel):
    items: List[POSCartItem]
    user_email: Optional[str] = None
    redeem_points: int = 0
    payment_method: Literal["cash", "card", "points"]
    cash_tendered: Optional[Decimal] = None
    cashier_notes: Optional[str] = None
    customer_name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None


class POSQuickPayResponse(BaseModel):
    order_number: str
    items: List[POSCartItemValidated]
    subtotal: Decimal
    tax: Decimal
    points_discount: Decimal
    total: Decimal
    change_due: Optional[Decimal] = None
    receipt_html: str
    member_points_earned: int = 0
    member_points_balance: Optional[int] = None
    status: OrderStatus
    source: str = "pos"


class UserProfileUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[str] = None


class UserRoleUpdate(BaseModel):
    is_superuser: bool


class UploadResponse(BaseModel):
    secure_url: str
    public_id: str


class CreatePaymentIntentRequest(BaseModel):
    order_id: Optional[str] = None
    amount: Optional[int] = None
    items: Optional[List[dict]] = None


class CreatePaymentIntentResponse(BaseModel):
    client_secret: str
    payment_intent_id: str


class PaginatedCategories(BaseModel):
    total: int
    page: int
    page_size: int
    pages: int
    items: List[CategoryRead]
    data: List[CategoryRead] = Field(default_factory=list)
    limit: int = 0
    totalPages: int = 0
