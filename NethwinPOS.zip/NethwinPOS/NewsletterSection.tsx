import { useState } from 'react'
import { Mail, Gift, Sparkles, ArrowRight } from 'lucide-react'
import Button from '../common/Button'
import Input from '../common/Input'
import { toast } from 'sonner'

export default function NewsletterSection() {
  const [email, setEmail] = useState('')

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    toast.success(`Subscribed ${email} — 15% off code sent to your inbox!`)
    setEmail('')
  }

  return (
    <section className="py-20 sm:py-24 bg-cream-100">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-cream-50 via-white to-primary-50 border border-cream-200 shadow-xl shadow-primary-950/[0.04] p-8 sm:p-12 lg:p-16">
          <div
            className="absolute -top-20 -right-20 w-80 h-80 rounded-full bg-accent-200/40 blur-3xl"
            aria-hidden
          />
          <div
            className="absolute -bottom-24 -left-20 w-80 h-80 rounded-full bg-primary-200/30 blur-3xl"
            aria-hidden
          />

          <div className="relative grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white border border-cream-200 shadow-sm text-xs font-semibold uppercase tracking-wider text-primary-700 mb-5">
                <Sparkles className="w-3.5 h-3.5 text-accent-600" />
                Join The Nethwin Circle
              </div>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-primary-950 leading-[1.1]">
                Get 15% off your <span className="italic text-primary-700">first</span> order.
              </h2>
              <p className="mt-5 text-primary-800/70 leading-relaxed max-w-lg">
                Subscribe to our weekly letter for new releases, author interviews, curated bundles, and
                members-only offers. One click, a lifetime of stories.
              </p>

              <ul className="mt-8 space-y-3">
                <li className="flex items-center gap-3 text-sm text-primary-900/80">
                  <div className="w-8 h-8 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center flex-shrink-0">
                    <Gift className="w-4 h-4" />
                  </div>
                  Exclusive 15% welcome discount on your first purchase
                </li>
                <li className="flex items-center gap-3 text-sm text-primary-900/80">
                  <div className="w-8 h-8 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center flex-shrink-0">
                    <Mail className="w-4 h-4" />
                  </div>
                  Weekly literary curations delivered straight to your inbox
                </li>
                <li className="flex items-center gap-3 text-sm text-primary-900/80">
                  <div className="w-8 h-8 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center flex-shrink-0">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  Early access to signed editions &amp; rare book drops
                </li>
              </ul>
            </div>

            <div>
              <form
                onSubmit={onSubmit}
                className="bg-white rounded-2xl border border-cream-200 shadow-sm p-6 sm:p-8 space-y-5"
              >
                <h3 className="font-serif text-2xl font-semibold text-primary-950">
                  Subscribe Now
                </h3>

                <Input
                  label="Email Address"
                  type="email"
                  required
                  placeholder="you@readingnook.com"
                  leftIcon={<Mail className="w-4 h-4" />}
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />

                <Button
                  type="submit"
                  variant="accent"
                  size="lg"
                  className="w-full gap-2 rounded-xl"
                >
                  Claim My 15% Off
                  <ArrowRight className="w-4.5 h-4.5" />
                </Button>

                <p className="text-xs text-center text-primary-800/60">
                  By subscribing, you agree to our{' '}
                  <a href="#" className="underline hover:text-primary-700">
                    Terms
                  </a>{' '}
                  &amp;{' '}
                  <a href="#" className="underline hover:text-primary-700">
                    Privacy Policy
                  </a>
                  . Unsubscribe anytime.
                </p>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
