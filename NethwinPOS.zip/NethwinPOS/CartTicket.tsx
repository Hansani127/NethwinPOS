import { Trash2, Coins, Calculator } from 'lucide-react'
import type { PosCartItem, PosCartTotals, PosPaymentMethod, User, MemberTier } from '../../types'
import { formatCurrency } from '../../utils/formatCurrency'
import { cleanImageUrl } from '../../utils/imageUrl'
import Badge from '../common/Badge'
import Button from '../common/Button'
import { QtyStepper } from './ProductTile'
import { cn } from '../../utils/cn'

const tierStyles: Record<MemberTier, { bg: string; text: string }> = {
  bronze: { bg: 'bg-orange-100 text-orange-800', text: 'Bronze' },
  silver: { bg: 'bg-slate-200 text-slate-800', text: 'Silver' },
  gold: { bg: 'bg-accent-100 text-accent-800', text: 'Gold' },
  platinum: { bg: 'bg-indigo-100 text-indigo-800', text: 'Platinum' },
}

interface CartTicketProps {
  items: PosCartItem[]
  onUpdateQty: (id: string, qty: number) => void
  onRemove: (id: string) => void
  onClear: () => void
  totals: PosCartTotals
  member: User | null
  pointsRedeemed: number
  maxPointsRedeemable: number
  onPointsChange: (points: number) => void
  paymentMethod: PosPaymentMethod | null
  onSelectMethod: (m: PosPaymentMethod) => void
  cashTendered: number
  onCashTendered: (v: number) => void
  onComplete: () => void
  orderNumber: string
  isProcessing: boolean
}

export default function CartTicket({
  items, onUpdateQty, onRemove, onClear, totals,
  member, pointsRedeemed, maxPointsRedeemable, onPointsChange,
  paymentMethod, onSelectMethod, cashTendered, onCashTendered, onComplete, orderNumber, isProcessing,
}: CartTicketProps) {
  const change = paymentMethod === 'cash' && cashTendered > 0 ? Math.max(0, cashTendered - totals.total) : 0
  const cashReady = paymentMethod === 'cash' ? cashTendered >= totals.total : true

  return (
    <div className="h-full flex flex-col bg-white rounded-2xl border border-cream-200 shadow-sm overflow-hidden">
      <div className="px-5 py-4 border-b border-cream-200 bg-gradient-to-r from-primary-900 to-primary-800 text-white">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-[10px] uppercase tracking-widest text-accent-400 font-semibold">Ticket</p>
            <p className="font-serif text-xl font-bold tabular-nums">#{orderNumber}</p>
          </div>
          {items.length > 0 && (
            <button
              onClick={onClear}
              className="text-xs text-cream-100/70 hover:text-white underline"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto">
        {items.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center p-8 text-center">
            <div className="w-28 h-28 mb-5 rounded-3xl bg-cream-100 border border-cream-200 flex items-center justify-center">
              <div className="w-16 h-20 rounded-xl bg-white border-2 border-dashed border-cream-300 flex items-center justify-center">
                <Calculator className="w-7 h-7 text-cream-400" />
              </div>
            </div>
            <h4 className="font-serif text-lg font-semibold text-primary-950 mb-1">Ticket is empty</h4>
            <p className="text-sm text-primary-800/60 max-w-[220px]">
              Scan barcodes, search, or tap products on the left to start adding items.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-cream-100">
            {items.map((it) => (
              <div key={it.id} className="p-3 hover:bg-cream-50/60">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg overflow-hidden bg-cream-100 border border-cream-200 flex-shrink-0">
                    <img
                      src={cleanImageUrl(it.thumbnail, it.name, it.productType)}
                      alt={it.name}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        ;(e.currentTarget as HTMLImageElement).src = cleanImageUrl('', it.name, it.productType)
                      }}
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-primary-950 text-sm line-clamp-1">{it.name}</p>
                    <p className="text-[10px] text-primary-800/50 font-mono">{it.sku}</p>
                    <div className="mt-1.5 flex items-center justify-between gap-2">
                      <QtyStepper qty={it.quantity} onChange={(q) => onUpdateQty(it.id, q)} />
                      <div className="text-right">
                        <p className="font-bold text-primary-900 tabular-nums text-sm">
                          {formatCurrency(it.price * it.quantity)}
                        </p>
                        <p className="text-[10px] text-primary-800/50 tabular-nums">
                          {formatCurrency(it.price)} ea
                        </p>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => onRemove(it.id)}
                    className="w-7 h-7 rounded-lg text-red-500 hover:bg-red-50 flex items-center justify-center flex-shrink-0"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {member && (
        <div className="px-4 py-3 border-t border-cream-200 bg-cream-50/60">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Badge className={cn(tierStyles[member.tier || 'bronze'].bg)}>
                {tierStyles[member.tier || 'bronze'].text}
              </Badge>
              <div>
                <p className="text-sm font-semibold text-primary-950">{member.name}</p>
                <p className="text-[11px] text-primary-800/60 flex items-center gap-1">
                  <Coins className="w-3 h-3 text-accent-600" />
                  {(member.points || 0).toLocaleString()} pts · ×{(member.tier === 'platinum' ? 2 : member.tier === 'gold' ? 1.5 : member.tier === 'silver' ? 1.25 : 1)}
                </p>
              </div>
            </div>
          </div>
          {maxPointsRedeemable > 0 && (
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="text-primary-800/70">Redeem Points</span>
                <span className="font-medium text-primary-900">
                  {pointsRedeemed.toLocaleString()} = {formatCurrency(pointsRedeemed / 100)}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min={0}
                  max={maxPointsRedeemable}
                  step={100}
                  value={pointsRedeemed}
                  onChange={(e) => onPointsChange(Number(e.target.value))}
                  className="flex-1 h-1.5 accent-accent-500"
                />
                <input
                  type="number"
                  min={0}
                  max={maxPointsRedeemable}
                  value={pointsRedeemed}
                  onChange={(e) => onPointsChange(Math.min(maxPointsRedeemable, Math.max(0, Number(e.target.value))))}
                  className="w-20 h-8 rounded-lg border border-cream-300 px-2 text-sm text-right tabular-nums focus:outline-none focus:ring-2 focus:ring-accent-500/30 focus:border-accent-500"
                />
              </div>
              <p className="text-[10px] text-primary-800/50 mt-1">Max: {maxPointsRedeemable.toLocaleString()} pts (50% of subtotal)</p>
            </div>
          )}
        </div>
      )}

      <div className="px-5 py-4 border-t border-cream-200 bg-cream-50 space-y-3">
        <div className="space-y-1.5 text-sm">
          <div className="flex justify-between text-primary-800/80">
            <span>Subtotal ({items.reduce((s, i) => s + i.quantity, 0)} items)</span>
            <span className="tabular-nums font-medium">{formatCurrency(totals.subtotal)}</span>
          </div>
          <div className="flex justify-between text-primary-800/80">
            <span>Tax (8%)</span>
            <span className="tabular-nums font-medium">{formatCurrency(totals.tax)}</span>
          </div>
          {totals.pointsDiscount > 0 && (
            <div className="flex justify-between text-accent-700">
              <span className="flex items-center gap-1"><Coins className="w-3.5 h-3.5" />Points Discount</span>
              <span className="tabular-nums font-medium">-{formatCurrency(totals.pointsDiscount)}</span>
            </div>
          )}
          <div className="flex justify-between items-end pt-2 mt-2 border-t border-cream-200">
            <div>
              <p className="text-[10px] uppercase tracking-wider text-primary-800/50 font-semibold">Total Due</p>
              {totals.pointsEarned > 0 && (
                <p className="text-[10px] text-accent-700 flex items-center gap-0.5 mt-0.5">
                  <Coins className="w-3 h-3" /> +{totals.pointsEarned.toLocaleString()} earned
                </p>
              )}
            </div>
            <p className="font-serif text-3xl font-bold text-primary-800 tabular-nums">
              {formatCurrency(totals.total)}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={() => onSelectMethod('cash')}
            className={cn(
              'flex flex-col items-center justify-center gap-1 h-14 rounded-xl border-2 transition-all',
              paymentMethod === 'cash'
                ? 'border-emerald-500 bg-emerald-50 text-emerald-800'
                : 'border-cream-200 bg-white hover:border-emerald-300 text-emerald-700',
            )}
          >
            <span className="text-xs font-bold uppercase">Cash</span>
          </button>
          <button
            onClick={() => onSelectMethod('card')}
            className={cn(
              'flex flex-col items-center justify-center gap-1 h-14 rounded-xl border-2 transition-all',
              paymentMethod === 'card'
                ? 'border-primary-600 bg-primary-50 text-primary-800'
                : 'border-cream-200 bg-white hover:border-primary-300 text-primary-700',
            )}
          >
            <span className="text-xs font-bold uppercase">Card</span>
          </button>
          <button
            onClick={() => onSelectMethod('points')}
            disabled={!member || (member.points || 0) < 100}
            className={cn(
              'flex flex-col items-center justify-center gap-1 h-14 rounded-xl border-2 transition-all disabled:opacity-40',
              paymentMethod === 'points'
                ? 'border-accent-500 bg-accent-50 text-accent-800'
                : 'border-cream-200 bg-white hover:border-accent-300 text-accent-700',
            )}
          >
            <span className="text-xs font-bold uppercase">Points</span>
          </button>
        </div>

        {paymentMethod === 'cash' && (
          <div className="p-3 rounded-xl bg-cream-100 border border-cream-200 space-y-2">
            <label className="block text-xs font-semibold text-primary-800/70 uppercase tracking-wider">
              Cash Tendered
            </label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                step="0.01"
                min={0}
                value={cashTendered || ''}
                placeholder="0.00"
                onChange={(e) => onCashTendered(Number(e.target.value))}
                className="flex-1 h-10 px-3 rounded-lg border border-cream-300 bg-white text-lg font-bold tabular-nums focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
              />
              {[20, 50, 100].map((denom) => (
                <button
                  key={denom}
                  onClick={() => onCashTendered(denom)}
                  className="h-10 px-3 rounded-lg bg-white border border-cream-300 text-xs font-semibold text-primary-800 hover:bg-cream-50"
                >
                  ${denom}
                </button>
              ))}
            </div>
            {change > 0 && (
              <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-center">
                <p className="text-[10px] uppercase tracking-wider text-emerald-700 font-semibold">Change Due</p>
                <p className="font-serif text-2xl font-bold text-emerald-800 tabular-nums">{formatCurrency(change)}</p>
              </div>
            )}
          </div>
        )}

        <Button
          variant="accent"
          size="lg"
          className="w-full rounded-xl h-14 text-lg gap-2 shadow-lg shadow-accent-500/30"
          onClick={onComplete}
          disabled={!paymentMethod || items.length === 0 || !cashReady || isProcessing}
          isLoading={isProcessing}
        >
          {!paymentMethod
            ? 'Select Payment Method'
            : items.length === 0
            ? 'Add Items First'
            : paymentMethod === 'cash' && cashTendered < totals.total
            ? `Need ${formatCurrency(totals.total - cashTendered)} More`
            : `Complete Payment · ${formatCurrency(totals.total)}`}
        </Button>
      </div>
    </div>
  )
}
