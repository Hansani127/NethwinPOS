import { Link } from '../../utils/router-compat'
import { useMemo } from 'react'
import { ArrowRight, Calendar, Sparkles } from 'lucide-react'
import { cleanImageUrl } from '../../utils/imageUrl'

import { useComingSoon } from '../../hooks/useBooks'
import BookCard from '../books/BookCard'
import Badge from '../common/Badge'
import type { CatalogProduct } from '../../types'
import LoadingSpinner from '../common/LoadingSpinner'

const DEMO_PREORDERS: CatalogProduct[] = [
  {
    id: 'pre-1', title: 'The Winds of Winter', author: 'George R.R. Martin', isbn: '9780553801478',
    price: 8500.00, coverImage: cleanImageUrl('', 'The Winds of Winter', 'book'),
    is_preorder: true, release_date: '2027-03-15', isFeatured: true, productType: 'book', rating: 0, reviewCount: 0,
    authors: [], category_names: ['Fantasy'], thumbnail: null, images: [], pages: 0, slug: '', categoryId: '5', stock: 0,
  } as any,
  {
    id: 'pre-2', title: 'Doors of Stone', author: 'Patrick Rothfuss', isbn: '9780756409433',
    price: 6800.00, coverImage: cleanImageUrl('', 'Doors of Stone', 'book'),
    is_preorder: true, release_date: '2026-11-01', productType: 'book', rating: 0, reviewCount: 0,
    authors: [], category_names: ['Fantasy'], thumbnail: null, images: [], pages: 0, slug: '', categoryId: '5', stock: 0,
  } as any,
  {
    id: 'pre-3', title: 'Nethwin 10th Anniversary Edition', author: 'Nethwin Press',
    price: 25000.00, coverImage: cleanImageUrl('', 'Nethwin 10th Anniversary Edition', 'book'),
    is_preorder: true, release_date: '2026-09-15', isFeatured: true, productType: 'book', rating: 0, reviewCount: 0,
    authors: [], category_names: ['Fiction'], thumbnail: null, images: [], pages: 0, slug: '', categoryId: '1', stock: 0, isbn: '',
  } as any,
  {
    id: 'pre-4', sku: 'ST-PRE-1', name: 'Nethwin Anniversary Brass Pen', category: 'Writing Instruments', brand: 'Nethwin',
    price: 48000.00, image: cleanImageUrl('', 'Nethwin Anniversary Brass Pen', 'stationery'),
    is_preorder: true, release_date: '2026-06-10', is_featured: true, productType: 'stationery', stock: 0,
  } as any,
  {
    id: 'pre-5', title: 'The Murakami Compendium', author: 'Haruki Murakami', isbn: '9781526680105',
    price: 14500.00, coverImage: cleanImageUrl('', 'The Murakami Compendium', 'book'),
    is_preorder: true, release_date: '2026-12-01', productType: 'book', rating: 0, reviewCount: 0,
    authors: [], category_names: ['Fiction'], thumbnail: null, images: [], pages: 0, slug: '', categoryId: '1', stock: 0,
  } as any,
  {
    id: 'pre-6', title: 'Brandon Sanderson: Stormlight #5', author: 'Brandon Sanderson', isbn: '9780765390004',
    price: 6500.00, coverImage: cleanImageUrl('', 'Brandon Sanderson: Stormlight #5', 'book'),
    is_preorder: true, release_date: '2026-05-20', productType: 'book', rating: 0, reviewCount: 0,
    authors: [], category_names: ['Fantasy'], thumbnail: null, images: [], pages: 0, slug: '', categoryId: '5', stock: 0,
  } as any,
  {
    id: 'pre-7', sku: 'ST-PRE-2', name: 'Midori Traveler\'s Passport', category: 'Notebooks', brand: 'Midori',
    price: 12800.00, image: cleanImageUrl('', 'Midori Traveler\'s Passport', 'stationery'),
    is_preorder: true, release_date: '2026-08-14', productType: 'stationery', stock: 0,
  } as any,
  {
    id: 'pre-8', title: 'The Testaments Deluxe', author: 'Margaret Atwood', isbn: '9780385543781',
    price: 11000.00, coverImage: cleanImageUrl('', 'The Testaments Deluxe', 'book'),
    is_preorder: true, release_date: '2026-04-30', productType: 'book', rating: 0, reviewCount: 0,
    authors: [], category_names: ['Fiction'], thumbnail: null, images: [], pages: 0, slug: '', categoryId: '1', stock: 0,
  } as any,
]

export default function PreorderSection() {
  const { data, isLoading } = useComingSoon()
  const items = useMemo(() => {
    const apiItems: CatalogProduct[] = Array.isArray(data) ? data : ((data as any)?.items || [])
    if (apiItems.length > 0) return apiItems
    return DEMO_PREORDERS
  }, [data])

  return (
    <section className="relative py-16 sm:py-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary-950 via-primary-900 to-primary-800" />
      <div
        className="absolute inset-0 opacity-30"
        style={{
          backgroundImage:
            'radial-gradient(circle at 10% 20%, rgba(251,191,36,0.15) 0, transparent 40%), radial-gradient(circle at 90% 80%, rgba(99,102,241,0.2) 0, transparent 50%)',
        }}
      />
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
          <div className="flex-1">
            <Badge className="mb-3 bg-accent-500/20 text-accent-300 border-accent-400/40 backdrop-blur">
              <Sparkles className="w-3 h-3 mr-1" />
              <span className="font-serif italic tracking-wide">COMING SOON</span>
            </Badge>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-white">
              Pre-Order <span className="italic text-accent-400">Now</span>
            </h2>
            <p className="mt-3 text-cream-100/70 max-w-xl text-base sm:text-lg">
              Secure the most anticipated releases, signed editions, and limited stationery drops before anyone else. Priority fulfillment on every pre-order.
            </p>
          </div>
          <Link href="/preorders"
            className="inline-flex items-center gap-2 h-11 px-5 rounded-xl bg-accent-500 text-primary-950 font-semibold hover:bg-accent-400 shadow-lg shadow-accent-500/20 transition-colors self-start md:self-end"
          >
            View All Pre-Orders
            <ArrowRight className="w-4.5 h-4.5" />
          </Link>
        </div>

        {isLoading && items.length === DEMO_PREORDERS.length ? (
          <div className="py-10"><LoadingSpinner label="Loading pre-releases..." /></div>
        ) : (
          <div className="overflow-x-auto -mx-4 sm:mx-0 pb-2">
            <div className="flex gap-5 px-4 sm:px-0 min-w-max sm:min-w-0 sm:grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
              {items.slice(0, 8).map(p => (
                <div key={String(p.id)} className="w-64 sm:w-auto">
                  <BookCard book={p} unified />
                </div>
              ))}
            </div>
          </div>
        )}

        <p className="mt-8 pt-6 border-t border-white/10 text-center text-xs text-cream-100/50 flex items-center justify-center gap-2">
          <Calendar className="w-3.5 h-3.5" />
          Release dates are estimated; you will only be charged when items are ready to ship.
        </p>
      </div>
    </section>
  )
}
