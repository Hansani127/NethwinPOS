import resend

from app.config import settings
from app.models.order import Order


def init_resend() -> None:
    resend.api_key = settings.RESEND_API_KEY


def _render_order_confirmation(order: Order) -> str:
    items_html = ""
    for item in order.items:
        items_html += f"""
        <tr>
            <td style="padding: 12px 8px; border-bottom: 1px solid #e5e7eb;">
                <div>
                    <div style="font-weight: 600; color: #111827;">{item.title}</div>
                    <div style="color: #6b7280; font-size: 13px;">ISBN: {item.isbn or 'N/A'}</div>
                </div>
            </td>
            <td style="padding: 12px 8px; text-align: center; border-bottom: 1px solid #e5e7eb;">{item.quantity}</td>
            <td style="padding: 12px 8px; text-align: right; border-bottom: 1px solid #e5e7eb;">${item.unit_price:.2f}</td>
            <td style="padding: 12px 8px; text-align: right; border-bottom: 1px solid #e5e7eb;">${item.subtotal:.2f}</td>
        </tr>
        """

    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Order Confirmation - {order.order_number}</title>
        <style>
            body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #f9fafb; margin: 0; padding: 0; }}
            .container {{ max-width: 600px; margin: 0 auto; padding: 24px; }}
            .header {{ background: #1e3a8a; color: white; padding: 32px; border-radius: 12px 12px 0 0; }}
            .header h1 {{ margin: 0; font-size: 24px; }}
            .header p {{ margin: 8px 0 0; opacity: 0.9; }}
            .body {{ background: white; padding: 32px; border-radius: 0 0 12px 12px; }}
            .info-grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 32px; }}
            .info-block h3 {{ margin: 0 0 8px; font-size: 14px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.05em; }}
            .info-block p {{ margin: 0; color: #111827; line-height: 1.6; }}
            table {{ width: 100%; border-collapse: collapse; margin-bottom: 24px; }}
            th {{ padding: 12px 8px; text-align: left; font-size: 13px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.05em; border-bottom: 2px solid #e5e7eb; }}
            .totals {{ margin-left: auto; width: 300px; }}
            .total-row {{ display: flex; justify-content: space-between; padding: 8px 0; }}
            .total-row.grand {{ border-top: 2px solid #111827; margin-top: 8px; padding-top: 16px; font-weight: 700; font-size: 18px; }}
            .footer {{ text-align: center; margin-top: 32px; color: #6b7280; font-size: 13px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Nethwin Bookshop</h1>
                <p>Thank you for your order!</p>
            </div>
            <div class="body">
                <div class="info-grid">
                    <div class="info-block">
                        <h3>Order Number</h3>
                        <p>{order.order_number}</p>
                        <h3 style="margin-top: 16px;">Order Date</h3>
                        <p>{order.created_at.strftime('%B %d, %Y')}</p>
                    </div>
                    <div class="info-block">
                        <h3>Shipping Address</h3>
                        <p>
                            {order.shipping_address.name}<br>
                            {order.shipping_address.line1}<br>
                            {order.shipping_address.line2 + '<br>' if order.shipping_address.line2 else ''}
                            {order.shipping_address.city}, {order.shipping_address.state or ''} {order.shipping_address.postal_code}<br>
                            {order.shipping_address.country}
                        </p>
                    </div>
                </div>

                <h3 style="margin: 0 0 16px; font-size: 18px;">Order Items</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Book</th>
                            <th style="text-align: center;">Qty</th>
                            <th style="text-align: right;">Price</th>
                            <th style="text-align: right;">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        {items_html}
                    </tbody>
                </table>

                <div class="totals">
                    <div class="total-row"><span>Subtotal</span><span>${order.subtotal:.2f}</span></div>
                    <div class="total-row"><span>Tax</span><span>${order.tax:.2f}</span></div>
                    <div class="total-row"><span>Shipping</span><span>${'FREE' if order.shipping == 0 else f'${order.shipping:.2f}'}</span></div>
                    <div class="total-row grand"><span>Total</span><span>${order.total:.2f}</span></div>
                </div>

                <div style="margin-top: 32px; padding: 16px; background: #f0fdf4; border-radius: 8px;">
                    <p style="margin: 0; color: #166534;"><strong>Status:</strong> {order.status.value.capitalize()}</p>
                </div>
            </div>
            <div class="footer">
                <p>&copy; 2024 Nethwin Bookshop. All rights reserved.</p>
            </div>
        </div>
    </body>
    </html>
    """
    return html


async def send_order_confirmation(order: Order) -> None:
    if not settings.RESEND_API_KEY:
        return
    init_resend()
    user_email = None
    try:
        from app.models.user import User
        if order.user_id:
            user = await User.get(str(order.user_id))
            if user:
                user_email = user.email
    except Exception:
        pass

    if not user_email:
        return

    html = _render_order_confirmation(order)
    try:
        resend.Emails.send({
            "from": settings.EMAIL_FROM,
            "to": user_email,
            "subject": f"Order Confirmation - {order.order_number}",
            "html": html,
        })
    except Exception:
        pass


async def send_email_task(to: str, subject: str, html: str) -> None:
    if not settings.RESEND_API_KEY:
        print(f"⚠️  [EMAIL] Skipped sending '{subject}' to {to}: RESEND_API_KEY not configured")
        return
    init_resend()
    try:
        resend.Emails.send({
            "from": settings.EMAIL_FROM,
            "to": to,
            "subject": subject,
            "html": html,
        })
    except Exception as e:
        print(f"❌ [EMAIL ERROR] Failed sending '{subject}' to {to}: {e}")
        import traceback
        traceback.print_exc()


async def send_password_reset(email: str, token: str) -> None:
    reset_url = f"{settings.FRONTEND_URL}/reset-password?token={token}"
    print("=" * 70)
    print("🔐 [PASSWORD RESET] Request received for:", email)
    print("🔗 Reset link:", reset_url)
    print("⏰ This link expires in 1 hour.")
    print("=" * 70)
    if not settings.RESEND_API_KEY:
        print("⚠️  [WARNING] RESEND_API_KEY is not set in .env - email not sent!")
        print("💡 Copy the reset link above into your browser to test the flow.")
        print("=" * 70)
        return
    html = f"""
    <!DOCTYPE html>
    <html>
    <head><title>Reset Your Password</title></head>
    <body style="font-family: sans-serif; padding: 32px; max-width: 500px; margin: 0 auto;">
        <h2>Nethwin Bookshop - Reset Password</h2>
        <p>We received a request to reset the password for {email}.</p>
        <p>Click the button below to reset your password:</p>
        <a href="{reset_url}" style="display: inline-block; padding: 12px 24px; background: #1e3a8a; color: white; text-decoration: none; border-radius: 8px;">Reset Password</a>
        <p style="margin-top: 24px; color: #6b7280;">If you didn't request this, please ignore this email. This link expires in 1 hour.</p>
    </body>
    </html>
    """
    try:
        await send_email_task(email, "Reset Your Password", html)
        print("✅ [EMAIL] Reset password email sent successfully to:", email)
    except Exception as e:
        print(f"❌ [EMAIL ERROR] Failed to send reset email to {email}: {e}")
        print(f"⚠️  You can still manually use this reset link: {reset_url}")


async def send_verification(email: str, token: str) -> None:
    if not settings.RESEND_API_KEY:
        return
    verify_url = f"{settings.FRONTEND_URL}/verify?token={token}"
    html = f"""
    <!DOCTYPE html>
    <html>
    <head><title>Verify Your Email</title></head>
    <body style="font-family: sans-serif; padding: 32px; max-width: 500px; margin: 0 auto;">
        <h2>Welcome to Nethwin Bookshop!</h2>
        <p>Please verify your email address to get started.</p>
        <a href="{verify_url}" style="display: inline-block; padding: 12px 24px; background: #1e3a8a; color: white; text-decoration: none; border-radius: 8px;">Verify Email</a>
        <p style="margin-top: 24px; color: #6b7280;">If you didn't create an account, please ignore this email.</p>
    </body>
    </html>
    """
    await send_email_task(email, "Verify Your Email", html)
