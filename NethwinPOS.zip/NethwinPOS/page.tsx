"use client";

import { Link, useNavigate, useSearchParams } from '../../utils/router-compat'
import { useState, useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { BookOpen, Lock, Eye, EyeOff, ArrowRight, ArrowLeft, Sparkles, CheckCircle2 } from 'lucide-react'
import Input from '../../components/common/Input'
import Button from '../../components/common/Button'
import { useAuthStore } from '../../store/authStore'
import { toast } from 'sonner'

const resetPasswordSchema = z
  .object({
    password: z.string().min(8, 'Password must be at least 8 characters'),
    confirmPassword: z.string(),
  })
  .refine((d) => d.password === d.confirmPassword, {
    message: 'Passwords do not match',
    path: ['confirmPassword'],
  })

type ResetPasswordForm = z.infer<typeof resetPasswordSchema>

export default function Page() {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const token = searchParams.get('token')
  const [showPwd, setShowPwd] = useState(false)
  const [showConfirmPwd, setShowConfirmPwd] = useState(false)
  const [completed, setCompleted] = useState(false)
  const [invalidToken, setInvalidToken] = useState(false)
  const resetPassword = useAuthStore((s) => s.resetPassword)

  useEffect(() => {
    if (!token) {
      setInvalidToken(true)
    }
  }, [token])

  const form = useForm<ResetPasswordForm>({
    resolver: zodResolver(resetPasswordSchema),
    defaultValues: { password: '', confirmPassword: '' },
    mode: 'onTouched',
  })

  const onSubmit = async (data: ResetPasswordForm) => {
    if (!token) {
      toast.error('Invalid or missing reset token')
      return
    }
    try {
      await resetPassword({ token, password: data.password })
      setCompleted(true)
      toast.success('Password reset successful! You can now sign in.')
    } catch (err: any) {
      const msg = err?.response?.data?.detail || 'Failed to reset password. The link may be expired or invalid.'
      toast.error(msg)
    }
  }

  if (invalidToken) {
    return (
      <div className="min-h-[calc(100vh-5rem)] bg-cream-100 flex items-center justify-center px-4 sm:px-6 lg:px-8 py-16">
        <div className="w-full max-w-lg rounded-3xl overflow-hidden bg-white shadow-2xl shadow-primary-950/[0.06] border border-cream-200 p-10">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center">
              <Lock className="w-10 h-10 text-red-600" />
            </div>
          </div>
          <h2 className="font-serif text-3xl font-semibold text-primary-950 text-center mb-3">
            Invalid Reset Link
          </h2>
          <p className="text-sm text-primary-800/70 text-center mb-8 leading-relaxed">
            This password reset link is invalid or has expired. Please request a new reset link.
          </p>
          <div className="space-y-3">
            <Button
              variant="accent"
              size="lg"
              className="w-full gap-2 rounded-xl"
              onClick={() => navigate('/forgot-password')}
            >
              Request New Reset Link
            </Button>
            <Button
              variant="ghost"
              size="lg"
              className="w-full gap-2 rounded-xl"
              onClick={() => navigate('/auth')}
            >
              <ArrowLeft className="w-4.5 h-4.5" />
              Back to Sign In
            </Button>
          </div>
        </div>
      </div>
    )
  }

  if (completed) {
    return (
      <div className="min-h-[calc(100vh-5rem)] bg-cream-100 flex items-center justify-center px-4 sm:px-6 lg:px-8 py-16">
        <div className="w-full max-w-lg rounded-3xl overflow-hidden bg-white shadow-2xl shadow-primary-950/[0.06] border border-cream-200 p-10">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center">
              <CheckCircle2 className="w-10 h-10 text-green-600" />
            </div>
          </div>
          <h2 className="font-serif text-3xl font-semibold text-primary-950 text-center mb-3">
            Password Reset Successful!
          </h2>
          <p className="text-sm text-primary-800/70 text-center mb-8 leading-relaxed">
            Your password has been updated successfully. You can now sign in to your Nethwin account with your new password.
          </p>
          <div className="space-y-3">
            <Button
              variant="accent"
              size="lg"
              className="w-full gap-2 rounded-xl"
              onClick={() => navigate('/auth')}
            >
              Sign In with New Password
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-[calc(100vh-5rem)] bg-cream-100 flex">
      <div className="flex-1 flex items-center justify-center px-4 sm:px-6 lg:px-8 py-16">
        <div className="w-full max-w-5xl grid lg:grid-cols-2 rounded-3xl overflow-hidden bg-white shadow-2xl shadow-primary-950/[0.06] border border-cream-200">
          <div className="relative hidden lg:flex items-end p-10 bg-gradient-to-br from-primary-800 via-primary-700 to-primary-600 text-white overflow-hidden">
            <div
              className="absolute inset-0 opacity-30"
              style={{
                backgroundImage:
                  'radial-gradient(circle at 20% 30%, rgba(251, 191, 36, 0.3) 0, transparent 45%), radial-gradient(circle at 80% 70%, rgba(165, 180, 252, 0.35) 0, transparent 45%)',
              }}
            />
            <div
              className="absolute inset-0 opacity-10"
              style={{
                backgroundImage:
                  "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")",
              }}
            />
            <div className="relative z-10 max-w-sm">
              <Link href="/" className="inline-flex items-center gap-2 mb-8">
                <BookOpen className="w-8 h-8 text-accent-400" />
                <span className="font-serif text-2xl font-semibold">
                  <span className="text-accent-400">N</span>ethwin
                </span>
              </Link>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 border border-white/15 text-cream-100 text-xs font-semibold uppercase tracking-wider mb-5">
                <Sparkles className="w-3.5 h-3.5 text-accent-400" />
                Set New Password
              </div>
              <h2 className="font-serif text-4xl font-semibold tracking-tight mb-4 leading-tight">
                Create a <span className="italic text-accent-400">strong</span> password
              </h2>
              <p className="text-cream-100/85 leading-relaxed mb-8">
                Choose a secure password that you haven't used elsewhere to keep your Nethwin account and personal information safe.
              </p>
              <ul className="space-y-3 text-sm text-cream-100/90">
                {[
                  'At least 8 characters long',
                  'Mix of uppercase & lowercase',
                  'Include numbers or symbols',
                  'Avoid common words or patterns',
                ].map((t, i) => (
                  <li key={i} className="flex items-center gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-accent-400/20 border border-accent-400/40 flex items-center justify-center flex-shrink-0 text-[10px]">
                      ✓
                    </span>
                    {t}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="p-8 sm:p-10 lg:p-12">
            <div className="mb-8 flex items-center lg:hidden">
              <Link href="/" className="inline-flex items-center gap-2">
                <BookOpen className="w-7 h-7 text-primary-700" />
                <span className="font-serif text-xl font-semibold text-primary-950">
                  <span className="text-accent-600">N</span>ethwin Bookshop
                </span>
              </Link>
            </div>

            <button
              type="button"
              onClick={() => navigate('/auth')}
              className="inline-flex items-center gap-1.5 text-sm font-medium text-primary-700 hover:text-primary-900 mb-8 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Sign In
            </button>

            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div>
                <h3 className="font-serif text-2xl font-semibold text-primary-950 mb-1">
                  Reset your password
                </h3>
                <p className="text-sm text-primary-800/70">
                  Enter your new password below.
                </p>
              </div>

              <div className="relative">
                <Input
                  label="New Password"
                  type={showPwd ? 'text' : 'password'}
                  leftIcon={<Lock className="w-4 h-4" />}
                  placeholder="At least 8 characters"
                  rightIcon={
                    <button
                      type="button"
                      onClick={() => setShowPwd((v) => !v)}
                      className="text-primary-900/50 hover:text-primary-800"
                      tabIndex={-1}
                    >
                      {showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  }
                  error={form.formState.errors.password?.message}
                  {...form.register('password')}
                />
              </div>

              <div className="relative">
                <Input
                  label="Confirm New Password"
                  type={showConfirmPwd ? 'text' : 'password'}
                  leftIcon={<Lock className="w-4 h-4" />}
                  placeholder="Repeat new password"
                  rightIcon={
                    <button
                      type="button"
                      onClick={() => setShowConfirmPwd((v) => !v)}
                      className="text-primary-900/50 hover:text-primary-800"
                      tabIndex={-1}
                    >
                      {showConfirmPwd ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </button>
                  }
                  error={form.formState.errors.confirmPassword?.message}
                  {...form.register('confirmPassword')}
                />
              </div>

              <Button
                type="submit"
                variant="accent"
                size="lg"
                className="w-full gap-2 rounded-xl"
                isLoading={form.formState.isSubmitting || useAuthStore.getState().isLoading}
              >
                Reset Password
                <ArrowRight className="w-4.5 h-4.5" />
              </Button>

              <p className="text-sm text-center text-primary-800/70">
                Didn't request this?{' '}
                <button
                  type="button"
                  onClick={() => navigate('/auth')}
                  className="font-semibold text-primary-700 hover:text-primary-900"
                >
                  Sign in
                </button>
              </p>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
