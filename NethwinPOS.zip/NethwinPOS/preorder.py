from beanie import Document, Link
from datetime import datetime
from typing import Optional, Any
from pydantic import BaseModel, Field, field_validator
from decimal import Decimal
from enum import Enum
from bson import Decimal128

from app.models.user import User
from app.models.order import ShippingAddress


def _to_decimal(v: Any) -> Any:
    if isinstance(v, Decimal128):
        return v.to_decimal()
    return v


class PreOrderStatus(str, Enum):
    RESERVED = "reserved"
    DEPOSIT_PAID = "deposit_paid"
    FULLY_PAID = "fully_paid"
    RELEASED_SHIPPED = "released_shipped"
    CANCELLED = "cancelled"


class PreOrder(Document):
    user_id: Optional[Link[User]] = None
    product_type: str
    product_id: str
    quantity: int = Field(ge=1)
    unit_price: Decimal = Field(gt=0, max_digits=10, decimal_places=2)
    deposit_amount: Decimal = Field(default=Decimal("0"), ge=0, max_digits=10, decimal_places=2)
    total_amount: Decimal = Field(gt=0, max_digits=10, decimal_places=2)
    amount_paid: Decimal = Field(default=Decimal("0"), ge=0, max_digits=10, decimal_places=2)
    status: PreOrderStatus = PreOrderStatus.RESERVED
    release_date: Optional[datetime] = None
    customer_name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    shipping_address: Optional[ShippingAddress] = None
    order_number: str
    notes: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    expected_fulfillment_date: Optional[datetime] = None

    class Settings:
        name = "preorders"

    @field_validator(
        "unit_price",
        "deposit_amount",
        "total_amount",
        "amount_paid",
        mode="before",
    )
    @classmethod
    def _preorder_decimals(cls, v: Any) -> Any:
        return _to_decimal(v)
