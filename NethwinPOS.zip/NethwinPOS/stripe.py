from fastapi import APIRouter, HTTPException, Depends, Request
from datetime import datetime
from decimal import Decimal
from bson import ObjectId

from app.config import settings
from app.core.security import current_user, current_superuser
from app.models.user import User
from app.models.order import Order, OrderStatus, PaymentStatus
from app.models.book import Book
from app.models.stationery import Stationery
from app.models.ledger import PointsTransaction, TransactionType
from app.services import (
    tier_from_spent,
    points_earned_for,
)
from app.schemas import (
    CreatePaymentIntentRequest,
    CreatePaymentIntentResponse,
)
from app.services import (
    create_payment_intent as stripe_create_pi,
    create_payment_intent_from_amount,
    construct_webhook_event,
    verify_payment,
    calculate_totals,
    send_order_confirmation,
)

router = APIRouter(prefix="/stripe", tags=["stripe"])


@router.post("/create-payment-intent", response_model=CreatePaymentIntentResponse)
async def create_payment_intent(
    data: CreatePaymentIntentRequest,
    user: User = Depends(current_user),
):
    order = None
    if data.order_id:
        order = await Order.get(data.order_id)
        if not order:
            raise HTTPException(status_code=404, detail="Order not found")

        user_oid = ObjectId(user.id)
        order_user_oid = None
        if order.user_id:
            if hasattr(order.user_id, "id"):
                order_user_oid = ObjectId(str(order.user_id.id))
            else:
                order_user_oid = ObjectId(str(order.user_id))
        if order_user_oid != user_oid and not user.is_superuser:
            raise HTTPException(status_code=403, detail="Forbidden")

        if order.payment_status == PaymentStatus.PAID:
            raise HTTPException(status_code=400, detail="Order already paid")

        client_secret, pi_id = await stripe_create_pi(order)
        order.payment_intent_id = pi_id
        await order.save()
        return CreatePaymentIntentResponse(client_secret=client_secret, payment_intent_id=pi_id)

    elif data.amount and data.items:
        amount_cents = data.amount
        client_secret, pi_id = await create_payment_intent_from_amount(amount_cents)
        return CreatePaymentIntentResponse(client_secret=client_secret, payment_intent_id=pi_id)

    else:
        raise HTTPException(status_code=400, detail="Provide order_id or amount+items")


async def deduct_stock_for_order(order: Order):
    for item in order.items:
        if getattr(item, "product_type", "book") == "stationery" and item.stationery_id:
            s_oid = ObjectId(str(item.stationery_id.id)) if hasattr(item.stationery_id, "id") else ObjectId(str(item.stationery_id))
            s = await Stationery.get(str(s_oid))
            if s and not s.is_preorder:
                s.stock = max(0, s.stock - item.quantity)
                s.updated_at = datetime.utcnow()
                await s.save()
        elif item.book_id:
            book_oid = ObjectId(str(item.book_id.id)) if hasattr(item.book_id, "id") else ObjectId(str(item.book_id))
            b = await Book.get(str(book_oid))
            if b and not b.is_preorder:
                b.stock = max(0, b.stock - item.quantity)
                b.updated_at = datetime.utcnow()
                await b.save()


async def award_loyalty_for_order(order: Order):
    user_oid = None
    if order.user_id:
        if hasattr(order.user_id, "id"):
            user_oid = ObjectId(str(order.user_id.id))
        else:
            user_oid = ObjectId(str(order.user_id))
    if user_oid is None:
        return
    u = await User.get(str(user_oid))
    if not u:
        return
    tier = tier_from_spent(u.total_spent)
    earned = points_earned_for(order.total, tier)
    if earned > 0:
        u.loyalty_points += earned
        u.points_earned_total += earned
    u.total_spent = (u.total_spent + order.total).quantize(Decimal("0.01"))
    new_tier = tier_from_spent(u.total_spent)
    u.membership_tier = new_tier
    await u.save()
    order.points_earned = earned
    await order.save()
    if earned > 0:
        tx = PointsTransaction(
            user_id=user_oid,
            type=TransactionType.EARN,
            points=earned,
            balance_after=u.loyalty_points,
            source=f"order:{order.order_number}",
            description=f"Points earned from order {order.order_number}",
        )
        await tx.insert()


@router.post("/webhook")
async def stripe_webhook(request: Request):
    if not settings.STRIPE_WEBHOOK_SECRET:
        raise HTTPException(status_code=400, detail="Webhook not configured")

    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")

    if not sig_header:
        raise HTTPException(status_code=400, detail="Missing signature")

    event = construct_webhook_event(payload, sig_header, settings.STRIPE_WEBHOOK_SECRET)
    if event is None:
        raise HTTPException(status_code=400, detail="Invalid webhook signature")

    if event["type"] == "payment_intent.succeeded":
        pi = event["data"]["object"]
        pi_id = pi["id"]
        order = await Order.find_one(Order.payment_intent_id == pi_id)
        if order and order.payment_status != PaymentStatus.PAID:
            order.payment_status = PaymentStatus.PAID
            order.status = OrderStatus.PAID
            order.paid_at = datetime.utcnow()
            order.updated_at = datetime.utcnow()
            await deduct_stock_for_order(order)
            await order.save()
            await award_loyalty_for_order(order)
            await send_order_confirmation(order)

    elif event["type"] == "payment_intent.payment_failed":
        pi = event["data"]["object"]
        pi_id = pi["id"]
        order = await Order.find_one(Order.payment_intent_id == pi_id)
        if order:
            order.payment_status = PaymentStatus.FAILED
            order.updated_at = datetime.utcnow()
            await order.save()

    elif event["type"] == "charge.refunded":
        charge = event["data"]["object"]
        pi_id = charge.get("payment_intent")
        if pi_id:
            order = await Order.find_one(Order.payment_intent_id == pi_id)
            if order:
                order.payment_status = PaymentStatus.REFUNDED
                order.status = OrderStatus.CANCELLED
                order.updated_at = datetime.utcnow()
                await order.save()

    return {"status": "success"}
