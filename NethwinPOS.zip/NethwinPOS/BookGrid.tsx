import type { Book } from '../../types'
import BookCard from './BookCard'
import LoadingSpinner from '../common/LoadingSpinner'
import EmptyState from '../common/EmptyState'

interface BookGridProps {
  books?: Book[]
  isLoading?: boolean
  error?: unknown
  columns?: 2 | 3 | 4 | 5
}

const colsMap = {
  2: 'grid-cols-2',
  3: 'grid-cols-2 md:grid-cols-3',
  4: 'grid-cols-2 md:grid-cols-3 lg:grid-cols-4',
  5: 'grid-cols-2 md:grid-cols-4 xl:grid-cols-5',
}

export default function BookGrid({
  books,
  isLoading,
  error,
  columns = 4,
}: BookGridProps) {
  if (isLoading) {
    return (
      <div className="py-16">
        <LoadingSpinner size="lg" label="Loading books..." />
      </div>
    )
  }

  if (error) {
    return (
      <div className="py-16">
        <EmptyState
          variant="general"
          title="Something went wrong"
          description="We couldn't load the books right now. Please try again in a moment."
          action={{ label: 'Retry', onClick: () => window.location.reload() }}
        />
      </div>
    )
  }

  if (!books || books.length === 0) {
    return (
      <EmptyState
        variant="books"
        title="No books found"
        description="Try adjusting your filters or search terms to discover more titles."
        action={{
          label: 'Browse All Books',
          onClick: () => (window.location.href = '/books'),
        }}
      />
    )
  }

  return (
    <div className={`grid gap-5 sm:gap-6 ${colsMap[columns]}`}>
      {books.map((book) => (
        <BookCard key={book.id} book={book} />
      ))}
    </div>
  )
}
