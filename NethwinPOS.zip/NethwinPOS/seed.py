import asyncio
import csv
import random
from decimal import Decimal
from pathlib import Path
import sys

from pymongo.errors import DuplicateKeyError

sys.path.insert(0, str(Path(__file__).parent))

from app.database import init_db, get_database
from app.models.book import Book
from app.models.stationery import Stationery
from app.models.category import Category


async def import_categories() -> dict[str, Category]:
    category_map: dict[str, Category] = {}
    return category_map


def slugify(name: str) -> str:
    import re
    s = name.lower().strip()
    s = re.sub(r"[^a-z0-9]+", "-", s)
    s = s.strip("-")
    return s


async def seed_books(category_map: dict[str, Category]) -> tuple[int, int]:
    project_root = Path(__file__).resolve().parents[2]
    csv_path = project_root / "Data Sheets" / "data.csv"
    if not csv_path.exists():
        print(f"Books CSV not found at {csv_path}")
        return 0, 0

    books_created = 0
    books_skipped = 0

    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    total_rows = len(rows)
    print(f"Found {total_rows} book rows in CSV. Processing...")

    csv_isbns: list[str] = []
    for row in rows:
        isbn13 = row.get("isbn13", "").strip()
        if isbn13:
            csv_isbns.append(isbn13)

    from beanie.odm.operators.find.comparison import In

    existing_isbns: set[str] = set()
    if csv_isbns:
        existing_cursor = Book.find(In(Book.isbn13, list(set(csv_isbns))), projection_model=Book)
        async for b in existing_cursor:
            if b.isbn13:
                existing_isbns.add(b.isbn13)
    print(f"Found {len(existing_isbns)} existing books in DB (by ISBN). Skip-checks O(1).")

    for idx, row in enumerate(rows, 1):
        isbn13 = row.get("isbn13", "").strip()
        if not isbn13:
            books_skipped += 1
            continue

        if isbn13 in existing_isbns:
            books_skipped += 1
            continue

        title = row.get("title", "").strip()
        if not title:
            books_skipped += 1
            continue

        subtitle = row.get("subtitle") or None
        isbn10 = row.get("isbn10") or None

        authors_str = row.get("authors", "")
        authors = [a.strip() for a in authors_str.split(";") if a.strip()] if authors_str else []

        categories_str = row.get("categories", "")
        category_names = [c.strip() for c in categories_str.split(";") if c.strip()] if categories_str else []

        category_refs = []
        resolved_names = []
        for cat_name in category_names:
            slug = slugify(cat_name)
            if slug in category_map:
                cat = category_map[slug]
            else:
                cat = await Category.find_one(Category.slug == slug)
                if not cat:
                    cat = Category(name=cat_name, slug=slug, description=None)
                    await cat.insert()
                category_map[slug] = cat
            category_refs.append(cat)
            resolved_names.append(cat_name)

        thumbnail = row.get("thumbnail") or None
        description = row.get("description") or None

        published_year = None
        try:
            py = row.get("published_year")
            if py:
                published_year = int(float(py))
        except (ValueError, TypeError):
            pass

        average_rating = None
        try:
            ar = row.get("average_rating")
            if ar:
                average_rating = float(ar)
        except (ValueError, TypeError):
            pass

        num_pages = None
        try:
            np = row.get("num_pages")
            if np:
                num_pages = int(float(np))
        except (ValueError, TypeError):
            pass

        ratings_count = None
        try:
            rc = row.get("ratings_count")
            if rc:
                ratings_count = int(float(rc))
        except (ValueError, TypeError):
            pass

        price = Decimal(str(round(random.uniform(950.0, 4500.0) / 50) * 50))
        stock = random.randint(5, 200)

        images = [thumbnail] if thumbnail else []

        book = Book(
            title=title,
            subtitle=subtitle,
            isbn13=isbn13,
            isbn10=isbn10,
            authors=authors,
            categories=category_refs,
            category_names=resolved_names,
            description=description,
            published_year=published_year,
            num_pages=num_pages,
            average_rating=average_rating,
            ratings_count=ratings_count,
            price=price,
            stock=stock,
            thumbnail=thumbnail,
            images=images,
            is_featured=random.random() < 0.1,
            is_active=True,
        )
        try:
            await book.insert()
            books_created += 1
            existing_isbns.add(isbn13)
        except DuplicateKeyError:
            books_skipped += 1
            existing_isbns.add(isbn13)

        if idx % 1000 == 0:
            print(f"  Books: {idx}/{total_rows}... (created: {books_created}, skipped: {books_skipped})")

    return books_created, books_skipped


async def seed_stationery() -> tuple[int, int]:
    project_root = Path(__file__).resolve().parents[2]
    csv_path = project_root / "Data Sheets" / "school_supplies_inventory.csv"
    if not csv_path.exists():
        print(f"Stationery CSV not found at {csv_path}")
        return 0, 0

    stat_created = 0
    stat_skipped = 0

    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    total_rows = len(rows)
    print(f"Found {total_rows} stationery rows in CSV. Processing...")

    for idx, row in enumerate(rows, 1):
        sku = row.get("Item_ID", "").strip()
        if not sku:
            stat_skipped += 1
            continue

        existing = await Stationery.find_one(Stationery.sku == sku)
        if existing:
            stat_skipped += 1
            continue

        name = row.get("Item_Name", "").strip()
        if not name:
            stat_skipped += 1
            continue

        category = row.get("Category", "").strip() or "General"
        price_str = row.get("Price_USD", "0").strip()
        stock_str = row.get("Stock_Quantity", "0").strip()

        try:
            price = Decimal(str(round((float(price_str) * 300.0) / 10) * 10))
            if price <= Decimal("0"):
                price = Decimal("150.00")
        except (ValueError, TypeError):
            price = Decimal("150.00")

        try:
            stock = max(0, int(float(stock_str)))
        except (ValueError, TypeError):
            stock = 0

        s = Stationery(
            sku=sku,
            name=name,
            category=category,
            price=price,
            stock=stock,
            description=None,
            image=None,
            barcode=None,
            brand=None,
            is_active=True,
            is_featured=random.random() < 0.05,
            is_preorder=False,
            preorder_release_date=None,
        )
        await s.insert()
        stat_created += 1

        if idx % 100 == 0:
            print(f"  Stationery: {idx}/{total_rows}... (created: {stat_created}, skipped: {stat_skipped})")

    return stat_created, stat_skipped


async def seed_users() -> tuple[int, int]:
    from app.models.user import User
    from fastapi_users.password import PasswordHelper

    password_helper = PasswordHelper()

    users_to_seed = [
        {
            "email": "admin@nethwin.com",
            "password": "AdminPassword123!",
            "first_name": "Admin",
            "last_name": "User",
            "is_superuser": True,
            "is_verified": True,
            "staff_role": "manager",
        },
        {
            "email": "manager@nethwin.com",
            "password": "ManagerPassword123!",
            "first_name": "Manager",
            "last_name": "User",
            "is_superuser": False,
            "is_verified": True,
            "staff_role": "manager",
        },
        {
            "email": "cashier@nethwin.com",
            "password": "CashierPassword123!",
            "first_name": "Cashier",
            "last_name": "User",
            "is_superuser": False,
            "is_verified": True,
            "staff_role": "cashier",
        },
        {
            "email": "customer@nethwin.com",
            "password": "CustomerPassword123!",
            "first_name": "Customer",
            "last_name": "User",
            "is_superuser": False,
            "is_verified": True,
            "loyalty_points": 5000,
            "membership_tier": "Gold",
            "total_spent": 15000.0,
        }
    ]

    users_created = 0
    users_skipped = 0

    for user_data in users_to_seed:
        email = user_data["email"]
        existing = await User.find_one(User.email == email)
        if existing:
            users_skipped += 1
            continue

        hashed_password = password_helper.hash(user_data["password"])
        
        user = User(
            email=email,
            hashed_password=hashed_password,
            is_active=True,
            is_superuser=user_data.get("is_superuser", False),
            is_verified=user_data.get("is_verified", False),
            first_name=user_data.get("first_name"),
            last_name=user_data.get("last_name"),
            loyalty_points=user_data.get("loyalty_points", 0),
            membership_tier=user_data.get("membership_tier", "Bronze"),
            total_spent=user_data.get("total_spent", 0.0),
            staff_role=user_data.get("staff_role"),
        )
        await user.insert()
        users_created += 1

    return users_created, users_skipped


async def seed() -> None:
    print("Initializing database...")
    await init_db()
    print("Database initialized.")

    db = await get_database()
    try:
        book_idx_info = await db["books"].index_information()
        if "sku_1" in book_idx_info:
            await db["books"].drop_index("sku_1")
            print("Dropped spurious sku_1 unique index from books collection")
    except Exception:
        pass

    category_map: dict[str, Category] = {}

    print("\n=== Seeding Users ===")
    users_created, users_skipped = await seed_users()

    print("\n=== Seeding Books ===")
    books_created, books_skipped = await seed_books(category_map)

    print("\n=== Seeding Stationery ===")
    stat_created, stat_skipped = await seed_stationery()

    print("\n" + "=" * 50)
    print("Seeding complete!")
    print(f"  Users created: {users_created}")
    print(f"  Users skipped (duplicates): {users_skipped}")
    print(f"  Books created: {books_created}")
    print(f"  Books skipped (duplicates): {books_skipped}")
    print(f"  Stationery created: {stat_created}")
    print(f"  Stationery skipped (duplicates): {stat_skipped}")
    print(f"  Categories tracked: {len(category_map)}")
    print("=" * 50)


if __name__ == "__main__":
    asyncio.run(seed())
