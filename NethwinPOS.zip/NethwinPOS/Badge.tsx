import { type HTMLAttributes, forwardRef } from 'react'
import { cn } from '../../utils/cn'

type Variant = 'default' | 'primary' | 'accent' | 'success' | 'warning' | 'danger' | 'preorder'
type Size = 'sm' | 'md'

interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  variant?: Variant
  size?: Size
}

const variantStyles: Record<Variant, string> = {
  default: 'bg-cream-200 text-primary-800 border-cream-300',
  primary: 'bg-primary-100 text-primary-800 border-primary-200',
  accent: 'bg-accent-100 text-accent-800 border-accent-200',
  success: 'bg-emerald-100 text-emerald-800 border-emerald-200',
  warning: 'bg-amber-100 text-amber-800 border-amber-200',
  danger: 'bg-red-100 text-red-800 border-red-200',
  preorder: 'bg-purple-100 text-purple-900 border-purple-300',
}

const sizeStyles: Record<Size, string> = {
  sm: 'h-5 px-2 text-xs',
  md: 'h-6 px-2.5 text-xs',
}

const Badge = forwardRef<HTMLSpanElement, BadgeProps>(
  ({ className, variant = 'default', size = 'sm', ...props }, ref) => (
    <span
      ref={ref}
      className={cn(
        'inline-flex items-center justify-center font-medium rounded-full border transition-colors',
        variantStyles[variant],
        sizeStyles[size],
        className,
      )}
      {...props}
    />
  ),
)

Badge.displayName = 'Badge'

export default Badge
