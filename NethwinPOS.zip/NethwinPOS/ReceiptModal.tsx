import { Printer, Download, CheckCircle2, Coins, Receipt as ReceiptIcon, Plus } from 'lucide-react'
import Modal from '../common/Modal'
import Button from '../common/Button'
import type { PosOrder, PosCartItem, PosPaymentMethod } from '../../types'
import { formatCurrency } from '../../utils/formatCurrency'
import { formatDate } from '../../utils/formatDate'
import { downloadReceiptPDF } from '../../utils/generatePDF'

interface ReceiptModalProps {
  open: boolean
  onClose: () => void
  onNewOrder: () => void
  order: PosOrder | null
  items?: PosCartItem[]
  subtotal?: number
  tax?: number
  total?: number
  method?: PosPaymentMethod
  cashTendered?: number
  changeDue?: number
  memberName?: string
  pointsEarned?: number
  pointsRedeemed?: number
}

export default function ReceiptModal({
  open, onClose, onNewOrder, order, items, subtotal, tax, total,
  method, cashTendered, changeDue, memberName, pointsEarned, pointsRedeemed,
}: ReceiptModalProps) {
  const displayItems = order?.items?.length
    ? order.items.map(i => ({
        id: String(i.id || i.title),
        productId: '',
        name: i.title,
        sku: i.sku || i.isbn || '',
        category: '',
        price: i.unit_price,
        quantity: i.quantity,
        thumbnail: i.image || '',
        productType: (i.productType as any) || 'book',
      }))
    : items || []

  const displaySubtotal = order?.subtotal ?? subtotal ?? 0
  const displayTax = order?.tax ?? tax ?? 0
  const displayTotal = order?.total ?? total ?? 0
  const orderNumber = order?.orderNumber || 'POS-TEMP'
  const createdAt = order?.createdAt || new Date().toISOString()
  const displayMethod = order?.paymentMethod || method
  const displayCash = order?.cashTendered ?? cashTendered
  const displayChange = order?.changeDue ?? changeDue
  const displayMember = order?.customerName || memberName
  const displayEarned = order?.pointsEarned ?? pointsEarned
  const displayRedeemed = order?.pointsRedeemed ?? pointsRedeemed

  const methodLabel: Record<string, string> = {
    cash: 'Cash',
    card: 'Credit/Debit Card',
    points: 'Loyalty Points',
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      showCloseButton={false}
      className="max-w-lg"
    >
      <div className="flex flex-col items-center">
        <div className="w-16 h-16 rounded-full bg-emerald-100 border-2 border-emerald-200 flex items-center justify-center mb-5">
          <CheckCircle2 className="w-9 h-9 text-emerald-600" />
        </div>

        <h2 className="font-serif text-2xl font-bold text-primary-950 mb-1">Payment Complete</h2>
        <p className="text-sm text-primary-800/70 mb-5 flex items-center gap-1.5">
          <ReceiptIcon className="w-4 h-4" />
          Receipt <span className="font-mono font-semibold text-primary-900">#{orderNumber}</span>
        </p>

        <div className="w-full bg-white border-2 border-dashed border-cream-300 rounded-2xl p-5 mb-5 relative">
          <div className="absolute -left-2.5 top-1/2 -translate-y-1/2 w-5 h-5 rounded-full bg-cream-100 border-r-2 border-dashed border-cream-300" />
          <div className="absolute -right-2.5 top-1/2 -translate-y-1/2 w-5 h-5 rounded-full bg-cream-100 border-l-2 border-dashed border-cream-300" />

          <div className="text-center mb-4 pb-4 border-b border-dashed border-cream-200">
            <p className="font-serif text-xl font-bold text-primary-950">Nethwin Bookshop</p>
            <p className="text-xs text-primary-800/60">No. 832, Dalanda Sevane Api Foundation, Gatambe Junction, 20000</p>
            <p className="text-xs text-primary-800/50 mt-1">Tel: 081 238 6908</p>
            <p className="text-xs text-primary-800/50 mt-0.5">{formatDate(createdAt)}</p>
          </div>

          <div className="space-y-2 mb-4 pb-4 border-b border-dashed border-cream-200">
            {displayItems.map((it) => (
              <div key={it.id} className="flex justify-between items-start gap-2 text-sm">
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-primary-950 leading-tight">
                    <span className="text-primary-800/60">{it.quantity}&times;</span> {it.name}
                  </p>
                  {it.sku && <p className="text-[10px] text-primary-800/40 font-mono">{it.sku}</p>}
                </div>
                <p className="font-medium text-primary-900 tabular-nums flex-shrink-0">
                  {formatCurrency(it.price * it.quantity)}
                </p>
              </div>
            ))}
          </div>

          <div className="space-y-1.5 text-sm mb-4 pb-4 border-b border-dashed border-cream-200">
            <div className="flex justify-between text-primary-800/80">
              <span>Subtotal</span>
              <span className="tabular-nums">{formatCurrency(displaySubtotal)}</span>
            </div>
            <div className="flex justify-between text-primary-800/80">
              <span>Tax (8%)</span>
              <span className="tabular-nums">{formatCurrency(displayTax)}</span>
            </div>
            {displayRedeemed && displayRedeemed > 0 && (
              <div className="flex justify-between text-accent-700">
                <span className="flex items-center gap-1">
                  <Coins className="w-3.5 h-3.5" /> Points ({displayRedeemed.toLocaleString()})
                </span>
                <span className="tabular-nums">-{formatCurrency(displayRedeemed / 100)}</span>
              </div>
            )}
            <div className="flex justify-between items-end pt-2">
              <span className="font-semibold text-primary-900 uppercase text-xs tracking-wider">Total</span>
              <span className="font-serif text-2xl font-bold text-primary-800 tabular-nums">
                {formatCurrency(displayTotal)}
              </span>
            </div>
          </div>

          <div className="space-y-1.5 text-sm">
            <div className="flex justify-between">
              <span className="text-primary-800/70">Payment</span>
              <span className="font-semibold text-primary-900">{methodLabel[displayMethod || ''] || displayMethod}</span>
            </div>
            {displayMethod === 'cash' && displayCash !== undefined && (
              <>
                <div className="flex justify-between">
                  <span className="text-primary-800/70">Cash Tendered</span>
                  <span className="font-medium text-primary-900 tabular-nums">{formatCurrency(displayCash)}</span>
                </div>
                {displayChange !== undefined && displayChange > 0 && (
                  <div className="flex justify-between text-emerald-700 pt-1">
                    <span className="font-semibold">Change Due</span>
                    <span className="font-bold tabular-nums">{formatCurrency(displayChange)}</span>
                  </div>
                )}
              </>
            )}
            {displayMember && (
              <div className="flex justify-between pt-2 border-t border-dashed border-cream-200 mt-2">
                <span className="text-primary-800/70">Member</span>
                <span className="font-medium text-primary-900">{displayMember}</span>
              </div>
            )}
            {displayEarned !== undefined && displayEarned > 0 && (
              <div className="p-2.5 rounded-lg bg-accent-50 border border-accent-100 mt-3">
                <p className="text-center text-xs text-accent-800 flex items-center justify-center gap-1.5">
                  <Coins className="w-4 h-4" />
                  <span>Earned <strong className="font-bold">{displayEarned.toLocaleString()} points</strong> today!</span>
                </p>
              </div>
            )}
          </div>
        </div>

        <p className="text-sm text-primary-800/70 mb-5 text-center font-serif italic">
          Thank you for shopping at Nethwin. Come again soon.
        </p>

        <div className="w-full flex flex-col sm:flex-row gap-3">
          <Button variant="outline" size="md" className="gap-1.5 flex-1" onClick={() => window.print()}>
            <Printer className="w-4 h-4" /> Print
          </Button>
          <Button
            variant="secondary"
            size="md"
            className="gap-1.5 flex-1"
            onClick={() => {
              const syntheticOrder: PosOrder = {
                id: orderNumber,
                orderNumber,
                items: displayItems.map(it => ({
                  title: it.name,
                  quantity: it.quantity,
                  unit_price: it.price,
                  subtotal: it.price * it.quantity,
                  sku: it.sku,
                  productType: it.productType as any,
                })),
                subtotal: displaySubtotal,
                tax: displayTax,
                total: displayTotal,
                paymentMethod: displayMethod as any,
                cashTendered: displayCash,
                changeDue: displayChange,
                customerName: displayMember,
                pointsEarned: displayEarned,
                pointsRedeemed: displayRedeemed,
                createdAt,
                status: 'completed',
              }
              downloadReceiptPDF(syntheticOrder)
            }}
          >
            <Download className="w-4 h-4" /> PDF
          </Button>
          <Button
            variant="accent"
            size="md"
            className="gap-1.5 flex-1"
            onClick={() => { onNewOrder(); onClose() }}
          >
            <Plus className="w-4 h-4" /> New Order
          </Button>
        </div>
      </div>
    </Modal>
  )
}
