import { useState, useEffect } from 'react'
import { useCategories } from '../../hooks/useCategories'
import {
  useCreateBook,
  useUpdateBook,
  useCreateStationery,
  useUpdateStationery,
} from '../../hooks/useBooks'
import Modal from '../common/Modal'
import Button from '../common/Button'
import { toast } from 'sonner'

interface AddEditProductModalProps {
  open: boolean
  onClose: () => void
  product?: any
  defaultType?: 'book' | 'stationery'
}

export default function AddEditProductModal({
  open,
  onClose,
  product,
  defaultType = 'book',
}: AddEditProductModalProps) {
  const isEdit = !!product
  const [productType, setProductType] = useState<'book' | 'stationery'>(defaultType)

  const [title, setTitle] = useState('')
  const [author, setAuthor] = useState('')
  const [price, setPrice] = useState('')
  const [originalPrice, setOriginalPrice] = useState('')
  const [coverImage, setCoverImage] = useState('')
  const [stock, setStock] = useState('')
  const [description, setDescription] = useState('')
  const [categoryId, setCategoryId] = useState('')
  const [isbn, setIsbn] = useState('')
  const [publisher, setPublisher] = useState('')
  const [pages, setPages] = useState('')
  const [isPreorder, setIsPreorder] = useState(false)
  const [releaseDate, setReleaseDate] = useState('')

  const { data: rawCategories } = useCategories()
  const categories = Array.isArray(rawCategories)
    ? rawCategories
    : (rawCategories as any)?.items || (rawCategories as any)?.data || []

  const createBook = useCreateBook()
  const updateBook = useUpdateBook()
  const createStationery = useCreateStationery()
  const updateStationery = useUpdateStationery()

  const isPending =
    createBook.isPending ||
    updateBook.isPending ||
    createStationery.isPending ||
    updateStationery.isPending

  useEffect(() => {
    if (open) {
      if (product) {
        const type = product.productType || (product.author || product.isbn ? 'book' : 'stationery')
        setProductType(type)
        setTitle(product.title || product.name || '')
        setAuthor(product.author || product.brand || '')
        setPrice(String(product.price || ''))
        setOriginalPrice(String(product.originalPrice || ''))
        setCoverImage(product.coverImage || product.image || '')
        setStock(String(product.stock ?? ''))
        setDescription(product.description || '')
        setCategoryId(product.categoryId || '')
        setIsbn(product.isbn || product.isbn13 || '')
        setPublisher(product.publisher || '')
        setPages(String(product.pages || ''))
        setIsPreorder(!!(product.is_preorder || product.isPreorder))
        setReleaseDate(product.release_date || product.releaseDate || '')
      } else {
        setProductType(defaultType)
        setTitle('')
        setAuthor('')
        setPrice('')
        setOriginalPrice('')
        setCoverImage('')
        setStock('')
        setDescription('')
        setCategoryId('')
        setIsbn('')
        setPublisher('')
        setPages('')
        setIsPreorder(false)
        setReleaseDate('')
      }
    }
  }, [open, product, defaultType])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!title.trim() || !price.trim() || !stock.trim()) {
      toast.error('Please fill in all required fields (Title, Price, Stock)')
      return
    }

    const payload: any = {
      title: productType === 'book' ? title : undefined,
      name: productType === 'stationery' ? title : undefined,
      author: productType === 'book' ? author : undefined,
      brand: productType === 'stationery' ? author : undefined,
      price: parseFloat(price),
      originalPrice: originalPrice ? parseFloat(originalPrice) : undefined,
      coverImage: productType === 'book' ? coverImage || undefined : undefined,
      image: productType === 'stationery' ? coverImage || undefined : undefined,
      stock: parseInt(stock),
      description: description || undefined,
      categoryId: categoryId || undefined,
      isbn: productType === 'book' ? isbn || undefined : undefined,
      isbn13: productType === 'book' ? isbn || undefined : undefined,
      publisher: productType === 'book' ? publisher || undefined : undefined,
      pages: productType === 'book' && pages ? parseInt(pages) : undefined,
      is_preorder: isPreorder,
      release_date: isPreorder && releaseDate ? releaseDate : undefined,
      productType,
    }

    try {
      if (isEdit) {
        if (productType === 'book') {
          await updateBook.mutateAsync({ id: product.id, payload })
        } else {
          await updateStationery.mutateAsync({ id: product.id, payload })
        }
        toast.success('Product updated successfully!')
      } else {
        if (productType === 'book') {
          await createBook.mutateAsync(payload)
        } else {
          await createStationery.mutateAsync(payload)
        }
        toast.success('Product added successfully!')
      }
      onClose()
    } catch (err: any) {
      toast.error(err.response?.data?.detail || 'Failed to save product')
    }
  }

  return (
    <Modal open={open} onClose={onClose} title={isEdit ? 'Edit Product' : 'Add New Product'}>
      <form onSubmit={handleSubmit} className="space-y-4 text-xs">
        {!isEdit && (
          <div className="flex items-center gap-4 border-b border-cream-200 pb-3">
            <span className="font-semibold text-primary-900">Product Type:</span>
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="radio"
                name="type"
                checked={productType === 'book'}
                onChange={() => setProductType('book')}
                className="text-primary-600 focus:ring-primary-500/20"
              />
              <span className="text-primary-800">Book</span>
            </label>
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="radio"
                name="type"
                checked={productType === 'stationery'}
                onChange={() => setProductType('stationery')}
                className="text-primary-600 focus:ring-primary-500/20"
              />
              <span className="text-primary-800">Stationery</span>
            </label>
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-primary-700 font-medium mb-1">Title *</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full border border-cream-300 rounded-lg px-2.5 py-1.5 bg-cream-50 focus:outline-none focus:ring-2 focus:ring-primary-500/30"
              placeholder={productType === 'book' ? 'e.g. The Hobbit' : 'e.g. Luxury Fountain Pen'}
            />
          </div>

          <div>
            <label className="block text-primary-700 font-medium mb-1">
              {productType === 'book' ? 'Author' : 'Brand'}
            </label>
            <input
              type="text"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              className="w-full border border-cream-300 rounded-lg px-2.5 py-1.5 bg-cream-50 focus:outline-none focus:ring-2 focus:ring-primary-500/30"
              placeholder={productType === 'book' ? 'J.R.R. Tolkien' : 'Montblanc'}
            />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div>
            <label className="block text-primary-700 font-medium mb-1">Price (LKR) *</label>
            <input
              type="number"
              step="0.01"
              required
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              className="w-full border border-cream-300 rounded-lg px-2.5 py-1.5 bg-cream-50 focus:outline-none focus:ring-2 focus:ring-primary-500/30"
              placeholder="1250.00"
            />
          </div>

          <div>
            <label className="block text-primary-700 font-medium mb-1">Original Price</label>
            <input
              type="number"
              step="0.01"
              value={originalPrice}
              onChange={(e) => setOriginalPrice(e.target.value)}
              className="w-full border border-cream-300 rounded-lg px-2.5 py-1.5 bg-cream-50 focus:outline-none focus:ring-2 focus:ring-primary-500/30"
              placeholder="1500.00"
            />
          </div>

          <div>
            <label className="block text-primary-700 font-medium mb-1">Stock Level *</label>
            <input
              type="number"
              required
              value={stock}
              onChange={(e) => setStock(e.target.value)}
              className="w-full border border-cream-300 rounded-lg px-2.5 py-1.5 bg-cream-50 focus:outline-none focus:ring-2 focus:ring-primary-500/30"
              placeholder="25"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-primary-700 font-medium mb-1">Category</label>
            <select
              value={categoryId}
              onChange={(e) => setCategoryId(e.target.value)}
              className="w-full border border-cream-300 rounded-lg px-2.5 py-1.5 bg-cream-50 focus:outline-none focus:ring-2 focus:ring-primary-500/30"
            >
              <option value="">Select Category</option>
              {categories.map((c: any) => (
                <option key={c.id || c._id} value={c.id || c._id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-primary-700 font-medium mb-1">Cover Image URL</label>
            <input
              type="text"
              value={coverImage}
              onChange={(e) => setCoverImage(e.target.value)}
              className="w-full border border-cream-300 rounded-lg px-2.5 py-1.5 bg-cream-50 focus:outline-none focus:ring-2 focus:ring-primary-500/30"
              placeholder="https://example.com/cover.jpg"
            />
          </div>
        </div>

        {productType === 'book' && (
          <div className="grid grid-cols-3 gap-3 border-t border-cream-100 pt-3">
            <div>
              <label className="block text-primary-700 font-medium mb-1">ISBN</label>
              <input
                type="text"
                value={isbn}
                onChange={(e) => setIsbn(e.target.value)}
                className="w-full border border-cream-300 rounded-lg px-2.5 py-1.5 bg-cream-50 focus:outline-none focus:ring-2 focus:ring-primary-500/30"
                placeholder="9780007525546"
              />
            </div>

            <div>
              <label className="block text-primary-700 font-medium mb-1">Publisher</label>
              <input
                type="text"
                value={publisher}
                onChange={(e) => setPublisher(e.target.value)}
                className="w-full border border-cream-300 rounded-lg px-2.5 py-1.5 bg-cream-50 focus:outline-none focus:ring-2 focus:ring-primary-500/30"
                placeholder="HarperCollins"
              />
            </div>

            <div>
              <label className="block text-primary-700 font-medium mb-1">Pages</label>
              <input
                type="number"
                value={pages}
                onChange={(e) => setPages(e.target.value)}
                className="w-full border border-cream-300 rounded-lg px-2.5 py-1.5 bg-cream-50 focus:outline-none focus:ring-2 focus:ring-primary-500/30"
                placeholder="320"
              />
            </div>
          </div>
        )}

        <div>
          <label className="block text-primary-700 font-medium mb-1">Description</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full border border-cream-300 rounded-lg px-2.5 py-1.5 bg-cream-50 h-20 focus:outline-none focus:ring-2 focus:ring-primary-500/30 resize-none"
            placeholder="Detailed description of the item..."
          />
        </div>

        <div className="flex items-center justify-between border-t border-cream-100 pt-3">
          <span className="text-primary-800 font-semibold">Enable Pre-order Mode</span>
          <button
            type="button"
            onClick={() => setIsPreorder(!isPreorder)}
            className={`relative w-9 h-5 rounded-full transition-colors focus:outline-none ${isPreorder ? 'bg-amber-500' : 'bg-cream-300'}`}
          >
            <span className={`absolute top-[2px] w-4 h-4 bg-white rounded-full shadow transition-all duration-200 ${isPreorder ? 'left-[18px]' : 'left-[2px]'}`} />
          </button>
        </div>

        {isPreorder && (
          <div>
            <label className="block text-primary-700 font-medium mb-1">Release Date</label>
            <input
              type="date"
              required
              value={releaseDate}
              onChange={(e) => setReleaseDate(e.target.value)}
              className="w-full border border-cream-300 rounded-lg px-2.5 py-1.5 bg-cream-50 focus:outline-none focus:ring-2 focus:ring-primary-500/30"
            />
          </div>
        )}

        <div className="flex justify-end gap-2 pt-3 border-t border-cream-100">
          <Button variant="ghost" onClick={onClose} disabled={isPending}>
            Cancel
          </Button>
          <Button variant="primary" type="submit" disabled={isPending}>
            {isPending ? 'Saving...' : isEdit ? 'Save Changes' : 'Add Product'}
          </Button>
        </div>
      </form>
    </Modal>
  )
}
