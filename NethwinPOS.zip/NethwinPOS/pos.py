from fastapi import APIRouter, HTTPException, Depends, Query
from typing import Optional
import math
import random
import string
from datetime import datetime
from decimal import Decimal
from bson import ObjectId
from html import escape as html_escape

from app.core.security import current_user, current_superuser
from app.models.user import User
from app.models.book import Book
from app.models.stationery import Stationery
from app.models.order import Order, OrderItem, OrderStatus, PaymentStatus, ShippingAddress
from app.models.ledger import PointsTransaction, TransactionType
from app.services import (
    tier_from_spent,
    points_earned_for,
    discount_from_points,
    max_points_for_order,
    TIER_EARN_MULTIPLIERS,
)
from app.config import settings
from app.schemas import (
    POSLookupProductRequest,
    POSLookupProductResponse,
    POSCartCalculateRequest,
    POSCartCalculateResponse,
    POSCartItemValidated,
    POSQuickPayRequest,
    POSQuickPayResponse,
    PaginatedOrders,
    OrderRead,
    OrderItemRead,
    ShippingAddressBase,
)
from app.routers.books import _book_to_read
from app.routers.stationery import _stationery_to_read

router = APIRouter(prefix="/pos", tags=["pos"])


def _generate_pos_order_number() -> str:
    date_part = datetime.utcnow().strftime("%Y%m%d")
    suffix = "".join(random.choices(string.ascii_uppercase + string.digits, k=6))
    return f"POS-{date_part}-{suffix}"


async def lookup_any_product_async(code: str):
    code = code.strip()
    if not code:
        return None, None

    stationery = None
    try:
        stationery = await Stationery.find_one(Stationery.sku == code)
    except Exception:
        pass
    if not stationery:
        try:
            stationery = await Stationery.find_one(Stationery.barcode == code)
        except Exception:
            pass
    if stationery:
        return "stationery", stationery

    book = None
    try:
        book = await Book.find_one(Book.isbn13 == code)
    except Exception:
        pass
    if not book:
        try:
            book = await Book.find_one(Book.isbn10 == code)
        except Exception:
            pass
    if book:
        return "book", book

    if ObjectId.is_valid(code):
        try:
            s2 = await Stationery.get(code)
            if s2:
                return "stationery", s2
        except Exception:
            pass
        try:
            b2 = await Book.get(code)
            if b2:
                return "book", b2
        except Exception:
            pass
    return None, None


@router.post("/lookup-product", response_model=POSLookupProductResponse)
async def pos_lookup_product(
    data: POSLookupProductRequest,
    _: User = Depends(current_user),
):
    ptype, product = await lookup_any_product_async(data.code)
    if product is None:
        raise HTTPException(status_code=404, detail="Product not found")

    if ptype == "book":
        read = await _book_to_read(product)
    else:
        read = _stationery_to_read(product)

    if product.is_preorder:
        status = "preorder"
    elif product.stock > 0:
        status = "in_stock"
    else:
        status = "out_of_stock"

    return POSLookupProductResponse(product=read, status=status)


async def _validate_and_price_items(items):
    validated = []
    subtotal = Decimal("0")
    for it in items:
        product = None
        if it.product_type == "book":
            product = await Book.get(it.product_id)
            if not product:
                raise HTTPException(status_code=404, detail=f"Book not found: {it.product_id}")
            title = product.title
        elif it.product_type == "stationery":
            product = await Stationery.get(it.product_id)
            if not product:
                raise HTTPException(status_code=404, detail=f"Stationery not found: {it.product_id}")
            title = product.name
        else:
            raise HTTPException(status_code=400, detail="Invalid product_type")

        in_stock = product.stock >= it.qty or product.is_preorder
        if not in_stock:
            raise HTTPException(status_code=400, detail=f"Insufficient stock for {title}")

        unit = product.price
        sub = (unit * it.qty).quantize(Decimal("0.01"))
        subtotal += sub
        validated.append(POSCartItemValidated(
            product_id=it.product_id,
            product_type=it.product_type,
            qty=it.qty,
            title=title,
            unit_price=unit,
            subtotal=sub,
            in_stock=in_stock,
        ))
    return validated, subtotal


def _build_receipt_html(order_number, items, subtotal, tax, points_discount, total, customer_name, cash_tendered, change_due):
    date_str = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
    rows = []
    for it in items:
        rows.append(f"""
        <tr>
            <td style="padding:4px 8px;border-bottom:1px dashed #ccc;text-align:left;">{html_escape(it.title)} x{it.qty}</td>
            <td style="padding:4px 8px;border-bottom:1px dashed #ccc;text-align:right;">${it.subtotal:.2f}</td>
        </tr>
        """)
    change_html = ""
    if cash_tendered is not None:
        change_html = f"""
        <tr><td style="padding:4px 8px;text-align:left;"><strong>Cash Tendered</strong></td>
        <td style="padding:4px 8px;text-align:right;">${cash_tendered:.2f}</td></tr>
        <tr><td style="padding:4px 8px;text-align:left;"><strong>Change Due</strong></td>
        <td style="padding:4px 8px;text-align:right;"><strong>${change_due:.2f}</strong></td></tr>
        """
    name_line = f"<p style=\"margin:4px 0;\">Customer: {html_escape(customer_name or 'Guest')}</p>" if customer_name else ""
    return f"""
    <div style=\"font-family:Arial,Helvetica,sans-serif;font-size:14px;max-width:480px;margin:0 auto;padding:16px;border:1px solid #e5e5e5;background:#fff;\">
        <div style=\"text-align:center;border-bottom:2px solid #333;padding-bottom:10px;margin-bottom:10px;\">
            <h2 style=\"margin:0 0 4px 0;\">Nethwin Bookshop</h2>
            <p style=\"margin:2px 0;font-size:12px;color:#555;\">Receipt / POS Transaction</p>
        </div>
        <div style=\"font-size:13px;margin-bottom:12px;\">
            <p style=\"margin:4px 0;\"><strong>Order #:</strong> {html_escape(order_number)}</p>
            <p style=\"margin:4px 0;\"><strong>Date:</strong> {date_str}</p>
            {name_line}
        </div>
        <table style=\"width:100%;border-collapse:collapse;margin-bottom:10px;\">
            <thead>
                <tr style=\"background:#f5f5f5;\">
                    <th style=\"padding:6px 8px;text-align:left;border-bottom:1px solid #ccc;\">Item</th>
                    <th style=\"padding:6px 8px;text-align:right;border-bottom:1px solid #ccc;\">Amount</th>
                </tr>
            </thead>
            <tbody>
                {''.join(rows)}
            </tbody>
        </table>
        <table style=\"width:100%;border-collapse:collapse;\">
            <tr><td style=\"padding:4px 8px;text-align:left;\">Subtotal</td>
            <td style=\"padding:4px 8px;text-align:right;\">${subtotal:.2f}</td></tr>
            <tr><td style=\"padding:4px 8px;text-align:left;\">Tax</td>
            <td style=\"padding:4px 8px;text-align:right;\">${tax:.2f}</td></tr>
            <tr><td style=\"padding:4px 8px;text-align:left;color:#c00;\">Points Discount</td>
            <td style=\"padding:4px 8px;text-align:right;color:#c00;\">-${points_discount:.2f}</td></tr>
            <tr style=\"font-size:16px;border-top:2px solid #333;\">
                <td style=\"padding:8px;text-align:left;\"><strong>TOTAL</strong></td>
                <td style=\"padding:8px;text-align:right;\"><strong>${total:.2f}</strong></td>
            </tr>
            {change_html}
        </table>
        <div style=\"text-align:center;margin-top:16px;padding-top:10px;border-top:1px dashed #ccc;color:#555;font-size:12px;\">
            <p style=\"margin:4px 0;\">Thank you for your purchase!</p>
            <p style=\"margin:4px 0;\">Nethwin Bookshop</p>
        </div>
    </div>
    """


@router.post("/cart/calculate", response_model=POSCartCalculateResponse)
async def pos_cart_calculate(
    data: POSCartCalculateRequest,
    _: User = Depends(current_user),
):
    validated, subtotal = await _validate_and_price_items(data.items)

    member_tier = None
    member_balance = None
    user_obj = None
    if data.user_email:
        user_obj = await User.find_one(User.email == data.user_email.lower().strip())
        if user_obj:
            member_tier = user_obj.membership_tier or tier_from_spent(user_obj.total_spent)
            member_balance = user_obj.loyalty_points

    points_discount = Decimal("0")
    if data.redeem_points > 0 and user_obj is not None:
        max_allowed = max_points_for_order(subtotal)
        points_to_apply = min(data.redeem_points, user_obj.loyalty_points, max_allowed)
        if points_to_apply > 0:
            points_discount = discount_from_points(points_to_apply)

    tax = (subtotal * Decimal(str(settings.TAX_RATE))).quantize(Decimal("0.01"))
    shipping = Decimal("0")
    discounted_subtotal = (subtotal - points_discount).quantize(Decimal("0.01"))
    if discounted_subtotal < Decimal("0"):
        discounted_subtotal = Decimal("0")
    total = (discounted_subtotal + tax + shipping).quantize(Decimal("0.01"))

    tier_for_calc = member_tier or "Bronze"
    loyalty_points_to_earn = points_earned_for(total, tier_for_calc)

    return POSCartCalculateResponse(
        items_validated=validated,
        subtotal=subtotal,
        tax=tax,
        shipping=shipping,
        points_discount=points_discount,
        total=total,
        loyalty_points_to_earn=loyalty_points_to_earn,
        member_tier=member_tier,
        member_points_balance=member_balance,
    )


@router.post("/quick-pay", response_model=POSQuickPayResponse)
async def pos_quick_pay(
    data: POSQuickPayRequest,
    _: User = Depends(current_user),
):
    validated, subtotal = await _validate_and_price_items(data.items)

    member_obj = None
    if data.user_email:
        member_obj = await User.find_one(User.email == data.user_email.lower().strip())

    points_applied = 0
    points_discount = Decimal("0")
    if data.redeem_points > 0 and member_obj is not None:
        max_allowed = max_points_for_order(subtotal)
        points_applied = min(data.redeem_points, member_obj.loyalty_points, max_allowed)
        if points_applied > 0:
            points_discount = discount_from_points(points_applied)

    discounted = (subtotal - points_discount).quantize(Decimal("0.01"))
    if discounted < Decimal("0"):
        discounted = Decimal("0")
    tax = (discounted * Decimal(str(settings.TAX_RATE))).quantize(Decimal("0.01"))
    shipping = Decimal("0")
    total = (discounted + tax + shipping).quantize(Decimal("0.01"))

    if total <= Decimal("0"):
        total = Decimal("0.01")

    if data.payment_method == "cash" and data.cash_tendered is not None:
        if data.cash_tendered < total:
            raise HTTPException(status_code=400, detail="Cash tendered is less than total")

    order_items = []
    for v in validated:
        if v.product_type == "book":
            order_items.append(OrderItem(
                book_id=ObjectId(v.product_id),
                product_type="book",
                title=v.title,
                isbn=None,
                sku=None,
                quantity=v.qty,
                unit_price=v.unit_price,
                subtotal=v.subtotal,
            ))
        else:
            order_items.append(OrderItem(
                stationery_id=ObjectId(v.product_id),
                product_type="stationery",
                title=v.title,
                isbn=None,
                sku=None,
                quantity=v.qty,
                unit_price=v.unit_price,
                subtotal=v.subtotal,
            ))

    ship_addr = None
    cust_name = data.customer_name
    if member_obj and not cust_name:
        cust_name = member_obj.full_name

    order = Order(
        user_id=ObjectId(member_obj.id) if member_obj else None,
        order_number=_generate_pos_order_number(),
        items=order_items,
        subtotal=subtotal,
        tax=tax,
        shipping=shipping,
        redeem_points_applied=points_applied,
        points_discount=points_discount,
        points_earned=0,
        total=total,
        status=OrderStatus.PAID,
        shipping_address=ship_addr,
        payment_intent_id=None,
        payment_status=PaymentStatus.PAID,
        tracking_number=None,
        notes=data.cashier_notes,
        source="pos",
        paid_at=datetime.utcnow(),
    )
    await order.insert()

    for v in validated:
        if v.product_type == "book":
            b = await Book.get(v.product_id)
            if b and not b.is_preorder:
                b.stock = max(0, b.stock - v.qty)
                b.updated_at = datetime.utcnow()
                await b.save()
        else:
            s = await Stationery.get(v.product_id)
            if s and not s.is_preorder:
                s.stock = max(0, s.stock - v.qty)
                s.updated_at = datetime.utcnow()
                await s.save()

    points_earned = 0
    final_balance = None
    if member_obj is not None:
        if points_applied > 0:
            member_obj.loyalty_points = max(0, member_obj.loyalty_points - points_applied)
            member_obj.points_redeemed_total += points_applied
            tx_redeem = PointsTransaction(
                user_id=ObjectId(member_obj.id),
                type=TransactionType.REDEEM,
                points=-points_applied,
                balance_after=member_obj.loyalty_points,
                source=f"order:{order.order_number}",
                description=f"Points redeemed on POS order {order.order_number}",
            )
            await tx_redeem.insert()

        tier = tier_from_spent(member_obj.total_spent)
        points_earned = points_earned_for(order.total, tier)
        if points_earned > 0:
            member_obj.loyalty_points += points_earned
            member_obj.points_earned_total += points_earned
        member_obj.total_spent = (member_obj.total_spent + order.total).quantize(Decimal("0.01"))
        new_tier = tier_from_spent(member_obj.total_spent)
        member_obj.membership_tier = new_tier
        await member_obj.save()
        final_balance = member_obj.loyalty_points
        order.points_earned = points_earned
        await order.save()

        if points_earned > 0:
            tx_earn = PointsTransaction(
                user_id=ObjectId(member_obj.id),
                type=TransactionType.EARN,
                points=points_earned,
                balance_after=member_obj.loyalty_points,
                source=f"order:{order.order_number}",
                description=f"Points earned from POS order {order.order_number}",
            )
            await tx_earn.insert()

    change_due = None
    if data.payment_method == "cash" and data.cash_tendered is not None:
        change_due = (data.cash_tendered - order.total).quantize(Decimal("0.01"))

    receipt_html = _build_receipt_html(
        order.order_number,
        validated,
        subtotal,
        tax,
        points_discount,
        total,
        cust_name,
        data.cash_tendered,
        change_due,
    )

    return POSQuickPayResponse(
        order_number=order.order_number,
        items=validated,
        subtotal=subtotal,
        tax=tax,
        points_discount=points_discount,
        total=total,
        change_due=change_due,
        receipt_html=receipt_html,
        member_points_earned=points_earned,
        member_points_balance=final_balance,
        status=order.status,
        source="pos",
    )


@router.get("/orders", response_model=PaginatedOrders)
async def pos_list_orders(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    _: User = Depends(current_user),
):
    total = await Order.find(Order.source == "pos").count()
    total_pages = max(1, math.ceil(total / page_size))
    skip = (page - 1) * page_size
    orders = await Order.find(Order.source == "pos").sort(-Order.created_at).skip(skip).limit(page_size).to_list()

    items = []
    for order in orders:
        items_read = []
        for it in order.items:
            items_read.append(OrderItemRead(
                product_type=it.product_type,
                title=it.title,
                isbn=it.isbn,
                sku=it.sku,
                quantity=it.quantity,
                unit_price=it.unit_price,
                subtotal=it.subtotal,
            ))
        user_id_str = None
        if order.user_id:
            if hasattr(order.user_id, "id"):
                user_id_str = str(order.user_id.id)
            else:
                user_id_str = str(order.user_id)
        addr = None
        if order.shipping_address:
            addr = ShippingAddressBase(
                name=order.shipping_address.name,
                line1=order.shipping_address.line1,
                line2=order.shipping_address.line2,
                city=order.shipping_address.city,
                state=order.shipping_address.state,
                postal_code=order.shipping_address.postal_code,
                country=order.shipping_address.country,
                phone=order.shipping_address.phone,
            )
        items.append(OrderRead(
            id=str(order.id),
            order_number=order.order_number,
            items=items_read,
            subtotal=order.subtotal,
            tax=order.tax,
            shipping=order.shipping,
            redeem_points_applied=order.redeem_points_applied,
            points_discount=order.points_discount,
            points_earned=order.points_earned,
            total=order.total,
            status=order.status,
            shipping_address=addr,
            payment_status=order.payment_status,
            tracking_number=order.tracking_number,
            notes=order.notes,
            source=order.source,
            created_at=order.created_at,
            updated_at=order.updated_at,
            paid_at=order.paid_at,
            shipped_at=order.shipped_at,
            delivered_at=order.delivered_at,
            paymentMethod="pos",
            userId=user_id_str,
            address=addr,
        ))

    return PaginatedOrders(
        total=total,
        page=page,
        page_size=page_size,
        pages=total_pages,
        items=items,
        data=items,
        limit=page_size,
        totalPages=total_pages,
    )
