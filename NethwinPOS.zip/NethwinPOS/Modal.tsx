import { useEffect, type HTMLAttributes } from 'react'
import { cn } from '../../utils/cn'
import { X } from 'lucide-react'
import Button from './Button'

interface ModalProps extends HTMLAttributes<HTMLDivElement> {
  open: boolean
  onClose: () => void
  title?: string
  description?: string
  showCloseButton?: boolean
}

export default function Modal({
  open,
  onClose,
  title,
  description,
  showCloseButton = true,
  children,
  className,
  ...props
}: ModalProps) {
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    document.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [open, onClose])

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-primary-950/50 backdrop-blur-sm animate-in fade-in-0 duration-200"
        onClick={onClose}
      />
      <div
        className={cn(
          'relative w-full max-w-lg bg-white rounded-2xl shadow-2xl shadow-primary-950/20 border border-cream-200 p-6 animate-in zoom-in-95 slide-in-from-bottom-4 duration-200',
          className,
        )}
        role="dialog"
        aria-modal="true"
        {...props}
      >
        {(title || showCloseButton) && (
          <div className="flex items-start justify-between mb-4">
            <div>
              {title && <h2 className="font-serif text-xl font-semibold text-primary-950">{title}</h2>}
              {description && <p className="text-sm text-primary-900/60 mt-1">{description}</p>}
            </div>
            {showCloseButton && (
              <Button variant="ghost" size="icon" onClick={onClose} aria-label="Close">
                <X className="w-4 h-4" />
              </Button>
            )}
          </div>
        )}
        <div>{children}</div>
      </div>
    </div>
  )
}
