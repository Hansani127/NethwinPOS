from beanie import Document, Indexed, Link
from datetime import datetime
from typing import Optional
from pydantic import Field, EmailStr
from decimal import Decimal

from fastapi_users_db_beanie import BeanieBaseUser, BeanieUserDatabase


class User(BeanieBaseUser, Document):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    loyalty_points: int = Field(default=0, ge=0)
    membership_tier: str = Field(default="Bronze")
    total_spent: float = Field(default=0.0, ge=0)
    points_earned_total: int = 0
    points_redeemed_total: int = 0
    joined_at: datetime = Field(default_factory=datetime.utcnow)
    staff_role: Optional[str] = None  # 'manager' | 'cashier' | None (regular user)

    class Settings(BeanieBaseUser.Settings):
        name = "users"

    @property
    def full_name(self) -> str:
        parts = [p for p in [self.first_name, self.last_name] if p]
        return " ".join(parts) if parts else self.email
