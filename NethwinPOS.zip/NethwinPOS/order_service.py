from datetime import datetime
from decimal import Decimal
import random
import string

from app.config import settings
from app.models.cart import CartItem
from app.models.order import Order, OrderItem


def generate_order_number() -> str:
    timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
    suffix = "".join(random.choices(string.ascii_uppercase + string.digits, k=6))
    return f"NW-{timestamp}-{suffix}"


def calculate_totals(
    items: list[CartItem] | list[OrderItem],
    tax_rate: float | None = None,
    shipping_rate: float | None = None,
) -> dict[str, Decimal]:
    tax_rate = tax_rate if tax_rate is not None else settings.TAX_RATE
    shipping_rate = shipping_rate if shipping_rate is not None else settings.SHIPPING_RATE

    subtotal = Decimal("0")
    for item in items:
        if isinstance(item, CartItem):
            subtotal += item.price_at_time * item.quantity
        else:
            subtotal += item.subtotal

    tax = (subtotal * Decimal(str(tax_rate))).quantize(Decimal("0.01"))

    if subtotal >= Decimal(str(settings.FREE_SHIPPING_THRESHOLD)):
        shipping = Decimal("0")
    else:
        shipping = Decimal(str(shipping_rate)).quantize(Decimal("0.01"))

    total = (subtotal + tax + shipping).quantize(Decimal("0.01"))

    return {
        "subtotal": subtotal.quantize(Decimal("0.01")),
        "tax": tax,
        "shipping": shipping,
        "total": total,
    }
