import { Plus, Minus } from 'lucide-react'
import type { CatalogProduct } from '../../types'
import { cleanImageUrl } from '../../utils/imageUrl'
import { formatCurrency } from '../../utils/formatCurrency'
import Badge from '../common/Badge'
import { cn } from '../../utils/cn'

interface ProductTileProps {
  product: CatalogProduct
  onClick: () => void
  onAddQty?: (qty: number) => void
  compact?: boolean
}

export default function ProductTile({ product, onClick, compact }: ProductTileProps) {
  const title = (product as any).title || (product as any).name || 'Product'
  const author = (product as any).author || (product as any).brand || ''
  const sku = (product as any).sku || (product as any).isbn || (product as any).isbn13 || ''
  const type: 'book' | 'stationery' = (product as any).productType ||
    ((product as any).author || (product as any).isbn ? 'book' : 'stationery')
  const img = cleanImageUrl((product as any).coverImage || (product as any).image, title, type)
  const stock = (product as any).stock ?? 99
  const isPreorder = (product as any).is_preorder || (product as any).isPreorder

  return (
    <button
      onClick={onClick}
      className={cn(
        'group relative text-left bg-white rounded-xl border border-cream-200 overflow-hidden transition-all hover:border-primary-300 hover:shadow-md active:scale-[0.98]',
        compact && 'rounded-lg',
      )}
    >
      <div className="relative aspect-square bg-cream-100 overflow-hidden">
        <img
          src={img}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          onError={(e) => {
            ;(e.currentTarget as HTMLImageElement).src = cleanImageUrl('', title, type)
          }}
        />
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {isPreorder && <Badge variant="primary" className="text-[10px] px-1.5 h-5">PRE-ORDER</Badge>}
          {type === 'stationery' && <Badge variant="default" className="text-[10px] px-1.5 h-5 bg-accent-50 text-accent-700 border-accent-200">Stationery</Badge>}
        </div>
        <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="w-8 h-8 rounded-full bg-accent-500 text-white flex items-center justify-center shadow-lg">
            <Plus className="w-4 h-4" />
          </div>
        </div>
        {stock === 0 && (
          <div className="absolute inset-0 bg-primary-950/60 flex items-center justify-center">
            <Badge variant="danger" className="px-3">Out of Stock</Badge>
          </div>
        )}
      </div>
      <div className="p-2.5 space-y-1">
        <p className="font-serif text-sm font-semibold text-primary-950 line-clamp-1 leading-tight">
          {title}
        </p>
        {author && <p className="text-[11px] text-primary-800/60 truncate">{author}</p>}
        {sku && <p className="text-[10px] text-primary-800/40 font-mono truncate">{sku}</p>}
        <div className="flex items-center justify-between pt-1">
          <p className="font-bold text-primary-800 tabular-nums text-sm">
            {formatCurrency((product as any).price || 0)}
          </p>
          <span className={cn(
            'text-[10px] font-semibold',
            stock === 0 ? 'text-red-600' : stock < 5 ? 'text-amber-700' : 'text-emerald-700',
          )}>
            {stock === 0 ? 'Out' : `${stock}`}
          </span>
        </div>
      </div>
    </button>
  )
}

export function QtyStepper({ qty, onChange, min = 1, max = 99 }: { qty: number; onChange: (v: number) => void; min?: number; max?: number }) {
  return (
    <div className="inline-flex items-center gap-1 bg-cream-100 rounded-lg p-0.5 border border-cream-200">
      <button
        type="button"
        onClick={() => onChange(Math.max(min, qty - 1))}
        className="w-6 h-6 rounded-md hover:bg-white text-primary-700 flex items-center justify-center"
      >
        <Minus className="w-3 h-3" />
      </button>
      <span className="w-7 text-center font-semibold text-primary-900 tabular-nums text-sm">{qty}</span>
      <button
        type="button"
        onClick={() => onChange(Math.min(max, qty + 1))}
        className="w-6 h-6 rounded-md hover:bg-white text-primary-700 flex items-center justify-center"
      >
        <Plus className="w-3 h-3" />
      </button>
    </div>
  )
}
