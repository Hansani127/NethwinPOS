import { useState, useMemo } from 'react'
import { User, Coins, Crown, X } from 'lucide-react'
import type { User as UserType, MemberTier } from '../../types'
import Badge from '../common/Badge'
import { cn } from '../../utils/cn'
import { useMemberSearchPOS } from '../../hooks/usePOS'

const tierBadge: Record<MemberTier, string> = {
  bronze: 'bg-orange-100 text-orange-800 border-orange-200',
  silver: 'bg-slate-200 text-slate-800 border-slate-300',
  gold: 'bg-accent-100 text-accent-800 border-accent-200',
  platinum: 'bg-indigo-100 text-indigo-800 border-indigo-200',
}

interface MemberLookupProps {
  selected: UserType | null
  onSelect: (u: UserType | null) => void
}

export default function MemberLookup({ selected, onSelect }: MemberLookupProps) {
  const [q, setQ] = useState('')
  const [open, setOpen] = useState(false)
  const { data: results, isLoading } = useMemberSearchPOS(q)

  const demoResults = useMemo(() => {
    if (!q || q.length < 2) return []
    const needle = q.toLowerCase()
    const base: UserType[] = [
      { id: '1', name: 'Victoria Ashford', email: 'v@ashford.co', role: 'user', tier: 'platinum', points: 12450 } as UserType,
      { id: '2', name: 'Dr. Samuel Reeves', email: 's@reeves.edu', role: 'user', tier: 'gold', points: 6820 } as UserType,
      { id: '3', name: 'Isabella Moreau', email: 'i@moreau.fr', role: 'user', tier: 'gold', points: 5240 } as UserType,
      { id: '4', name: 'James Whitmore', email: 'j@whitmore.io', role: 'user', tier: 'silver', points: 2180 } as UserType,
      { id: '5', name: 'Emily Chen', email: 'e@chen.art', role: 'user', tier: 'silver', points: 1950 } as UserType,
    ]
    return base.filter(u =>
      u.name.toLowerCase().includes(needle) ||
      u.email.toLowerCase().includes(needle) ||
      u.id.includes(needle),
    )
  }, [q])

  const displayResults: UserType[] = ((results as any)?.length || 0) > 0 ? ((results as any) || []) : demoResults

  if (selected) {
    const tier = selected.tier || 'bronze'
    return (
      <div className="relative">
        <div className="flex items-center gap-3 px-3 py-2 rounded-xl bg-accent-50 border border-accent-200">
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary-500 to-primary-700 text-white flex items-center justify-center font-semibold text-xs flex-shrink-0">
            {selected.name.split(' ').map(p => p[0]).slice(0, 2).join('')}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <p className="font-semibold text-primary-950 text-sm truncate">{selected.name}</p>
              <Badge className={cn(tierBadge[tier], 'text-[10px] h-5')}>
                <Crown className="w-3 h-3 mr-0.5" />
                {tier.charAt(0).toUpperCase() + tier.slice(1)}
              </Badge>
            </div>
            <p className="text-xs text-primary-800/70 flex items-center gap-1 truncate">
              <Coins className="w-3 h-3 text-accent-600 flex-shrink-0" />
              {(selected.points || 0).toLocaleString()} pts · {selected.email}
            </p>
          </div>
          <button
            onClick={() => onSelect(null)}
            className="w-7 h-7 rounded-lg text-primary-700 hover:bg-accent-100 flex items-center justify-center flex-shrink-0"
            aria-label="Remove member"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="relative">
      <div className="relative">
        <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cream-100/50" />
        <input
          type="text"
          value={q}
          onChange={(e) => { setQ(e.target.value); setOpen(true) }}
          onFocus={() => setOpen(true)}
          placeholder="Member lookup (name, email, ID)"
          className="w-full pl-9 pr-8 h-10 rounded-xl bg-white/10 border border-white/15 text-sm text-cream-50 placeholder:text-cream-100/50 focus:outline-none focus:ring-2 focus:ring-accent-500/40 focus:border-accent-500/60"
        />
        {q && (
          <button
            onClick={() => { setQ(''); onSelect(null); setOpen(false) }}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-cream-100/50 hover:text-cream-50"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {open && q.length >= 2 && (
        <>
          <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
          <div className="absolute z-40 left-0 right-0 mt-2 bg-white rounded-xl border border-cream-200 shadow-xl overflow-hidden">
            {isLoading ? (
              <div className="p-4 text-sm text-primary-800/60 text-center">Searching...</div>
            ) : displayResults.length === 0 ? (
              <div className="p-4 text-sm text-primary-800/60 text-center">No members found</div>
            ) : (
              <div className="max-h-72 overflow-y-auto">
                {displayResults.map((u) => {
                  const t = u.tier || 'bronze'
                  return (
                    <button
                      key={u.id}
                      onClick={() => { onSelect(u); setOpen(false); setQ('') }}
                      className="w-full flex items-center gap-3 p-3 hover:bg-cream-50 text-left border-b border-cream-100 last:border-0"
                    >
                      <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary-500 to-primary-700 text-white flex items-center justify-center font-semibold text-xs flex-shrink-0">
                        {u.name.split(' ').map(p => p[0]).slice(0, 2).join('')}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="font-medium text-primary-950 text-sm truncate">{u.name}</p>
                          <Badge className={cn(tierBadge[t], 'text-[10px] h-5')}>{t.charAt(0).toUpperCase() + t.slice(1)}</Badge>
                        </div>
                        <p className="text-xs text-primary-800/60 truncate">{u.email}</p>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <p className="font-bold text-accent-700 tabular-nums text-sm flex items-center justify-end gap-0.5">
                          <Coins className="w-3 h-3" />
                          {(u.points || 0).toLocaleString()}
                        </p>
                        <p className="text-[10px] text-primary-800/50">pts</p>
                      </div>
                    </button>
                  )
                })}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  )
}
