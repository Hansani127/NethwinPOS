from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.database import init_db
from app.routers import (
    auth_router,
    books_router,
    stationery_router,
    catalog_router,
    categories_router,
    cart_router,
    orders_router,
    upload_router,
    stripe_router,
    users_router,
    loyalty_router,
    preorders_router,
    pos_router,
    analytics_router,
)
from app.models.category import Category


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield


app = FastAPI(
    title="Nethwin Bookshop API",
    description="Backend API for Nethwin Bookshop",
    version="1.0.0",
    lifespan=lifespan,
)

Category.model_rebuild()

origins = [
    settings.FRONTEND_URL,
    "http://localhost:3000",
    "http://localhost:5173",
    "http://localhost:5174",
    "http://localhost:5175",
    "http://localhost:5176",
    "http://localhost:5177",
    "http://localhost:5178",
    "http://localhost:5179",
    "http://localhost:5180",
    "http://127.0.0.1:3000",
    "http://127.0.0.1:5173",
    "http://127.0.0.1:5174",
    "http://127.0.0.1:5175",
    "http://127.0.0.1:5176",
    "http://127.0.0.1:5177",
    "http://127.0.0.1:5178",
    "http://127.0.0.1:5179",
    "http://127.0.0.1:5180",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router, prefix="/api")
app.include_router(books_router, prefix="/api")
app.include_router(stationery_router, prefix="/api")
app.include_router(catalog_router, prefix="/api")
app.include_router(categories_router, prefix="/api")
app.include_router(cart_router, prefix="/api")
app.include_router(orders_router, prefix="/api")
app.include_router(upload_router, prefix="/api")
app.include_router(stripe_router, prefix="/api")
app.include_router(users_router, prefix="/api")
app.include_router(loyalty_router, prefix="/api")
app.include_router(preorders_router, prefix="/api")
app.include_router(pos_router, prefix="/api")
app.include_router(analytics_router, prefix="/api")


@app.get("/health", tags=["health"])
async def health_check():
    return {"status": "healthy"}
