from decimal import Decimal
from typing import Optional

POINTS_PER_DOLLAR: int = 1
POINT_VALUE_IN_DOLLARS: Decimal = Decimal("0.01")
MAX_REDEEM_PERCENT_OF_ORDER: float = 0.5

TIER_THRESHOLDS: list[tuple[str, Decimal]] = [
    ("Bronze", Decimal("0")),
    ("Silver", Decimal("250")),
    ("Gold", Decimal("1000")),
    ("Platinum", Decimal("5000")),
]

TIER_EARN_MULTIPLIERS: dict[str, float] = {
    "Bronze": 1,
    "Silver": 1.25,
    "Gold": 1.5,
    "Platinum": 2,
}


def tier_from_spent(total_spent: Decimal) -> str:
    tier = "Bronze"
    for name, threshold in TIER_THRESHOLDS:
        if total_spent >= threshold:
            tier = name
    return tier


def points_earned_for(total: Decimal, tier: str) -> int:
    multiplier = TIER_EARN_MULTIPLIERS.get(tier, 1)
    points = int((total * Decimal(str(POINTS_PER_DOLLAR)) * Decimal(str(multiplier))).to_integral_value())
    return max(0, points)


def discount_from_points(points: int) -> Decimal:
    if points <= 0:
        return Decimal("0")
    return (Decimal(str(points)) * POINT_VALUE_IN_DOLLARS).quantize(Decimal("0.01"))


def max_points_for_order(order_subtotal: Decimal) -> int:
    max_discount = (order_subtotal * Decimal(str(MAX_REDEEM_PERCENT_OF_ORDER))).quantize(Decimal("0.01"))
    if POINT_VALUE_IN_DOLLARS == Decimal("0"):
        return 0
    return int((max_discount / POINT_VALUE_IN_DOLLARS).to_integral_value())


def next_tier_info(current_tier: str, total_spent: Decimal) -> tuple[Optional[str], Optional[Decimal]]:
    tiers_in_order = [t[0] for t in TIER_THRESHOLDS]
    try:
        idx = tiers_in_order.index(current_tier)
    except ValueError:
        return None, None
    if idx + 1 >= len(tiers_in_order):
        return None, None
    next_name = tiers_in_order[idx + 1]
    next_threshold = TIER_THRESHOLDS[idx + 1][1]
    points_needed = (next_threshold - total_spent).quantize(Decimal("0.01"))
    if points_needed < Decimal("0"):
        points_needed = Decimal("0")
    return next_name, points_needed
