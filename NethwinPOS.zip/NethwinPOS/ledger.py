from beanie import Document, Link
from datetime import datetime
from typing import Optional
from pydantic import Field
from enum import Enum

from app.models.user import User


class TransactionType(str, Enum):
    EARN = "earn"
    REDEEM = "redeem"
    ADJUST = "adjust"
    BONUS = "bonus"


class PointsTransaction(Document):
    user_id: Link[User]
    type: TransactionType
    points: int
    balance_after: int
    source: str
    description: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)

    class Settings:
        name = "points_transactions"
