"""
One-shot MongoDB migration: convert mongoose-style books docs to Beanie Book schema.
Renames camelCase fields → snake_case, converts str→list types, drops stale fields.
"""
import asyncio
import re
from app.database import init_db, get_database


ADULT_CATEGORY_KEYWORDS = [
    "erotica", "erotic", "sexual behavior", "sexual custom", "sex custom",
    "pornography", "porn", "xxx", "18+", "nsfw", "x-rated", "x rated",
]


def category_is_adult(cat: str) -> bool:
    low = cat.lower()
    return any(k in low for k in ADULT_CATEGORY_KEYWORDS)


def split_authors(s) -> list[str]:
    if isinstance(s, list):
        return [str(x).strip() for x in s if str(x).strip()]
    if isinstance(s, str):
        parts = re.split(r"\s*;\s*|\s*,\s*|\s+&\s+|\s+and\s+", s)
        return [p.strip() for p in parts if p.strip()]
    return []


def split_categories(s) -> list[str]:
    if isinstance(s, list):
        return [str(x).strip() for x in s if str(x).strip()]
    if isinstance(s, str):
        parts = [p.strip() for p in s.split(",") if p.strip()]
        return parts
    return []


async def main():
    await init_db()
    db = await get_database()
    col = db["books"]
    total = await col.count_documents({})
    print(f"Books before migration: {total}")

    # Process each document in batches for speed (but safe, <10K docs)
    cursor = col.find({})
    updated = 0
    adult_flagged = 0

    async for raw in cursor:
        _id = raw["_id"]
        unset = {}
        set_ = {}

        # Authors: str -> list[str]
        if "authors" in raw:
            if not isinstance(raw["authors"], list):
                set_["authors"] = split_authors(raw["authors"])
        elif "author" in raw:
            set_["authors"] = split_authors(raw["author"])
            unset["author"] = 1

        # Categories: str 'category' -> list 'category_names'
        if "category" in raw:
            cats = split_categories(raw["category"])
            if cats:
                set_["category_names"] = cats
                if any(category_is_adult(c) for c in cats):
                    # For admin / audit trail we just mark is_adult (if we add a field, no - we don't
                    # add a field; we just track for stats. Filtering is done by checking category_names.
                    adult_flagged += 1
            unset["category"] = 1

        # Featured boolean
        if "featured" in raw and "is_featured" not in raw:
            set_["is_featured"] = bool(raw["featured"])
            unset["featured"] = 1
        if "isFeatured" in raw and "is_featured" not in raw:
            set_["is_featured"] = bool(raw["isFeatured"])
            unset["isFeatured"] = 1

        # Preorder flags
        if "isPreorder" in raw and "is_preorder" not in raw:
            set_["is_preorder"] = bool(raw["isPreorder"])
            unset["isPreorder"] = 1
        if "releaseDate" in raw and "preorder_release_date" not in raw:
            set_["preorder_release_date"] = raw["releaseDate"]
            unset["releaseDate"] = 1

        # ISBN
        if "isbn" in raw and "isbn13" not in raw:
            isbn_val = raw["isbn"]
            if isinstance(isbn_val, str) and len(isbn_val) == 13 and isbn_val.isdigit():
                set_["isbn13"] = isbn_val
            elif isinstance(isbn_val, str) and len(isbn_val) == 10 and isbn_val[:-1].isdigit():
                set_["isbn10"] = isbn_val
            else:
                set_["isbn13"] = str(isbn_val) if isbn_val else None
            unset["isbn"] = 1

        # Stock
        if "quantity" in raw and "stock" not in raw:
            try:
                set_["stock"] = int(raw["quantity"])
            except Exception:
                set_["stock"] = 0
            unset["quantity"] = 1

        # Rating
        if "rating" in raw and "average_rating" not in raw:
            try:
                set_["average_rating"] = float(raw["rating"])
            except Exception:
                pass
            unset["rating"] = 1

        # Thumbnail
        if "thumbnailUrl" in raw and "thumbnail" not in raw:
            set_["thumbnail"] = raw["thumbnailUrl"]
            unset["thumbnailUrl"] = 1
        if "cover" in raw and "thumbnail" not in raw:
            set_["thumbnail"] = raw["cover"]
            unset["cover"] = 1

        # Images list (use thumbnail as only image if no images)
        if "images" not in raw and set_.get("thumbnail"):
            set_["images"] = [set_["thumbnail"]]

        # Blurb -> description
        if "blurb" in raw and "description" not in raw:
            set_["description"] = raw["blurb"]
            unset["blurb"] = 1

        # Published year
        if "publishedYear" in raw and "published_year" not in raw:
            try:
                set_["published_year"] = int(float(raw["publishedYear"]))
            except Exception:
                pass
            unset["publishedYear"] = 1

        # is_active default True, migrate isActive
        if "isActive" in raw and "is_active" not in raw:
            set_["is_active"] = bool(raw["isActive"])
            unset["isActive"] = 1
        elif "is_active" not in raw:
            set_["is_active"] = True

        # Dates
        if "createdAt" in raw and "created_at" not in raw:
            set_["created_at"] = raw["createdAt"]
            unset["createdAt"] = 1
        if "updatedAt" in raw and "updated_at" not in raw:
            set_["updated_at"] = raw["updatedAt"]
            unset["updatedAt"] = 1

        # Stale mongoose fields
        for field in ("__v", "kind", "coverHue", "sku", "stockText"):
            if field in raw:
                unset[field] = 1

        # If nothing to change, skip
        if not set_ and not unset:
            continue

        update_doc = {}
        if set_:
            update_doc["$set"] = set_
        if unset:
            update_doc["$unset"] = unset
        await col.update_one({"_id": _id}, update_doc)
        updated += 1

    print(f"Migration complete. Updated {updated}/{total} docs.")
    print(f"Adult-category books identified: {adult_flagged}")

    # Final post-migration sanity: print sample
    print("\nSample post-migration docs:")
    async for d in col.find({}, limit=5):
        print(
            "  -",
            d.get("title"),
            "| category_names:",
            d.get("category_names"),
            "| is_featured:",
            d.get("is_featured"),
            "| thumb:",
            bool(d.get("thumbnail")),
        )


if __name__ == "__main__":
    asyncio.run(main())
