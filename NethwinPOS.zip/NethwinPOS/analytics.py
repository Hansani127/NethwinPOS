from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, HTTPException
from bson import ObjectId

from app.core.security import current_user
from app.models.user import User
from app.models.book import Book
from app.models.order import Order, OrderStatus, PaymentStatus

router = APIRouter(prefix="/analytics", tags=["analytics"])

@router.get("/dashboard")
async def get_dashboard_stats(user: User = Depends(current_user)):
    # Verify user is admin or manager
    if not user.is_superuser and user.staff_role not in ("manager", "cashier"):
        raise HTTPException(status_code=403, detail="Not authorized to view dashboard analytics")

    now = datetime.utcnow()
    thirty_days_ago = now - timedelta(days=30)
    sixty_days_ago = now - timedelta(days=60)

    # 1. Query all orders, books, and users
    all_orders = await Order.find_all().to_list()
    books = await Book.find_all().to_list()
    all_users = await User.find_all().to_list()

    # 2. Revenue & Orders Count calculations
    # Paid/Completed orders
    paid_orders = [
        o for o in all_orders 
        if o.payment_status == PaymentStatus.PAID or o.status in (OrderStatus.PAID, OrderStatus.DELIVERED, OrderStatus.SHIPPED)
    ]
    
    total_revenue = sum(float(o.total) for o in paid_orders)
    total_orders = len(all_orders)

    # Last 30 days vs previous 30 days (days 31-60)
    orders_last_30 = [o for o in all_orders if o.created_at >= thirty_days_ago]
    orders_prev_30 = [o for o in all_orders if sixty_days_ago <= o.created_at < thirty_days_ago]

    # Revenue last 30 vs prev 30
    rev_last_30 = sum(
        float(o.total) for o in orders_last_30 
        if o.payment_status == PaymentStatus.PAID or o.status in (OrderStatus.PAID, OrderStatus.DELIVERED, OrderStatus.SHIPPED)
    )
    rev_prev_30 = sum(
        float(o.total) for o in orders_prev_30 
        if o.payment_status == PaymentStatus.PAID or o.status in (OrderStatus.PAID, OrderStatus.DELIVERED, OrderStatus.SHIPPED)
    )

    if rev_prev_30 > 0:
        rev_change = ((rev_last_30 - rev_prev_30) / rev_prev_30) * 100
    else:
        rev_change = 0.0 if rev_last_30 == 0 else 100.0

    # Orders count changes
    count_last_30 = len(orders_last_30)
    count_prev_30 = len(orders_prev_30)
    if count_prev_30 > 0:
        orders_change = ((count_last_30 - count_prev_30) / count_prev_30) * 100
    else:
        orders_change = 0.0 if count_last_30 == 0 else 100.0

    # 3. Books in Stock calculations
    total_books_in_stock = sum(b.stock for b in books if b.stock is not None)
    
    # Calculate stock change based on books added in last 30 days vs previous
    books_last_30 = [b for b in books if getattr(b, "created_at", now) >= thirty_days_ago]
    stock_last_30 = sum(b.stock for b in books_last_30 if b.stock is not None)
    total_stock_prev = total_books_in_stock - stock_last_30
    if total_stock_prev > 0:
        stock_change = (stock_last_30 / total_stock_prev) * 100
    else:
        stock_change = 0.0 if stock_last_30 == 0 else 100.0

    # 4. Customers calculations
    customers = [u for u in all_users if not u.is_superuser and u.staff_role is None]
    total_customers = len(customers)

    cust_last_30 = [u for u in customers if u.joined_at >= thirty_days_ago]
    cust_prev_30 = [u for u in customers if sixty_days_ago <= u.joined_at < thirty_days_ago]
    cust_count_last = len(cust_last_30)
    cust_count_prev = len(cust_prev_30)
    if cust_count_prev > 0:
        cust_change = ((cust_count_last - cust_count_prev) / cust_count_prev) * 100
    else:
        cust_change = 0.0 if cust_count_last == 0 else 100.0

    # 5. Daily revenue last 30 days
    daily_revenue = []
    for d in range(30):
        day_start = now - timedelta(days=29 - d)
        day_start = day_start.replace(hour=0, minute=0, second=0, microsecond=0)
        day_end = day_start + timedelta(days=1)
        
        day_orders = [o for o in all_orders if day_start <= o.created_at < day_end]
        day_rev = sum(
            float(o.total) for o in day_orders 
            if o.payment_status == PaymentStatus.PAID or o.status in (OrderStatus.PAID, OrderStatus.DELIVERED, OrderStatus.SHIPPED)
        )
        daily_revenue.append({
            "date": day_start.strftime("%b %d"),
            "revenue": day_rev
        })

    # 6. Top Categories calculations
    book_category_map = {}
    for b in books:
        cats = b.category_names or []
        if b.isbn13:
            book_category_map[b.isbn13] = cats
        if b.title:
            book_category_map[b.title.lower()] = cats

    category_sales = {}
    for o in paid_orders:
        for item in o.items:
            cats = []
            if item.isbn and item.isbn in book_category_map:
                cats = book_category_map[item.isbn]
            elif item.title and item.title.lower() in book_category_map:
                cats = book_category_map[item.title.lower()]
            
            if not cats:
                cats = ['Fiction']  # Fallback to Fiction if unspecified

            for cat in cats:
                category_sales[cat] = category_sales.get(cat, 0) + item.quantity

    sorted_cats = sorted(category_sales.items(), key=lambda x: x[1], reverse=True)
    top_categories = []
    max_sold = sorted_cats[0][1] if sorted_cats else 1
    
    colors = ['bg-primary-500', 'bg-rose-500', 'bg-amber-500', 'bg-indigo-500', 'bg-emerald-500']
    for idx, (cat_name, sold) in enumerate(sorted_cats[:5]):
        color = colors[idx % len(colors)]
        pct = int((sold / max_sold) * 100) if max_sold > 0 else 0
        top_categories.append({
            "name": cat_name,
            "sold": sold,
            "pct": pct,
            "color": color
        })

    # If no sales have occurred yet, fallback to default seed-like list but with 0 sold
    if not top_categories:
        default_cats = ['Fiction', 'Romance', 'Mystery', 'Sci-Fi', 'Classics']
        for idx, cat_name in enumerate(default_cats):
            top_categories.append({
                "name": cat_name,
                "sold": 0,
                "pct": 0,
                "color": colors[idx % len(colors)]
            })

    return {
        "stats": {
            "totalRevenue": total_revenue,
            "revenueChange": round(rev_change, 1),
            "totalOrders": total_orders,
            "ordersChange": round(orders_change, 1),
            "booksInStock": total_books_in_stock,
            "stockChange": round(stock_change, 1),
            "totalCustomers": total_customers,
            "customersChange": round(cust_change, 1)
        },
        "dailyRevenue": daily_revenue,
        "topCategories": top_categories
    }


@router.get("/financials")
async def get_financial_reports(period: str = "month", user: User = Depends(current_user)):
    if not user.is_superuser and user.staff_role not in ("manager", "cashier"):
        raise HTTPException(status_code=403, detail="Not authorized to view financial analytics")

    now = datetime.utcnow()
    
    days = 30
    if period == "week":
        days = 7
    elif period == "quarter":
        days = 90
    elif period == "year":
        days = 365

    current_start = now - timedelta(days=days)
    prev_start = now - timedelta(days=days * 2)

    orders = await Order.find(Order.created_at >= prev_start).to_list()

    def calculate_metrics(order_list):
        paid = [
            o for o in order_list 
            if o.payment_status == PaymentStatus.PAID or o.status in (OrderStatus.PAID, OrderStatus.DELIVERED, OrderStatus.SHIPPED)
        ]
        refunded = [
            o for o in order_list 
            if o.payment_status == PaymentStatus.REFUNDED or o.status == OrderStatus.CANCELLED
        ]

        rev = sum(float(o.total) for o in paid)
        pos = sum(float(o.total) for o in paid if getattr(o, "source", "web") == "pos")
        web = sum(float(o.total) for o in paid if getattr(o, "source", "web") != "pos")
        ref = sum(float(o.total) for o in refunded)

        exp = rev * 0.7
        prof = max(0.0, rev - exp - ref)

        return {
            "totalRevenue": rev,
            "netProfit": prof,
            "totalExpenses": exp,
            "posRevenue": pos,
            "onlineRevenue": web,
            "refundsIssued": ref
        }

    current_orders = [o for o in orders if o.created_at >= current_start]
    prev_orders = [o for o in orders if prev_start <= o.created_at < current_start]

    curr_m = calculate_metrics(current_orders)
    prev_m = calculate_metrics(prev_orders)

    def get_change(curr_val, prev_val):
        if prev_val == 0:
            return 0.0 if curr_val == 0 else 100.0
        return round(((curr_val - prev_val) / prev_val) * 100, 1)

    return {
        "period": period,
        "metrics": {
            "totalRevenue": {
                "value": curr_m["totalRevenue"],
                "change": get_change(curr_m["totalRevenue"], prev_m["totalRevenue"]),
                "up": curr_m["totalRevenue"] >= prev_m["totalRevenue"]
            },
            "netProfit": {
                "value": curr_m["netProfit"],
                "change": get_change(curr_m["netProfit"], prev_m["netProfit"]),
                "up": curr_m["netProfit"] >= prev_m["netProfit"]
            },
            "totalExpenses": {
                "value": curr_m["totalExpenses"],
                "change": get_change(curr_m["totalExpenses"], prev_m["totalExpenses"]),
                "up": curr_m["totalExpenses"] < prev_m["totalExpenses"]
            },
            "posRevenue": {
                "value": curr_m["posRevenue"],
                "change": get_change(curr_m["posRevenue"], prev_m["posRevenue"]),
                "up": curr_m["posRevenue"] >= prev_m["posRevenue"]
            },
            "onlineRevenue": {
                "value": curr_m["onlineRevenue"],
                "change": get_change(curr_m["onlineRevenue"], prev_m["onlineRevenue"]),
                "up": curr_m["onlineRevenue"] >= prev_m["onlineRevenue"]
            },
            "refundsIssued": {
                "value": curr_m["refundsIssued"],
                "change": get_change(curr_m["refundsIssued"], prev_m["refundsIssued"]),
                "up": curr_m["refundsIssued"] <= prev_m["refundsIssued"]
            }
        }
    }

