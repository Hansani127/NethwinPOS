import { Link, useNavigate } from '../../utils/router-compat'
import { useState, useEffect } from 'react'

import { BookOpen, Search, ShoppingCart, User, Menu, X, LogOut, Settings, LayoutDashboard, Calculator } from 'lucide-react'
import { cn } from '../../utils/cn'
import { useAuthStore } from '../../store/authStore'
import { useCart } from '../../hooks/useCart'
import Button from '../common/Button'

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [userMenuOpen, setUserMenuOpen] = useState(false)
  const navigate = useNavigate()
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated)
  const user = useAuthStore((s) => s.user)
  const logout = useAuthStore((s) => s.logout)
  const { totalItems } = useCart()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll)
    onScroll()
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    const q = searchQuery.trim()
    navigate(`/books${q ? `?search=${encodeURIComponent(q)}` : ''}`)
    setSearchQuery('')
  }

  const handleLogout = () => {
    logout()
    setUserMenuOpen(false)
    navigate('/')
  }

  const navLinks = [
    { href: '/', label: 'Home' },
    { href: '/books', label: 'Catalog' },
    { href: '/preorders', label: 'Pre-Orders' },
    { href: '/membership', label: 'Membership' },
    { href: '/checkout', label: 'Checkout' },
  ]

  return (
    <header
      className={cn(
        'sticky top-0 z-50 transition-all duration-300',
        scrolled
          ? 'bg-cream-50/90 backdrop-blur-md shadow-sm border-b border-cream-200'
          : 'bg-transparent',
      )}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <Link href="/" className="flex items-center group">
            <img src="/logo.svg" alt="Nethwin Printers Logo" className="h-12 w-auto transition-transform duration-300 group-hover:scale-[1.03]" />
          </Link>

          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((l) => (
              <Link
                key={l.href}
                to={l.href}
                className="text-sm font-medium text-primary-900/80 hover:text-primary-700 transition-colors"
              >
                {l.label}
              </Link>
            ))}
          </nav>

          <form onSubmit={handleSearch} className="hidden lg:flex items-center relative w-72">
            <Search className="absolute left-3 w-4 h-4 text-primary-900/40" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search books, authors..."
              className="w-full pl-10 pr-4 py-2 bg-white border border-cream-300 rounded-full text-sm text-primary-900 placeholder:text-primary-900/40 focus:outline-none focus:ring-2 focus:ring-primary-500/30 focus:border-primary-500 transition-all"
            />
          </form>

          <div className="flex items-center gap-2">
            <Link href="/cart"
              className="relative p-2 rounded-full text-primary-900/80 hover:text-primary-700 hover:bg-cream-200/60 transition-colors"
              aria-label="Cart"
            >
              <ShoppingCart className="w-5 h-5" />
              {totalItems > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-accent-500 text-white text-xs font-bold rounded-full flex items-center justify-center shadow-sm">
                  {totalItems > 99 ? '99+' : totalItems}
                </span>
              )}
            </Link>

            {isAuthenticated ? (
              <div className="relative">
                <button
                  onClick={() => setUserMenuOpen((v) => !v)}
                  className="flex items-center gap-2 p-2 rounded-full hover:bg-cream-200/60 transition-colors"
                >
                  {user?.avatar ? (
                    <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full object-cover" />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center text-primary-700">
                      <User className="w-4 h-4" />
                    </div>
                  )}
                </button>
                {userMenuOpen && (
                  <>
                    <div className="fixed inset-0 z-10" onClick={() => setUserMenuOpen(false)} />
                    <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-cream-200 py-2 z-20">
                      <div className="px-4 py-2 border-b border-cream-100">
                        <p className="text-sm font-semibold text-primary-900">{user?.name}</p>
                        <p className="text-xs text-primary-900/60">{user?.email}</p>
                      </div>
                      <Link href="/profile"
                        onClick={() => setUserMenuOpen(false)}
                        className="flex items-center gap-3 w-full px-4 py-2 text-sm text-primary-900/80 hover:bg-cream-100 hover:text-primary-700"
                      >
                        <Settings className="w-4 h-4" /> Profile
                      </Link>
                      {['admin', 'manager', 'cashier'].includes(user?.role || '') && (
                        <Link href="/pos"
                          onClick={() => setUserMenuOpen(false)}
                          className="flex items-center gap-3 w-full px-4 py-2 text-sm text-primary-900/80 hover:bg-cream-100 hover:text-primary-700"
                        >
                          <Calculator className="w-4 h-4" /> POS Terminal
                        </Link>
                      )}
                      {(user?.role === 'admin' || user?.role === 'manager') && (
                        <Link href="/admin"
                          onClick={() => setUserMenuOpen(false)}
                          className="flex items-center gap-3 w-full px-4 py-2 text-sm text-primary-900/80 hover:bg-cream-100 hover:text-primary-700"
                        >
                          <LayoutDashboard className="w-4 h-4" /> Dashboard
                        </Link>
                      )}
                      <button
                        onClick={handleLogout}
                        className="flex items-center gap-3 w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50"
                      >
                        <LogOut className="w-4 h-4" /> Logout
                      </button>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <Button variant="primary" size="sm" onClick={() => navigate('/auth')}>
                Sign In
              </Button>
            )}

            <button
              onClick={() => setMobileOpen((v) => !v)}
              className="md:hidden p-2 rounded-full text-primary-900/80 hover:bg-cream-200/60"
              aria-label="Toggle menu"
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {mobileOpen && (
          <div className="md:hidden py-4 border-t border-cream-200 space-y-4">
            <form onSubmit={handleSearch} className="flex items-center relative">
              <Search className="absolute left-3 w-4 h-4 text-primary-900/40" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search books..."
                className="w-full pl-10 pr-4 py-2 bg-white border border-cream-300 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-primary-500/30"
              />
            </form>
            <nav className="flex flex-col gap-1">
              {navLinks.map((l) => (
                <Link
                  key={l.href}
                  to={l.href}
                  onClick={() => setMobileOpen(false)}
                  className="px-3 py-2 rounded-lg text-sm font-medium text-primary-900/80 hover:bg-cream-200/60"
                >
                  {l.label}
                </Link>
              ))}
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
