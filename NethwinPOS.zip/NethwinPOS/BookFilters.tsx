import { useMemo, useState, useEffect } from 'react'
import {
  Search,
  SlidersHorizontal,
  X,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Grid3X3,
  List,
  LayoutList,
} from 'lucide-react'
import Input from '../common/Input'
import Select from '../common/Select'
import Button from '../common/Button'
import Badge from '../common/Badge'
import type { BookFilters, Category } from '../../types'
import { cn } from '../../utils/cn'

interface BookFiltersProps {
  categories?: Category[]
  filters: BookFilters
  onFilterChange: (filters: BookFilters) => void
  className?: string
  includeProductType?: boolean
  availableCategories?: string[]
  totalCount?: number
  booksCount?: number
  stationeryCount?: number
  viewMode?: 'grid' | 'list' | 'compact'
  onViewModeChange?: (mode: 'grid' | 'list' | 'compact') => void
}

const sortOptions = [
  { value: '', label: 'Featured · Recommended' },
  { value: 'newest', label: 'Newest Arrivals' },
  { value: 'price-asc', label: 'Price: Low → High' },
  { value: 'price-desc', label: 'Price: High → Low' },
  { value: 'rating-desc', label: 'Customer Rating' },
  { value: 'name-asc', label: 'Name: A → Z' },
]

const priceRanges = [
  { label: 'All Prices', min: undefined, max: undefined },
  { label: 'Under Rs. 1,000', min: 0, max: 1000 },
  { label: 'Rs. 1,000 – Rs. 5,000', min: 1000, max: 5000 },
  { label: 'Rs. 5,000 – Rs. 10,000', min: 5000, max: 10000 },
  { label: 'Rs. 10,000 – Rs. 25,000', min: 10000, max: 25000 },
  { label: 'Rs. 25,000+', min: 25000, max: undefined },
]

const stationeryCategories = [
  { label: 'Writing Instruments' },
  { label: 'Notebooks & Journals' },
  { label: 'Planners & Organizers' },
  { label: 'Pads, Paper & Cards' },
  { label: 'Desk Accessories' },
  { label: 'Art & Craft Supplies' },
  { label: 'Office Essentials' },
  { label: 'Gift & Accessories' },
]

const pageSizeOptions = [
  { value: '12', label: '12 per page' },
  { value: '24', label: '24 per page' },
  { value: '48', label: '48 per page' },
  { value: '96', label: '96 per page' },
]

interface SectionProps {
  title: string
  icon?: React.ReactNode
  children: React.ReactNode
  defaultOpen?: boolean
  count?: number
}

function FilterSection({ title, icon, children, defaultOpen = true, count }: SectionProps) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div className="border-b border-cream-200 last:border-b-0 pb-5 mb-5 last:pb-0 last:mb-0">
      <button
        type="button"
        onClick={() => setOpen(v => !v)}
        className="w-full flex items-center justify-between gap-2 group"
      >
        <div className="flex items-center gap-2">
          {icon && <span className="text-primary-600">{icon}</span>}
          <h4 className="text-sm font-semibold text-primary-950 uppercase tracking-wider">
            {title}
          </h4>
          {count !== undefined && count > 0 && (
            <Badge variant="primary" className="h-5 px-1.5 text-[10px]">
              {count}
            </Badge>
          )}
        </div>
        {open ? (
          <ChevronUp className="w-4 h-4 text-primary-900/50 group-hover:text-primary-800 transition-colors" />
        ) : (
          <ChevronDown className="w-4 h-4 text-primary-900/50 group-hover:text-primary-800 transition-colors" />
        )}
      </button>
      {open && <div className="mt-3.5">{children}</div>}
    </div>
  )
}

export default function BookFilters({
  categories,
  filters,
  onFilterChange,
  className,
  includeProductType,
  availableCategories,
  totalCount,
  booksCount,
  stationeryCount,
  viewMode,
  onViewModeChange,
}: BookFiltersProps) {
  const [searchInput, setSearchInput] = useState(filters.search || '')

  useEffect(() => {
    setSearchInput(filters.search || '')
  }, [filters.search])

  useEffect(() => {
    const t = setTimeout(() => {
      if (searchInput !== (filters.search || '')) {
        onFilterChange({ ...filters, search: searchInput || undefined, page: 1 })
      }
    }, 350)
    return () => clearTimeout(t)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchInput])

  const { bookCats, stationeryCats } = useMemo(() => {
    const bookCats: { value: string; label: string }[] = []
    const avail = new Set(availableCategories || [])
    if (categories) {
      categories.forEach(c => {
        if (c.type === 'stationery') return
        const label = c.name
        const value = c.slug || String(c.id)
        if (availableCategories && avail.size > 0 && !avail.has(value) && !avail.has(label)) return
        bookCats.push({ value, label })
      })
    }
    const stationeryCats = stationeryCategories.map(c => ({
      value: c.label,
      label: c.label,
    })).filter(c => {
      if (!availableCategories || avail.size === 0) return true
      return avail.has(c.value) || avail.has(c.label)
    })
    return { bookCats, stationeryCats }
  }, [categories, availableCategories])

  const activeChips: { key: string; label: string; onRemove: () => void }[] = []
  if (filters.search) {
    activeChips.push({
      key: 'search',
      label: `“${filters.search}”`,
      onRemove: () => {
        setSearchInput('')
        onFilterChange({ ...filters, search: undefined, page: 1 })
      },
    })
  }
  if (filters.category) {
    activeChips.push({
      key: 'category',
      label: filters.category,
      onRemove: () =>
        onFilterChange({ ...filters, category: undefined, categoryId: undefined, page: 1 }),
    })
  }
  if (filters.minPrice != null || filters.maxPrice != null) {
    const r = priceRanges.find(
      r => r.min === filters.minPrice && r.max === filters.maxPrice,
    )
    activeChips.push({
      key: 'price',
      label: r?.label || 'Custom price',
      onRemove: () =>
        onFilterChange({ ...filters, minPrice: undefined, maxPrice: undefined, page: 1 }),
    })
  }
  if (filters.featured) {
    activeChips.push({
      key: 'featured',
      label: 'Featured',
      onRemove: () => onFilterChange({ ...filters, featured: undefined, page: 1 }),
    })
  }
  if (filters.sort) {
    const sortLabel = sortOptions.find(s => s.value === filters.sort)?.label
    if (sortLabel) {
      activeChips.push({
        key: 'sort',
        label: `Sort: ${sortLabel}`,
        onRemove: () => onFilterChange({ ...filters, sort: undefined, page: 1 }),
      })
    }
  }

  const clearAll = () => {
    setSearchInput('')
    onFilterChange({
      categoryId: undefined,
      category: undefined,
      search: undefined,
      minPrice: undefined,
      maxPrice: undefined,
      sort: undefined,
      featured: undefined,
      productType: 'all',
      page: 1,
      page_size: filters.page_size,
    })
  }

  const productTypeOptions = [
    { value: 'all', label: 'All Products', count: totalCount ?? 0 },
    { value: 'book', label: 'Books', count: booksCount ?? 0 },
    { value: 'stationery', label: 'Stationery', count: stationeryCount ?? 0 },
  ]

  const currentPriceRange = priceRanges.find(
    r => r.min === filters.minPrice && r.max === filters.maxPrice,
  )

  return (
    <aside className={`space-y-5 ${className}`}>
      <div className="flex items-center justify-between">
        <h3 className="font-serif text-xl font-semibold text-primary-950 flex items-center gap-2">
          <SlidersHorizontal className="w-5 h-5 text-primary-600" />
          Filters
        </h3>
        {activeChips.length > 0 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={clearAll}
            className="gap-1 text-primary-700 h-8"
          >
            <X className="w-3.5 h-3.5" />
            Reset
          </Button>
        )}
      </div>

      {activeChips.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {activeChips.map(chip => (
            <button
              key={chip.key}
              onClick={chip.onRemove}
              className="inline-flex items-center gap-1 pl-2.5 pr-1.5 py-1 rounded-full bg-primary-50 border border-primary-200 text-xs font-semibold text-primary-800 hover:bg-primary-100 hover:border-primary-300 transition-colors"
            >
              {chip.label}
              <span className="w-4 h-4 rounded-full bg-primary-200/70 flex items-center justify-center text-primary-700">
                <X className="w-2.5 h-2.5" />
              </span>
            </button>
          ))}
        </div>
      )}

      <div className="p-5 bg-white rounded-2xl border border-cream-200 shadow-sm">
        <FilterSection title="Search" icon={<Search className="w-4 h-4" />}>
          <Input
            placeholder="Search title, author, ISBN…"
            leftIcon={<Search className="w-4 h-4" />}
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
          />
        </FilterSection>

        {includeProductType && (
          <FilterSection title="Browse" icon={<Grid3X3 className="w-4 h-4" />}>
            <div className="grid grid-cols-3 gap-2">
              {productTypeOptions.map(opt => {
                const isActive = (filters.productType || 'all') === opt.value
                return (
                  <button
                    key={opt.value}
                    onClick={() =>
                      onFilterChange({
                        ...filters,
                        productType: opt.value as BookFilters['productType'],
                        category: undefined,
                        categoryId: undefined,
                        page: 1,
                      })
                    }
                    className={cn(
                      'flex flex-col items-center justify-center gap-0.5 px-1 py-2.5 rounded-xl text-[11px] font-semibold transition-all border',
                      isActive
                        ? 'bg-primary-700 text-white border-primary-700 shadow-sm shadow-primary-700/20'
                        : 'bg-cream-50 text-primary-800/80 border-cream-200 hover:bg-cream-100 hover:border-cream-300',
                    )}
                  >
                    <span className="text-sm tabular-nums font-bold">{opt.count}</span>
                    <span className="text-[10px] font-semibold opacity-90">{opt.label.split(' ')[0]}</span>
                  </button>
                )
              })}
            </div>
          </FilterSection>
        )}

        <FilterSection title="Sort & Display" icon={<List className="w-4 h-4" />}>
          <div className="space-y-3">
            <Select
              options={sortOptions}
              value={filters.sort || ''}
              onChange={(e) =>
                onFilterChange({
                  ...filters,
                  sort: (e.target.value as BookFilters['sort']) || undefined,
                  page: 1,
                })
              }
            />
            <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-cream-100 border border-cream-200">
              {(['grid', 'list', 'compact'] as const).map(mode => {
                const Icon =
                  mode === 'grid' ? Grid3X3 : mode === 'list' ? List : LayoutList
                const active = viewMode === mode
                return (
                  <button
                    key={mode}
                    onClick={() => onViewModeChange?.(mode)}
                    className={cn(
                      'flex items-center justify-center h-8 rounded-lg text-xs font-semibold transition-colors',
                      active
                        ? 'bg-white text-primary-800 shadow-sm'
                        : 'text-primary-800/60 hover:text-primary-800',
                    )}
                    title={mode[0].toUpperCase() + mode.slice(1) + ' view'}
                  >
                    <Icon className="w-4 h-4" />
                  </button>
                )
              })}
            </div>
            <Select
              options={pageSizeOptions}
              value={String(filters.page_size || 12)}
              onChange={(e) =>
                onFilterChange({
                  ...filters,
                  page_size: Number(e.target.value),
                  page: 1,
                })
              }
            />
          </div>
        </FilterSection>

        <FilterSection
          title="Book Categories"
          icon={<Sparkles className="w-4 h-4" />}
          count={bookCats.length}
        >
          <div className="flex flex-wrap gap-1.5 max-h-56 overflow-y-auto pr-1">
            <button
              onClick={() =>
                onFilterChange({
                  ...filters,
                  category: undefined,
                  categoryId: undefined,
                  page: 1,
                })
              }
              className={cn(
                'px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors',
                !filters.category
                  ? 'bg-primary-700 text-white border-primary-700'
                  : 'bg-white text-primary-800/80 border-cream-200 hover:bg-cream-50 hover:border-cream-300',
              )}
            >
              All Books
            </button>
            {bookCats.map(cat => {
              const isActive =
                filters.category === cat.value || filters.category === cat.label
              return (
                <button
                  key={cat.value}
                  onClick={() =>
                    onFilterChange({ ...filters, category: cat.value, categoryId: undefined, page: 1 })
                  }
                  className={cn(
                    'px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors',
                    isActive
                      ? 'bg-primary-700 text-white border-primary-700'
                      : 'bg-white text-primary-800/80 border-cream-200 hover:bg-cream-50 hover:border-cream-300',
                  )}
                >
                  {cat.label}
                </button>
              )
            })}
          </div>
        </FilterSection>

        <FilterSection
          title="Stationery"
          icon={<Sparkles className="w-4 h-4" />}
          count={stationeryCats.length}
        >
          <div className="space-y-1 max-h-52 overflow-y-auto pr-1">
            {stationeryCats.map(cat => {
              const isActive =
                filters.category === cat.value || filters.category === cat.label
              return (
                <button
                  key={cat.value}
                  onClick={() =>
                    onFilterChange({
                      ...filters,
                      category: isActive ? undefined : cat.value,
                      categoryId: undefined,
                      page: 1,
                    })
                  }
                  className={cn(
                    'w-full flex items-center justify-between gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-colors border',
                    isActive
                      ? 'bg-primary-50 text-primary-800 border-primary-200'
                      : 'bg-white text-primary-800/80 border-transparent hover:bg-cream-50 hover:border-cream-200',
                  )}
                >
                  <span>{cat.label}</span>
                  <span
                    className={cn(
                      'w-4 h-4 rounded-full border flex items-center justify-center transition-colors',
                      isActive
                        ? 'bg-primary-600 border-primary-600 text-white'
                        : 'border-cream-300',
                    )}
                  >
                    {isActive && <span className="w-2 h-2 rounded-full bg-white" />}
                  </span>
                </button>
              )
            })}
          </div>
        </FilterSection>

        <FilterSection title="Price Range" icon={<Sparkles className="w-4 h-4" />}>
          <div className="space-y-1.5">
            {priceRanges.map(range => {
              const isActive = currentPriceRange === range
              return (
                <button
                  key={range.label}
                  onClick={() =>
                    onFilterChange({
                      ...filters,
                      minPrice: range.min,
                      maxPrice: range.max,
                      page: 1,
                    })
                  }
                  className={cn(
                    'w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-semibold transition-colors border',
                    isActive
                      ? 'bg-accent-50 text-accent-800 border-accent-200'
                      : 'text-primary-800/80 hover:bg-cream-50 border-transparent',
                  )}
                >
                  <span>{range.label}</span>
                  {isActive && <CheckCircleMark />}
                </button>
              )
            })}
          </div>
        </FilterSection>

        <FilterSection title="Quick Toggles" icon={<Sparkles className="w-4 h-4" />}>
          <div className="grid grid-cols-2 gap-2">
            <ToggleChip
              label="Featured Only"
              active={!!filters.featured}
              onClick={() =>
                onFilterChange({ ...filters, featured: filters.featured ? undefined : true, page: 1 })
              }
            />
            <ToggleChip
              label="Pre-Orders"
              active={filters.productType === 'preorder'}
              onClick={() =>
                onFilterChange({
                  ...filters,
                  productType: filters.productType === 'preorder' ? 'all' : 'preorder',
                  page: 1,
                })
              }
            />
            <ToggleChip
              label="In Stock"
              active={false}
              onClick={() => {}}
              disabled
            />
            <ToggleChip
              label="On Sale"
              active={false}
              onClick={() => {}}
              disabled
            />
          </div>
        </FilterSection>
      </div>
    </aside>
  )
}

function CheckCircleMark() {
  return (
    <span className="w-4 h-4 rounded-full bg-accent-500 text-white flex items-center justify-center shadow-sm">
      <svg viewBox="0 0 20 20" fill="currentColor" className="w-2.5 h-2.5">
        <path
          fillRule="evenodd"
          d="M16.704 5.29a1 1 0 010 1.42l-7.5 7.5a1 1 0 01-1.42 0l-3.5-3.5a1 1 0 111.42-1.42L8.5 12.08l6.79-6.79a1 1 0 011.414 0z"
          clipRule="evenodd"
        />
      </svg>
    </span>
  )
}

function ToggleChip({
  label,
  active,
  onClick,
  disabled,
}: {
  label: string
  active: boolean
  onClick: () => void
  disabled?: boolean
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={cn(
        'px-3 py-2 rounded-xl text-xs font-semibold border transition-all',
        disabled && 'opacity-40 cursor-not-allowed',
        active
          ? 'bg-primary-700 text-white border-primary-700 shadow-sm'
          : 'bg-white text-primary-800/80 border-cream-200 hover:bg-cream-50 hover:border-cream-300',
      )}
    >
      {label}
    </button>
  )
}
