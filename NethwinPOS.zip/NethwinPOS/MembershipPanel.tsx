import { useState, useMemo } from 'react'
import {
  Crown, Coins, Gift, Sparkles, Truck, Star, Calendar, ArrowUp, ArrowDown,
  BookOpen, BadgeCheck,
} from 'lucide-react'
import type { Loyalty, LoyaltyHistoryEntry, MemberTier } from '../../types'
import { formatCurrency } from '../../utils/formatCurrency'
import { formatDateShort } from '../../utils/formatDate'
import { cn } from '../../utils/cn'
import Badge from '../common/Badge'
import { Card } from '../common/Card'
import { useMyLoyalty, useLoyaltyHistory } from '../../hooks/useLoyalty'
import LoadingSpinner from '../common/LoadingSpinner'

const tierConfig: Record<MemberTier, {
  threshold: number
  color: string
  bg: string
  border: string
  text: string
  dark: string
  light: string
  progress: string
  label: string
  multiplier: string
  birthday: string
}> = {
  bronze: {
    threshold: 0,
    color: 'from-orange-500 to-orange-700',
    bg: 'bg-orange-50',
    border: 'border-orange-200',
    text: 'text-orange-800',
    dark: 'bg-orange-700',
    light: 'bg-orange-100',
    progress: 'bg-gradient-to-r from-orange-400 to-orange-600',
    label: 'Bronze',
    multiplier: '1x',
    birthday: 'Rs. 500',
  },
  silver: {
    threshold: 15000,
    color: 'from-slate-400 to-slate-600',
    bg: 'bg-slate-50',
    border: 'border-slate-200',
    text: 'text-slate-800',
    dark: 'bg-slate-600',
    light: 'bg-slate-100',
    progress: 'bg-gradient-to-r from-slate-400 to-slate-600',
    label: 'Silver',
    multiplier: '1.25x',
    birthday: 'Rs. 1,000',
  },
  gold: {
    threshold: 45000,
    color: 'from-accent-400 to-accent-600',
    bg: 'bg-accent-50',
    border: 'border-accent-200',
    text: 'text-accent-800',
    dark: 'bg-accent-600',
    light: 'bg-accent-100',
    progress: 'bg-gradient-to-r from-accent-400 to-accent-600',
    label: 'Gold',
    multiplier: '1.5x',
    birthday: 'Rs. 2,500',
  },
  platinum: {
    threshold: 150000,
    color: 'from-indigo-500 to-indigo-700',
    bg: 'bg-indigo-50',
    border: 'border-indigo-200',
    text: 'text-indigo-800',
    dark: 'bg-indigo-700',
    light: 'bg-indigo-100',
    progress: 'bg-gradient-to-r from-indigo-400 to-indigo-600',
    label: 'Platinum',
    multiplier: '2x',
    birthday: 'Rs. 5,000',
  },
}

const TIERS_ORDER: MemberTier[] = ['bronze', 'silver', 'gold', 'platinum']

function computeTier(spend: number): MemberTier {
  if (spend >= 150000) return 'platinum'
  if (spend >= 45000) return 'gold'
  if (spend >= 15000) return 'silver'
  return 'bronze'
}

export default function MembershipPanel() {
  const [tab, setTab] = useState<'history' | 'tiers'>('history')
  const { data: loyalty } = useMyLoyalty()
  const { data: historyRaw, isLoading: loadingHistory } = useLoyaltyHistory()
  const history = historyRaw as LoyaltyHistoryEntry[] | undefined

  const demoLoyalty: Loyalty = useMemo(() => ({
    tier: 'gold',
    points: 5240,
    totalSpent: 1890.00,
    multiplier: 1.5,
    pointsToNextTier: 3110,
    nextTier: 'platinum',
  }), [])

  const loyaltyData = loyalty || demoLoyalty

  const demoHistory: LoyaltyHistoryEntry[] = useMemo(() => {
    let balance = 5240
    const entries: LoyaltyHistoryEntry[] = []
    const raw: Array<[string, 'earn' | 'redeem' | 'bonus' | 'adjust', number, string, string]> = [
      ['h-1', 'earn', 67, 'Order #NWH-124593', new Date().toISOString()],
      ['h-2', 'bonus', 500, 'Birthday bonus', new Date(Date.now() - 2 * 86400000).toISOString()],
      ['h-3', 'redeem', -500, 'Order #NWH-124592 · Points redeemed', new Date(Date.now() - 4 * 86400000).toISOString()],
      ['h-4', 'earn', 89, 'Order #NWH-124591', new Date(Date.now() - 7 * 86400000).toISOString()],
      ['h-5', 'earn', 112, 'Order #NWH-124590', new Date(Date.now() - 12 * 86400000).toISOString()],
      ['h-6', 'bonus', 100, 'Referral bonus: Emily Chen', new Date(Date.now() - 18 * 86400000).toISOString()],
      ['h-7', 'earn', 215, 'Order #NWH-118327', new Date(Date.now() - 25 * 86400000).toISOString()],
      ['h-8', 'earn', 53, 'Order #NWH-118320', new Date(Date.now() - 32 * 86400000).toISOString()],
    ]
    for (let i = raw.length - 1; i >= 0; i--) {
      balance -= raw[i][2]
    }
    raw.forEach(([id, type, pts, source, date]) => {
      balance += pts
      entries.push({
        id, type, points: Math.abs(pts), source,
        orderNumber: source.includes('#') ? source.split('#')[1].split(' ')[0] : undefined,
        createdAt: date, runningBalance: balance,
      })
    })
    return entries.reverse()
  }, [])

  const historyData = (history?.length || 0) > 0 ? (history as LoyaltyHistoryEntry[]) : demoHistory

  const currentTier = computeTier(loyaltyData.totalSpent)
  const currentConfig = tierConfig[currentTier]
  const tierIdx = TIERS_ORDER.indexOf(currentTier)
  const nextTier = tierIdx < TIERS_ORDER.length - 1 ? TIERS_ORDER[tierIdx + 1] : null
  const nextConfig = nextTier ? tierConfig[nextTier] : null
  const spendToNext = nextConfig
    ? Math.max(0, nextConfig.threshold - loyaltyData.totalSpent)
    : 0
  const progressPct = nextConfig
    ? Math.min(100, Math.round(
        ((loyaltyData.totalSpent - currentConfig.threshold) /
          Math.max(1, nextConfig.threshold - currentConfig.threshold)) * 100,
      ))
    : 100

  return (
    <Card className="p-0 overflow-hidden">
      <div className={cn(
        'relative p-6 sm:p-8 text-white overflow-hidden',
        `bg-gradient-to-br ${currentConfig.color}`,
      )}>
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage:
              'radial-gradient(circle at 20% 20%, rgba(255,255,255,0.3) 0, transparent 50%), radial-gradient(circle at 80% 80%, rgba(251,191,36,0.4) 0, transparent 50%)',
          }}
        />
        <div className="absolute -right-8 -top-8 opacity-10">
          <Crown className="w-40 h-40" />
        </div>

        <div className="relative flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 border border-white/20 text-xs font-semibold uppercase tracking-wider mb-3">
              <Crown className="w-3.5 h-3.5" />
              Member Tier
            </div>
            <h2 className="font-serif text-4xl sm:text-5xl font-bold tracking-tight leading-none">
              {currentConfig.label}
            </h2>
            <p className="text-white/80 mt-2 text-sm">
              {nextTier && nextConfig ? `Spend ${formatCurrency(spendToNext)} more to unlock ${nextConfig.label}` : 'You reached the top tier!'}
            </p>
          </div>
          <div className="text-right">
            <Badge className="bg-white/15 border-white/20 text-white backdrop-blur">
              <Sparkles className="w-3 h-3 mr-1" />
              Earn {currentConfig.multiplier} points
            </Badge>
          </div>
        </div>

        {nextConfig && (
          <div className="relative mt-6">
            <div className="flex items-center justify-between text-xs text-white/70 mb-1.5">
              <span>{currentConfig.label}</span>
              <span className="font-semibold text-white tabular-nums">
                {loyaltyData.totalSpent >= nextConfig.threshold
                  ? 'Completed'
                  : `${progressPct}% to ${nextConfig.label}`}
              </span>
              <span>{nextConfig.label}</span>
            </div>
            <div className="h-2.5 rounded-full bg-white/15 overflow-hidden">
              <div
                className={cn('h-full rounded-full transition-all duration-500', currentConfig.progress)}
                style={{ width: `${progressPct}%` }}
              />
            </div>
          </div>
        )}
      </div>

      <div className="p-5 sm:p-6 -mt-1 relative z-10 mx-5 sm:mx-6 mb-0">
        <Card className={cn('p-5 sm:p-6 shadow-md bg-white border', currentConfig.border)}>
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className={cn(
                'w-14 h-14 rounded-2xl flex items-center justify-center shadow-sm',
                currentConfig.light,
              )}>
                <Coins className={cn('w-7 h-7', currentConfig.text)} />
              </div>
              <div>
                <p className="text-xs uppercase tracking-wider text-primary-800/50 font-semibold">
                  Points Balance
                </p>
                <p className="font-serif text-4xl font-bold text-primary-950 tabular-nums leading-none mt-1">
                  {loyaltyData.points.toLocaleString()}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="text-xs uppercase tracking-wider text-primary-800/50 font-semibold">Worth</p>
                <p className="font-serif text-2xl font-bold text-accent-700 tabular-nums">
                  {formatCurrency(loyaltyData.points / 100)}
                </p>
              </div>
              <Badge variant="accent" size="md" className="px-3">
                Redeem on next purchase
              </Badge>
            </div>
          </div>
        </Card>
      </div>

      <div className="p-5 sm:p-6">
        <div className="grid sm:grid-cols-3 gap-3 mb-6">
          {[
            { icon: <BookOpen className="w-4 h-4" />, title: 'Earn on every Rs. 100', desc: `${currentConfig.multiplier} points per Rs. 100 spent`, color: currentConfig.light, colorText: currentConfig.text },
            { icon: <Calendar className="w-4 h-4" />, title: 'Birthday Bonus', desc: `${currentConfig.birthday} in points every year`, color: 'bg-rose-50', colorText: 'text-rose-700' },
            { icon: <Truck className="w-4 h-4" />, title: 'Free Shipping', desc: tierIdx >= 1 ? 'Unlocked' : 'Silver tier and up', color: 'bg-emerald-50', colorText: 'text-emerald-700' },
          ].map((t, i) => (
            <div key={i} className="p-4 rounded-xl bg-cream-50 border border-cream-200">
              <div className={cn('w-8 h-8 rounded-lg flex items-center justify-center mb-2', t.color, t.colorText)}>
                {t.icon}
              </div>
              <p className="font-semibold text-primary-950 text-sm">{t.title}</p>
              <p className="text-xs text-primary-800/60 mt-0.5">{t.desc}</p>
            </div>
          ))}
        </div>

        <div className="space-y-3 mb-5">
          <p className="text-xs uppercase tracking-wider text-primary-800/60 font-semibold">
            Ways to Earn More Points
          </p>
          <div className="space-y-2">
            {[
              { text: 'Leave a book review', pts: '+25 pts', icon: <Star className="w-3.5 h-3.5" /> },
              { text: 'Refer a friend who buys something', pts: '+100 pts', icon: <Gift className="w-3.5 h-3.5" /> },
              { text: 'Follow us on social', pts: '+10 pts', icon: <Sparkles className="w-3.5 h-3.5" /> },
              { text: 'Share a photo of your haul', pts: '+50 pts', icon: <BadgeCheck className="w-3.5 h-3.5" /> },
            ].map((t, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-white border border-cream-200 hover:border-primary-200 transition-colors">
                <div className="flex items-center gap-2.5 text-primary-800/80">
                  <span className="w-6 h-6 rounded-md bg-accent-50 text-accent-700 flex items-center justify-center flex-shrink-0">
                    {t.icon}
                  </span>
                  <span className="text-sm">{t.text}</span>
                </div>
                <span className="text-xs font-bold text-accent-700 tabular-nums">{t.pts}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="flex items-center p-1 rounded-xl bg-cream-100 border border-cream-200 mb-4">
          {([
            { key: 'history' as const, label: 'Points History' },
            { key: 'tiers' as const, label: 'Tiers & Benefits' },
          ]).map(t => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={cn(
                'flex-1 h-9 rounded-lg text-sm font-semibold transition-all',
                tab === t.key
                  ? 'bg-white text-primary-900 shadow-sm border border-cream-200'
                  : 'text-primary-800/70 hover:text-primary-900',
              )}
            >
              {t.label}
            </button>
          ))}
        </div>

        {tab === 'history' ? (
          <div className="rounded-xl border border-cream-200 overflow-hidden">
            {loadingHistory && !history?.length ? (
              <div className="p-8"><LoadingSpinner size="sm" label="Loading history..." /></div>
            ) : historyData.length === 0 ? (
              <div className="p-8 text-center text-sm text-primary-800/60">No points history yet.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-cream-50 text-primary-800/60 uppercase tracking-wider text-xs">
                    <tr>
                      <th className="text-left font-semibold p-3">Type</th>
                      <th className="text-left font-semibold p-3 hidden sm:table-cell">Source</th>
                      <th className="text-right font-semibold p-3">Points</th>
                      <th className="text-left font-semibold p-3 hidden md:table-cell">Date</th>
                      <th className="text-right font-semibold p-3">Balance</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-cream-100">
                    {historyData.map(h => (
                      <tr key={h.id} className="hover:bg-cream-50/60">
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <span className={cn(
                              'w-6 h-6 rounded-md flex items-center justify-center flex-shrink-0',
                              h.type === 'earn' ? 'bg-emerald-50 text-emerald-700' :
                              h.type === 'redeem' ? 'bg-amber-50 text-amber-700' :
                              h.type === 'bonus' ? 'bg-accent-50 text-accent-700' :
                              'bg-primary-50 text-primary-700',
                            )}>
                              {h.type === 'earn' ? <ArrowUp className="w-3 h-3" /> :
                               h.type === 'redeem' ? <ArrowDown className="w-3 h-3" /> :
                               <Sparkles className="w-3 h-3" />}
                            </span>
                            <span className="font-medium text-primary-900 capitalize">{h.type}</span>
                          </div>
                        </td>
                        <td className="p-3 hidden sm:table-cell text-primary-800/80 truncate max-w-xs">
                          {h.source}
                        </td>
                        <td className="p-3 text-right">
                          <span className={cn(
                            'font-bold tabular-nums',
                            h.type === 'redeem' ? 'text-amber-700' : 'text-emerald-700',
                          )}>
                            {h.type === 'redeem' ? '-' : '+'}{h.points.toLocaleString()}
                          </span>
                        </td>
                        <td className="p-3 hidden md:table-cell text-primary-800/70 text-xs">
                          {formatDateShort(h.createdAt)}
                        </td>
                        <td className="p-3 text-right font-semibold text-primary-900 tabular-nums">
                          {h.runningBalance.toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        ) : (
          <div className="rounded-xl border border-cream-200 overflow-hidden overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-cream-50 text-primary-800/60 uppercase tracking-wider text-xs">
                <tr>
                  <th className="text-left font-semibold p-3">Tier</th>
                  <th className="text-left font-semibold p-3">Spend</th>
                  <th className="text-left font-semibold p-3">Earn Rate</th>
                  <th className="text-left font-semibold p-3 hidden sm:table-cell">Birthday</th>
                  <th className="text-left font-semibold p-3 hidden md:table-cell">Free Shipping</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-cream-100">
                {TIERS_ORDER.map(tierKey => {
                  const cfg = tierConfig[tierKey]
                  const isActive = tierKey === currentTier
                  const spendStr = tierKey === 'bronze' ? 'Start here' :
                    tierKey === 'platinum' ? `${formatCurrency(cfg.threshold)}+` :
                    `${formatCurrency(cfg.threshold)}+`
                  return (
                    <tr key={tierKey} className={cn(isActive && 'bg-accent-50/40')}>
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          <div className={cn('w-7 h-7 rounded-md bg-gradient-to-br', cfg.color, 'flex items-center justify-center flex-shrink-0')}>
                            <Crown className="w-3.5 h-3.5 text-white" />
                          </div>
                          <span className="font-semibold text-primary-950">{cfg.label}</span>
                          {isActive && <Badge variant="accent" size="sm">You</Badge>}
                        </div>
                      </td>
                      <td className="p-3 font-medium text-primary-800 tabular-nums">{spendStr}</td>
                      <td className="p-3">
                        <Badge className={cn(cfg.bg, cfg.border, cfg.text)}>
                          ×{cfg.multiplier.replace('x', '')}
                        </Badge>
                      </td>
                      <td className="p-3 hidden sm:table-cell font-semibold text-primary-800">{cfg.birthday}</td>
                      <td className="p-3 hidden md:table-cell">
                        {tierKey === 'bronze'
                          ? <span className="text-primary-800/40">—</span>
                          : <BadgeCheck className="w-4 h-4 text-emerald-600" />}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </Card>
  )
}
