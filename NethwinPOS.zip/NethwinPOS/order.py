from beanie import Document, Link
from datetime import datetime
from typing import List, Optional, Any
from pydantic import BaseModel, Field, ConfigDict, field_validator
from decimal import Decimal
from enum import Enum
from bson import Decimal128

from app.models.user import User
from app.models.book import Book
from app.models.stationery import Stationery


def _to_decimal(v: Any) -> Any:
    if isinstance(v, Decimal128):
        return v.to_decimal()
    return v


class OrderStatus(str, Enum):
    PENDING = "pending"
    PAID = "paid"
    SHIPPED = "shipped"
    DELIVERED = "delivered"
    CANCELLED = "cancelled"


class PaymentStatus(str, Enum):
    UNPAID = "unpaid"
    PAID = "paid"
    REFUNDED = "refunded"
    FAILED = "failed"


class OrderItem(BaseModel):
    book_id: Optional[Link[Book]] = None
    stationery_id: Optional[Link[Stationery]] = None
    product_type: str = "book"
    title: str
    isbn: Optional[str] = None
    sku: Optional[str] = None
    quantity: int = Field(ge=1)
    unit_price: Decimal = Field(gt=0, max_digits=10, decimal_places=2)
    subtotal: Decimal = Field(gt=0, max_digits=10, decimal_places=2)

    @field_validator("unit_price", "subtotal", mode="before")
    @classmethod
    def _order_item_decimals(cls, v: Any) -> Any:
        return _to_decimal(v)


class ShippingAddress(BaseModel):
    name: str
    line1: str
    line2: Optional[str] = None
    city: str
    state: Optional[str] = None
    postal_code: str
    country: str
    phone: Optional[str] = None


class Order(Document):
    user_id: Optional[Link[User]] = None
    order_number: str
    items: List[OrderItem] = Field(default_factory=list)
    subtotal: Decimal = Field(ge=0, max_digits=10, decimal_places=2)
    tax: Decimal = Field(ge=0, max_digits=10, decimal_places=2, default=Decimal("0"))
    shipping: Decimal = Field(ge=0, max_digits=10, decimal_places=2, default=Decimal("0"))
    redeem_points_applied: int = 0
    points_discount: Decimal = Field(default=Decimal("0"), ge=0, max_digits=10, decimal_places=2)
    points_earned: int = 0
    total: Decimal = Field(gt=0, max_digits=10, decimal_places=2)
    status: OrderStatus = OrderStatus.PENDING
    shipping_address: Optional[ShippingAddress] = None
    payment_intent_id: Optional[str] = None
    payment_status: PaymentStatus = PaymentStatus.UNPAID
    tracking_number: Optional[str] = None
    notes: Optional[str] = None
    source: str = "web"
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    paid_at: Optional[datetime] = None
    shipped_at: Optional[datetime] = None
    delivered_at: Optional[datetime] = None

    class Settings:
        name = "orders"

    @field_validator(
        "subtotal", "tax", "shipping", "points_discount", "total", mode="before"
    )
    @classmethod
    def _order_decimals(cls, v: Any) -> Any:
        return _to_decimal(v)
