from typing import Optional

from fastapi import Depends, Request
from fastapi_users import BaseUserManager, FastAPIUsers, schemas
from fastapi_users.authentication import (
    AuthenticationBackend,
    BearerTransport,
    CookieTransport,
    JWTStrategy,
)

try:
    from fastapi_users_db_beanie import BeanieUserDatabase, ObjectIDIDMixin
except ImportError:
    from fastapi_users.db import BeanieUserDatabase, ObjectIDIDMixin

from app.config import settings
from app.models.user import User
from app.services.email_service import send_password_reset


class UserRead(schemas.BaseUser):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    role: str = "user"
    full_name: Optional[str] = None

    class Config:
        from_attributes = True


class UserCreate(schemas.BaseUserCreate):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[str] = None


class UserUpdate(schemas.BaseUserUpdate):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[str] = None


async def get_user_db():
    yield BeanieUserDatabase(User)


class UserManager(ObjectIDIDMixin, BaseUserManager[User, str]):
    reset_password_token_secret = settings.SECRET_KEY
    verification_token_secret = settings.SECRET_KEY

    async def on_after_register(
        self, user: User, request: Optional[Request] = None
    ) -> None:
        pass

    async def on_after_forgot_password(
        self, user: User, token: str, request: Optional[Request] = None
    ) -> None:
        try:
            print(f"🔔 [AUTH] on_after_forgot_password triggered for user: {user.email}")
            await send_password_reset(user.email, token)
            print(f"✅ [AUTH] Password reset flow completed for user: {user.email}")
        except Exception as e:
            print(f"❌ [AUTH ERROR] on_after_forgot_password failed for {user.email}: {e}")
            import traceback
            traceback.print_exc()

    async def on_after_request_verify(
        self, user: User, token: str, request: Optional[Request] = None
    ) -> None:
        pass


async def get_user_manager(user_db: BeanieUserDatabase = Depends(get_user_db)):
    yield UserManager(user_db)


cookie_transport = CookieTransport(
    cookie_name="nethwin_auth",
    cookie_max_age=3600000,
    cookie_secure=False,
    cookie_httponly=True,
    cookie_samesite="lax",
)

bearer_transport = BearerTransport(tokenUrl="auth/jwt/login")


def get_jwt_strategy() -> JWTStrategy:
    return JWTStrategy(secret=settings.SECRET_KEY, lifetime_seconds=3600000)


auth_backend = AuthenticationBackend(
    name="jwt",
    transport=cookie_transport,
    get_strategy=get_jwt_strategy,
)

bearer_auth_backend = AuthenticationBackend(
    name="bearer",
    transport=bearer_transport,
    get_strategy=get_jwt_strategy,
)

fastapi_users = FastAPIUsers[User, str](get_user_manager, [auth_backend, bearer_auth_backend])

current_user = fastapi_users.current_user(active=True)
current_superuser = fastapi_users.current_user(active=True, superuser=True)
current_optional_user = fastapi_users.current_user(optional=True)


def user_to_response(user: User) -> dict:
    if user.is_superuser:
        effective_role = "admin"
    elif user.staff_role in ("manager", "cashier"):
        effective_role = user.staff_role
    else:
        effective_role = "user"

    return {
        "id": str(user.id),
        "name": user.full_name or user.email,
        "email": user.email,
        "role": effective_role,
        "avatar": None,
        "phone": user.phone,
        "address": user.address,
        "createdAt": user.created_at if hasattr(user, "created_at") else None,
        "first_name": user.first_name,
        "last_name": user.last_name,
        "is_active": user.is_active,
        "is_superuser": user.is_superuser,
    }
