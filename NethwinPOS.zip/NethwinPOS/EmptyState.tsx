import { cn } from '../../utils/cn'
import { BookMarked, ShoppingCart, Search, Package, FileQuestion } from 'lucide-react'
import Button from './Button'

type Variant = 'cart' | 'books' | 'search' | 'orders' | 'general'

interface EmptyStateProps {
  variant?: Variant
  title: string
  description?: string
  action?: {
    label: string
    onClick: () => void
  }
  secondaryAction?: {
    label: string
    onClick: () => void
  }
  icon?: React.ReactNode
  className?: string
}

const iconMap: Record<Variant, React.ReactNode> = {
  cart: <ShoppingCart className="w-14 h-14" />,
  books: <BookMarked className="w-14 h-14" />,
  search: <Search className="w-14 h-14" />,
  orders: <Package className="w-14 h-14" />,
  general: <FileQuestion className="w-14 h-14" />,
}

export default function EmptyState({
  variant = 'general',
  title,
  description,
  action,
  secondaryAction,
  icon,
  className,
}: EmptyStateProps) {
  return (
    <div
      className={cn(
        'flex flex-col items-center justify-center text-center py-16 px-6',
        className,
      )}
    >
      <div className="w-28 h-28 rounded-full bg-primary-50 border border-primary-100 flex items-center justify-center text-primary-400 mb-6">
        {icon || iconMap[variant]}
      </div>
      <h3 className="font-serif text-2xl font-semibold text-primary-950 mb-2">
        {title}
      </h3>
      {description && (
        <p className="text-primary-800/70 max-w-md mb-8 leading-relaxed">
          {description}
        </p>
      )}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        {action && (
          <Button variant="primary" onClick={action.onClick}>
            {action.label}
          </Button>
        )}
        {secondaryAction && (
          <Button variant="outline" onClick={secondaryAction.onClick}>
            {secondaryAction.label}
          </Button>
        )}
      </div>
    </div>
  )
}
