/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: "#eefdf4",
          100: "#d6fad8",
          200: "#b2f4b7",
          300: "#7ce886",
          400: "#3ed04c",
          500: "#00a651",
          600: "#008e43",
          700: "#007335",
          800: "#055a2c",
          900: "#064a27",
          950: "#022913",
        },
        accent: {
          50: "#fff5f5",
          100: "#ffe5e5",
          200: "#ffcdcd",
          300: "#ffa4a4",
          400: "#ff6c6c",
          500: "#ee1c25",
          600: "#cd131b",
          700: "#ad0e14",
          800: "#8e0f14",
          900: "#761216",
          950: "#420406",
        },
        cream: {
          50: "#fdfcfb",
          100: "#faf8f5",
          200: "#f5f0e8",
          300: "#ede4d4",
          400: "#e2d3b8",
          500: "#d4bf9a",
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        serif: ['"Playfair Display"', 'Georgia', 'serif'],
      },
    },
  },
  plugins: [],
}
