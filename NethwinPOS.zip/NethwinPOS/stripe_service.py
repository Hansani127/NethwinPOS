import stripe
try:
    from stripe.error import SignatureVerificationError
except ImportError:
    SignatureVerificationError = getattr(stripe, "SignatureVerificationError", Exception)

from app.config import settings
from app.models.order import Order


def init_stripe() -> None:
    stripe.api_key = settings.STRIPE_SECRET_KEY


async def create_payment_intent(order: Order) -> tuple[str, str]:
    init_stripe()
    amount_cents = int(order.total * 100)
    intent = stripe.PaymentIntent.create(
        amount=amount_cents,
        currency="usd",
        metadata={
            "order_number": order.order_number,
            "order_id": str(order.id),
        },
    )
    return intent.client_secret, intent.id


async def create_payment_intent_from_amount(amount_cents: int, metadata: dict | None = None) -> tuple[str, str]:
    init_stripe()
    intent = stripe.PaymentIntent.create(
        amount=amount_cents,
        currency="usd",
        metadata=metadata or {},
    )
    return intent.client_secret, intent.id


def construct_webhook_event(payload: bytes, sig_header: str, webhook_secret: str):
    init_stripe()
    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, webhook_secret
        )
        return event
    except (ValueError, SignatureVerificationError):
        return None


async def verify_payment(payment_intent_id: str) -> dict | None:
    init_stripe()
    try:
        intent = stripe.PaymentIntent.retrieve(payment_intent_id)
        return intent
    except Exception:
        return None
