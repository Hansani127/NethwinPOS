import { Star } from 'lucide-react'
import { cn } from '../../utils/cn'

interface RatingProps {
  value: number
  max?: number
  size?: 'sm' | 'md' | 'lg'
  showValue?: boolean
  reviewCount?: number
  className?: string
}

const sizeMap = {
  sm: { star: 'w-3.5 h-3.5', text: 'text-xs' },
  md: { star: 'w-4 h-4', text: 'text-sm' },
  lg: { star: 'w-5 h-5', text: 'text-base' },
}

export default function Rating({
  value,
  max = 5,
  size = 'md',
  showValue = true,
  reviewCount,
  className,
}: RatingProps) {
  const sizes = sizeMap[size]
  const clamped = Math.max(0, Math.min(max, value))

  return (
    <div className={cn('inline-flex items-center gap-1.5', className)}>
      <div className="inline-flex items-center gap-0.5">
        {Array.from({ length: max }).map((_, i) => {
          const filled = i + 1 <= Math.floor(clamped)
          const half = !filled && i + 0.5 <= clamped
          return (
            <Star
              key={i}
              className={cn(
                sizes.star,
                filled || half
                  ? 'text-accent-500 fill-accent-500'
                  : 'text-cream-400',
              )}
              style={half ? { clipPath: 'inset(0 50% 0 0)' } : undefined}
            />
          )
        })}
      </div>
      {showValue && (
        <span className={cn('font-medium text-primary-800', sizes.text)}>
          {clamped.toFixed(1)}
          {reviewCount !== undefined && (
            <span className="text-primary-700/60 font-normal ml-1">({reviewCount})</span>
          )}
        </span>
      )}
    </div>
  )
}
