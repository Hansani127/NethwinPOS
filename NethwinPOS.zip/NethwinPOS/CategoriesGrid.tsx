import { Link } from '../../utils/router-compat'

import { BookOpen, UserSearch, History, Lightbulb, Landmark, ScrollText, Palette } from 'lucide-react'
import { useCategories } from '../../hooks/useCategories'
import type { Category, PaginatedResponse } from '../../types'
import { useMemo } from 'react'

const MAIN_CATEGORIES = [
  {
    slug: 'fiction',
    name: 'Fiction',
    description: 'Novels, short stories, and literary journeys.',
    icon: <BookOpen className="w-6 h-6" />,
    color: 'from-primary-500/15 to-primary-500/2 border-primary-200 text-primary-700',
  },
  {
    slug: 'biography--autobiography',
    name: 'Biographies',
    description: 'Extraordinary lives told in the authors own words.',
    icon: <UserSearch className="w-6 h-6" />,
    color: 'from-rose-500/15 to-rose-500/2 border-rose-200 text-rose-700',
  },
  {
    slug: 'history',
    name: 'History',
    description: 'Journey through empires, revolutions, and the people who shaped our world.',
    icon: <Landmark className="w-6 h-6" />,
    color: 'from-amber-500/15 to-amber-500/2 border-amber-200 text-amber-700',
  },
  {
    slug: 'philosophy',
    name: 'Philosophy & Religion',
    description: 'Great thinkers, sacred texts, and the search for meaning.',
    icon: <Lightbulb className="w-6 h-6" />,
    color: 'from-indigo-500/15 to-indigo-500/2 border-indigo-200 text-indigo-700',
  },
  {
    slug: 'comics--graphic-novels',
    name: 'Comics & Graphic Novels',
    description: 'Pictures that tell stories, from superheroes to intimate memoirs.',
    icon: <Palette className="w-6 h-6" />,
    color: 'from-emerald-500/15 to-emerald-500/2 border-emerald-200 text-emerald-700',
  },
  {
    slug: 'science',
    name: 'Science & Tech',
    description: 'From quantum physics to AI, cosmology to code.',
    icon: <ScrollText className="w-6 h-6" />,
    color: 'from-violet-500/15 to-violet-500/2 border-violet-200 text-violet-700',
  },
]

const ADULT_SLUG_HINTS = ['erotica', 'erotic', 'sexual', 'sex', 'adult', '18', 'xxx', 'nsfw', 'x-rated']

function is_adult_category(c: { slug?: string; name?: string }) {
  const s = `${c.slug || ''} ${c.name || ''}`.toLowerCase()
  return ADULT_SLUG_HINTS.some((kw) => s.includes(kw))
}

function slugify(input: string) {
  return input
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
}

function extractCategories(data: Category[] | PaginatedResponse<Category> | undefined): Category[] {
  if (!data) return []
  if (Array.isArray(data)) return data
  return data.items || data.data || []
}

export default function CategoriesGrid() {
  const { data: apiCategories } = useCategories()
  const list = useMemo(
    () => extractCategories(apiCategories).filter((c) => !is_adult_category(c)),
    [apiCategories],
  )

  const topFromApi =
    list.length > 0
      ? list
          .sort((a, b) => {
            const ba = (a as any).bookCount ?? (a as any).count ?? 0
            const bb = (b as any).bookCount ?? (b as any).count ?? 0
            return bb - ba
          })
          .slice(0, 20)
          .map((c) => ({
            id: c.id,
            slug: c.slug || slugify(c.name),
            name: c.name,
            description: c.description || 'Curated selection',
          }))
      : []

  function mergeMainWithApi(main: typeof MAIN_CATEGORIES) {
    return main.map((m) => {
      const match = topFromApi.find(
        (c) =>
          slugify(c.name) === m.slug ||
          c.slug === m.slug ||
          slugify(c.name) === slugify(m.name) ||
          slugify(c.name).split('-').slice(0, 2).join('-') === m.slug.split('-').slice(0, 2).join('-'),
      )
      return {
        id: match?.id || m.slug,
        slug: match?.slug || m.slug,
        name: match?.name || m.name,
        description: m.description,
        icon: m.icon,
        color: m.color,
      }
    })
  }

  const categories = mergeMainWithApi(MAIN_CATEGORIES).slice(0, 6)

  return (
    <section className="py-20 sm:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-14 max-w-2xl mx-auto">
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-primary-950">
            Explore by <span className="italic text-primary-700">Category</span>
          </h2>
          <p className="mt-4 text-primary-800/70 leading-relaxed">
            Wander through our curated sections — each shelf a different world, every genre a new doorway.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 sm:gap-5">
          {categories.map((cat: any) => (
            <Link
              key={cat.id}
              to={`/books?category=${encodeURIComponent(cat.slug)}`}
              className="group relative bg-white rounded-2xl border border-cream-200 p-6 overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-primary-950/5 hover:border-primary-200"
            >
              <div
                className={`absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-100 transition-opacity duration-500 ${cat.color.split(' ').slice(0, 2).join(' ')}`}
              />
              <div className="relative">
                <div
                  className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${cat.color} flex items-center justify-center mb-5 transition-transform duration-300 group-hover:scale-110`}
                >
                  {cat.icon}
                </div>
                <h3 className="font-serif text-xl font-semibold text-primary-950 mb-1 group-hover:text-primary-700 transition-colors">
                  {cat.name}
                </h3>
                <p className="text-sm text-primary-800/60 leading-relaxed min-h-[2.5rem]">
                  {cat.description}
                </p>
                <div className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-primary-600 opacity-0 group-hover:opacity-100 translate-x-[-4px] group-hover:translate-x-0 transition-all">
                  Browse
                  <span aria-hidden>→</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
