from fastapi import APIRouter, Query, Depends
from typing import Optional, List
import math
from datetime import datetime
from beanie.odm.operators.find.comparison import GTE, LTE
from beanie.odm.operators.find.evaluation import RegEx as Regex
from beanie.odm.operators.find.logical import And, Or

from app.core.security import current_optional_user
from app.models.book import Book
from app.models.stationery import Stationery
from app.models.user import User
from app.routers.books import _book_to_read, _adult_exclude_filter
from app.routers.stationery import _stationery_to_read
from app.schemas import (
    CatalogSearchResponse,
    CatalogSearchStats,
    BookRead,
    StationeryRead,
    UnifiedProduct,
)

router = APIRouter(prefix="/catalog", tags=["catalog"])


@router.get("/search", response_model=CatalogSearchResponse)
async def catalog_search(
    q: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    category: Optional[str] = None,
    product_type: str = Query("all", pattern="^(all|books|stationery)$"),
    sort: Optional[str] = Query(None, description="newest|price-asc|price-desc|rating-desc|name-asc"),
    min_price: Optional[float] = None,
    max_price: Optional[float] = None,
    featured: Optional[bool] = None,
    include_adult: bool = Query(False, description="If true, also include adult/erotica books"),
    _: Optional[User] = Depends(current_optional_user),
):
    book_filters = []
    stationery_filters = []

    if featured is not None:
        book_filters.append(Book.is_featured == featured)
        stationery_filters.append(Stationery.is_featured == featured)

    book_filters.append(Book.is_active == True)
    stationery_filters.append(Stationery.is_active == True)

    if min_price is not None:
        book_filters.append(GTE(Book.price, min_price))
        stationery_filters.append(GTE(Stationery.price, min_price))
    if max_price is not None:
        book_filters.append(LTE(Book.price, max_price))
        stationery_filters.append(LTE(Stationery.price, max_price))
    if q:
        escaped = q.replace("\\", "\\\\").replace(".", "\\.")
        book_search = Or(
            Regex(Book.title, escaped, options="i"),
            Regex(Book.authors, escaped, options="i"),
            Regex(Book.isbn13, escaped, options="i"),
            Regex(Book.isbn10, escaped, options="i"),
            Regex(Book.category_names, escaped, options="i"),
        )
        stationery_search = Or(
            Regex(Stationery.name, escaped, options="i"),
            Regex(Stationery.sku, escaped, options="i"),
            Regex(Stationery.brand, escaped, options="i"),
            Regex(Stationery.category, escaped, options="i"),
        )
        book_filters.append(book_search)
        stationery_filters.append(stationery_search)
    if category:
        book_filters.append(Or(
            Book.category_names == category,
            Regex(Book.category_names, category, options="i"),
        ))
        stationery_filters.append(Or(
            Stationery.category == category,
            Regex(Stationery.category, category, options="i"),
        ))

    if not include_adult:
        af = _adult_exclude_filter()
        if af is not None:
            book_filters.append(af)

    book_query = And(*book_filters) if book_filters else {}
    stationery_query = And(*stationery_filters) if stationery_filters else {}

    books_count = 0
    stationery_count = 0
    all_items: list[UnifiedProduct] = []

    if product_type in ("all", "books"):
        books_count = await Book.find(book_query).count()
    if product_type in ("all", "stationery"):
        stationery_count = await Stationery.find(stationery_query).count()

    categories_set: set[str] = set()

    if product_type in ("all", "books"):
        book_list = await Book.find(book_query).to_list()
        for b in book_list:
            br = await _book_to_read(b)
            all_items.append(br)
            for cn in br.category_names:
                categories_set.add(cn)
    if product_type in ("all", "stationery"):
        stationery_list = await Stationery.find(stationery_query).to_list()
        for s in stationery_list:
            sr = _stationery_to_read(s)
            all_items.append(sr)
            categories_set.add(sr.categoryId or s.category)

    # Apply sorting
    if sort == "price-asc":
        all_items.sort(key=lambda x: (x.price or 0))
    elif sort == "price-desc":
        all_items.sort(key=lambda x: (x.price or 0), reverse=True)
    elif sort == "rating-desc":
        all_items.sort(key=lambda x: (getattr(x, "rating", None) or 0), reverse=True)
    elif sort == "name-asc":
        all_items.sort(key=lambda x: (getattr(x, "title", None) or getattr(x, "name", None) or "").lower())
    else:
        # newest (default)
        all_items.sort(key=lambda x: x.created_at, reverse=True)

    total = len(all_items)
    total_pages = max(1, math.ceil(total / page_size))
    skip = (page - 1) * page_size
    page_items = all_items[skip:skip + page_size]

    stats = CatalogSearchStats(
        books_count=books_count,
        stationery_count=stationery_count,
        categories_available=sorted(list(categories_set)),
    )

    return CatalogSearchResponse(
        total=total,
        page=page,
        page_size=page_size,
        pages=total_pages,
        items=page_items,
        data=page_items,
        limit=page_size,
        totalPages=total_pages,
        stats=stats,
    )


@router.get("/coming-soon")
async def catalog_coming_soon(
    limit: int = Query(16, ge=1, le=50),
    include_adult: bool = Query(False, description="If true, also include adult/erotica books"),
):
    results: list[UnifiedProduct] = []

    book_filters = [
        Book.is_preorder == True,
        Book.is_active == True,
    ]
    if not include_adult:
        af = _adult_exclude_filter()
        if af is not None:
            book_filters.append(af)

    books = await Book.find(And(*book_filters)).to_list()

    for b in books:
        br = await _book_to_read(b)
        results.append(br)

    stationeries = await Stationery.find(
        Stationery.is_preorder == True,
        Stationery.is_active == True,
    ).to_list()

    for s in stationeries:
        sr = _stationery_to_read(s)
        results.append(sr)

    def _release_key(item):
        d = item.preorder_release_date
        if d is None:
            return datetime.max
        return d

    results.sort(key=_release_key)
    limited = results[:limit]

    return {
        "total": len(results),
        "items": limited,
        "data": limited,
    }
