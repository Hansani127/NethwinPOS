from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    MONGO_URI: str = "mongodb://localhost:27017"
    DATABASE_NAME: str = "nethwin_bookshop"
    SECRET_KEY: str = "change-me-in-production"

    CLOUDINARY_URL: str = ""
    STRIPE_SECRET_KEY: str = ""
    STRIPE_PUBLISHABLE_KEY: str = ""
    STRIPE_WEBHOOK_SECRET: str = ""
    REDIS_URL: str = "redis://localhost:6379/0"
    RESEND_API_KEY: str = ""
    FRONTEND_URL: str = "http://localhost:3000"
    EMAIL_FROM: str = "noreply@nethwinbookshop.com"

    TAX_RATE: float = 0.08
    SHIPPING_RATE: float = 350.00
    FREE_SHIPPING_THRESHOLD: float = 10000.00


settings = Settings()
