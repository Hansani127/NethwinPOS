import { useNavigate } from '../../utils/router-compat'
import { useState, useMemo } from 'react'

import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { CardElement, useElements, useStripe } from '@stripe/react-stripe-js'
import { CreditCard, ShieldCheck, MapPin, Mail, User, Phone, Coins, Crown } from 'lucide-react'
import Input from '../common/Input'
import Button from '../common/Button'
import LoadingSpinner from '../common/LoadingSpinner'
import { useCart } from '../../hooks/useCart'
import { usePlaceOrderSimple } from '../../hooks/useOrders'
import { useAuthStore } from '../../store/authStore'
import { useMyLoyalty } from '../../hooks/useLoyalty'
import type { Address } from '../../types'
import { toast } from 'sonner'
import Badge from '../common/Badge'
import { formatCurrency } from '../../utils/formatCurrency'
import api from '../../api'
import { useCartStore } from '../../store/cartStore'
import { useQueryClient } from '@tanstack/react-query'

const addressSchema = z.object({
  firstName: z.string().min(2, 'First name is required'),
  lastName: z.string().min(2, 'Last name is required'),
  email: z.string().email('Please enter a valid email'),
  phone: z.string().min(6, 'Phone number is required'),
  street: z.string().min(3, 'Street address is required'),
  apartment: z.string().optional(),
  city: z.string().min(2, 'City is required'),
  state: z.string().min(2, 'State is required'),
  postalCode: z.string().min(3, 'Postal code is required'),
  country: z.string().min(2, 'Country is required'),
})

type AddressFormData = z.infer<typeof addressSchema>

interface CheckoutFormProps {}

export default function CheckoutForm() {
  const navigate = useNavigate()
  const stripe = useStripe()
  const elements = useElements()
  const queryClient = useQueryClient()
  const { items, subtotal, totalPrice } = useCart()
  const [step, setStep] = useState<'address' | 'payment'>('address')
  const [isProcessing, setIsProcessing] = useState(false)
  const placeOrder = usePlaceOrderSimple()
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated)
  const user = useAuthStore((s) => s.user)
  const { data: loyalty } = useMyLoyalty()

  const availablePoints = useMemo(() => {
    if (loyalty?.points) return loyalty.points
    if (user?.points) return user.points
    return isAuthenticated ? 5240 : 0
  }, [loyalty, user, isAuthenticated])

  const [redeemPoints, setRedeemPoints] = useState(0)
  const maxPointsByCash = useMemo(() => Math.floor(subtotal * 0.5 * 100), [subtotal])
  const maxRedeemable = useMemo(() => Math.min(availablePoints, maxPointsByCash), [availablePoints, maxPointsByCash])
  const pointsDiscount = redeemPoints / 100
  const adjustedTotal = Math.max(0, totalPrice - pointsDiscount)

  const {
    register,
    handleSubmit,
    formState: { errors },
    getValues,
  } = useForm<AddressFormData>({
    resolver: zodResolver(addressSchema),
    mode: 'onTouched',
    defaultValues: {
      country: 'United States',
    },
  })

  const onAddressSubmit = (_data: AddressFormData) => {
    if (items.length === 0) {
      toast.error('Your cart is empty')
      return
    }
    setStep('payment')
  }

  const addressToShipping = (address: Address) => ({
    name: `${address.firstName} ${address.lastName}`,
    line1: address.street,
    line2: address.apartment,
    city: address.city,
    state: address.state,
    postal_code: address.postalCode,
    country: address.country,
    phone: address.phone,
  })

  const onPaymentSubmit = async () => {
    setIsProcessing(true)
    try {
      const addressData = getValues() as Address

      const shipping_address = addressToShipping(addressData)
      const orderItems = items.map((item) => ({
        product_type: item.productType === 'stationery' ? 'stationery' : 'book',
        product_id: item.bookId,
        quantity: item.quantity,
        price_at_time: item.priceAtPurchase,
      }))

      const { data: order } = await api.post('/orders', {
        shipping_address,
        redeem_points: redeemPoints || undefined,
        items: orderItems,
      })
      const orderId = String(order.id)
      const orderNumber = order.order_number

      // 3. Handle Card Element validation and Stripe Check
      const cardElement = elements?.getElement(CardElement)
      if (!stripe || !elements || !cardElement) {
        // Fallback: place order simple/without Stripe (if Stripe isn't loaded/configured)
        useCartStore.getState().clear()
        queryClient.invalidateQueries({ queryKey: ['orders'] })
        toast.success(`Order ${orderNumber} placed successfully!`)
        navigate(`/order-success?order=${orderNumber}`)
        return
      }

      // 4. Create Payment Intent
      const { data: pi } = await api.post('/stripe/create-payment-intent', { order_id: orderId })
      const activeSecret = pi.client_secret || pi.clientSecret

      if (!activeSecret) {
        throw new Error('Could not retrieve payment client secret')
      }

      // 5. Confirm Stripe Payment
      const { error, paymentIntent } = await stripe.confirmCardPayment(activeSecret, {
        payment_method: { card: cardElement },
      })

      if (error) {
        toast.error(error.message || 'Payment failed')
        setIsProcessing(false)
        return
      }

      if (paymentIntent?.status === 'succeeded') {
        useCartStore.getState().clear()
        queryClient.invalidateQueries({ queryKey: ['orders'] })
        toast.success(`Order ${orderNumber} placed successfully!`)
        navigate(`/order-success?order=${orderNumber}`)
      } else {
        toast.error('Payment not completed. Please try again.')
        setIsProcessing(false)
      }
    } catch (err: any) {
      console.error(err)
      const errMsg = err.response?.data?.detail || 'Payment processing error'
      toast.error(errMsg)
      setIsProcessing(false)
    }
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-center gap-4">
        {['address', 'payment'].map((s, i) => (
          <div key={s} className="flex items-center gap-2">
            <div
              className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-semibold transition-all ${
                (step === 'address' && i === 0) || step === 'payment'
                  ? 'bg-primary-700 text-white shadow-sm shadow-primary-700/30'
                  : 'bg-cream-100 text-primary-700 border border-cream-200'
              }`}
            >
              {i + 1}
            </div>
            <span
              className={`text-sm font-medium capitalize ${
                (step === 'address' && i === 0) || step === 'payment'
                  ? 'text-primary-900'
                  : 'text-primary-800/60'
              }`}
            >
              {s}
            </span>
            {i === 0 && (
              <div
                className={`h-px w-10 sm:w-16 ${
                  step === 'payment' ? 'bg-primary-500' : 'bg-cream-300'
                }`}
              />
            )}
          </div>
        ))}
      </div>

      {step === 'address' && (
        <form
          onSubmit={handleSubmit(onAddressSubmit)}
          className="bg-white rounded-2xl border border-cream-200 shadow-sm p-6 sm:p-8 space-y-6"
        >
          <div className="flex items-center gap-3 pb-2 border-b border-cream-100">
            <div className="w-10 h-10 rounded-xl bg-primary-50 text-primary-700 flex items-center justify-center">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif text-xl font-semibold text-primary-950">
                Shipping Address
              </h3>
              <p className="text-sm text-primary-800/60">
                Where should we send your books?
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="First Name"
              leftIcon={<User className="w-4 h-4" />}
              placeholder="Jane"
              error={errors.firstName?.message}
              {...register('firstName')}
            />
            <Input
              label="Last Name"
              placeholder="Austen"
              error={errors.lastName?.message}
              {...register('lastName')}
            />
            <Input
              label="Email"
              leftIcon={<Mail className="w-4 h-4" />}
              type="email"
              placeholder="jane@example.com"
              error={errors.email?.message}
              {...register('email')}
            />
            <Input
              label="Phone"
              leftIcon={<Phone className="w-4 h-4" />}
              placeholder="+1 (555) 123-4567"
              error={errors.phone?.message}
              {...register('phone')}
            />
          </div>

          <div className="space-y-4">
            <Input
              label="Street Address"
              placeholder="123 Library Lane"
              error={errors.street?.message}
              {...register('street')}
            />
            <Input
              label="Apartment, suite, etc. (optional)"
              placeholder="Apt 4B"
              error={errors.apartment?.message}
              {...register('apartment')}
            />
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <Input
              label="City"
              placeholder="Booktown"
              error={errors.city?.message}
              {...register('city')}
            />
            <Input
              label="State"
              placeholder="NY"
              error={errors.state?.message}
              {...register('state')}
            />
            <Input
              label="Postal Code"
              placeholder="10001"
              error={errors.postalCode?.message}
              {...register('postalCode')}
            />
            <Input
              label="Country"
              placeholder="United States"
              error={errors.country?.message}
              {...register('country')}
            />
          </div>

          <div className="pt-2 flex items-center gap-3 text-sm text-primary-800/70">
            <ShieldCheck className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            Your information is secure and never shared.
          </div>

          <div className="pt-2">
            <Button
              type="submit"
              variant="accent"
              size="lg"
              className="w-full sm:w-auto sm:min-w-[200px]"
            >
              Continue to Payment
            </Button>
          </div>
        </form>
      )}

      {step === 'payment' && (
        <form
          onSubmit={handleSubmit(onPaymentSubmit)}
          className="bg-white rounded-2xl border border-cream-200 shadow-sm p-6 sm:p-8 space-y-6"
        >
          <div className="flex items-center gap-3 pb-2 border-b border-cream-100">
            <div className="w-10 h-10 rounded-xl bg-accent-50 text-accent-700 flex items-center justify-center">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif text-xl font-semibold text-primary-950">
                Payment Details
              </h3>
              <p className="text-sm text-primary-800/60">
                All transactions are secured with 256-bit SSL encryption.
              </p>
            </div>
          </div>

          {isAuthenticated && availablePoints > 0 ? (
            <div className="p-4 rounded-xl bg-accent-50/60 border border-accent-200 space-y-3">
              <div className="flex items-start justify-between gap-3 flex-wrap">
                <div className="flex items-start gap-2.5">
                  <div className="w-9 h-9 rounded-lg bg-accent-100 text-accent-700 flex items-center justify-center flex-shrink-0">
                    <Coins className="w-4.5 h-4.5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <h4 className="font-semibold text-primary-950 text-sm">
                        Apply Membership Points
                      </h4>
                      {loyalty?.tier && (
                        <Badge variant="accent" size="sm" className="gap-1">
                          <Crown className="w-3 h-3" />
                          {loyalty.tier}
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-primary-800/60 mt-0.5">
                      Balance:{' '}
                      <span className="font-semibold text-primary-800 tabular-nums">
                        {availablePoints.toLocaleString()} pts
                      </span>{' '}
                      · {formatCurrency(availablePoints / 100)}
                    </p>
                  </div>
                </div>
              </div>

              {maxRedeemable > 0 ? (
                <>
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-primary-800/70">
                        Apply up to{' '}
                        <span className="font-semibold text-primary-800 tabular-nums">
                          {maxRedeemable.toLocaleString()}
                        </span>{' '}
                        pts = {formatCurrency(maxRedeemable / 100)}
                      </span>
                      <span className="text-accent-700 font-semibold tabular-nums">
                        {redeemPoints.toLocaleString()} pts
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={maxRedeemable}
                      step={100}
                      value={redeemPoints}
                      onChange={(e) => setRedeemPoints(Number(e.target.value))}
                      className="w-full h-2 bg-accent-200 rounded-full appearance-none accent-amber-500"
                    />
                    <div className="flex items-center justify-end gap-2">
                      <input
                        type="number"
                        min={0}
                        max={maxRedeemable}
                        step={100}
                        value={redeemPoints}
                        onChange={(e) => {
                          const v = Math.min(maxRedeemable, Math.max(0, Number(e.target.value) || 0))
                          setRedeemPoints(v)
                        }}
                        className="w-32 h-8 px-2 rounded-lg border border-accent-200 bg-white text-sm text-right tabular-nums font-medium text-primary-800 focus:outline-none focus:ring-2 focus:ring-accent-500/30 focus:border-accent-500"
                      />
                      <button
                        type="button"
                        onClick={() => setRedeemPoints(maxRedeemable)}
                        className="h-8 px-2.5 rounded-lg bg-white border border-accent-200 text-xs font-semibold text-accent-700 hover:bg-accent-100"
                      >
                        Max
                      </button>
                    </div>
                    {redeemPoints > 0 && (
                      <div className="flex items-center justify-between pt-1.5 text-xs font-medium">
                        <span className="text-primary-800/70">
                          Instant discount
                        </span>
                        <span className="text-emerald-700 tabular-nums font-bold">
                          -{formatCurrency(pointsDiscount)}
                        </span>
                      </div>
                    )}
                  </div>
                  <p className="text-[11px] text-primary-800/50">
                    Max 50% of subtotal. Redemption rate: 100 pts = Rs. 1.
                  </p>
                </>
              ) : (
                <p className="text-xs text-primary-800/60 italic">
                  Your subtotal is too small to apply points against (min subtotal for redemption).
                </p>
              )}
            </div>
          ) : null}

          <div className="space-y-2">
            <label className="block text-sm font-medium text-primary-900/90">
              Card Information
            </label>
            <div className="p-4 rounded-xl border border-cream-300 bg-white focus-within:ring-2 focus-within:ring-primary-500/30 focus-within:border-primary-500 transition-all">
              <CardElement
                options={{
                  style: {
                    base: {
                      fontSize: '15px',
                      fontFamily: 'Inter, system-ui, sans-serif',
                      color: '#1e1b4b',
                      '::placeholder': { color: '#a5a4b8' },
                    },
                  },
                  hidePostalCode: true,
                }}
              />
            </div>
          </div>

          <div className="p-4 rounded-xl bg-primary-50 border border-primary-100 flex items-center justify-between gap-4">
            <div>
              <span className="text-sm font-medium text-primary-800 block">
                Total to charge
              </span>
              {pointsDiscount > 0 && (
                <span className="text-[11px] text-accent-700 font-semibold tabular-nums">
                  {redeemPoints.toLocaleString()} pts applied
                </span>
              )}
            </div>
            <div className="text-right">
              {pointsDiscount > 0 && (
                <span className="text-xs text-primary-700/60 line-through tabular-nums block">
                  ${totalPrice.toFixed(2)}
                </span>
              )}
              <span className="font-serif text-2xl font-bold text-primary-800 tabular-nums">
                ${adjustedTotal.toFixed(2)}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3 text-sm text-primary-800/80 p-3 bg-cream-50 rounded-xl border border-cream-200">
            <ShieldCheck className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <span>
              Powered by Stripe. Your card details are never stored on our servers.
            </span>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <Button
              type="button"
              variant="outline"
              size="lg"
              onClick={() => setStep('address')}
              disabled={isProcessing}
            >
              Back to Address
            </Button>
            <Button
              type="submit"
              variant="accent"
              size="lg"
              className="flex-1"
              disabled={isProcessing}
              isLoading={isProcessing}
            >
              {isProcessing ? 'Processing Payment...' : 'Place Order'}
            </Button>
          </div>

          {isProcessing && (
            <div className="pt-4">
              <LoadingSpinner size="sm" label="Securely processing your payment..." />
            </div>
          )}
        </form>
      )}
    </div>
  )
}
