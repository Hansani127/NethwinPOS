from beanie import Document, Indexed, Link
from datetime import datetime
from typing import Optional, List, Any
from pydantic import Field, field_validator, model_validator
from decimal import Decimal
from bson import Decimal128

from app.models.category import Category


ADULT_KEYWORDS = {
    "erotica", "erotic", "sexual", "sex customs", "erotic poetry",
    "sexual behavior", "sexual customs", "pornography", "porn",
    "xxx", "18+", "nsfw", "x-rated", "x rated",
}


def _to_decimal(v: Any) -> Any:
    if isinstance(v, Decimal128):
        return v.to_decimal()
    if v is None:
        return v
    if isinstance(v, (int, float)):
        return Decimal(str(v))
    return v


def _to_list_of_str(v: Any) -> Any:
    if v is None:
        return []
    if isinstance(v, list):
        return [str(x) for x in v]
    if isinstance(v, str):
        if not v.strip():
            return []
        sep = ";" if ";" in v else ","
        return [s.strip() for s in v.split(sep) if s.strip()]
    return [str(v)]


def _is_bool_or_any(v: Any) -> Any:
    if isinstance(v, bool):
        return v
    if v in (1, 0):
        return bool(v)
    return bool(v)


def _to_datetime(v: Any) -> Any:
    if isinstance(v, datetime):
        return v
    if v is None:
        return datetime.utcnow()
    try:
        import dateutil.parser as _dp  # type: ignore
        return _dp.parse(v)
    except Exception:
        return datetime.utcnow()


class Book(Document):
    title: str
    subtitle: Optional[str] = None
    isbn13: Optional[Indexed(str, unique=True)] = None
    isbn10: Optional[str] = None
    authors: List[str] = Field(default_factory=list)
    categories: List[Link[Category]] = Field(default_factory=list)
    category_names: List[str] = Field(default_factory=list)
    description: Optional[str] = None
    published_year: Optional[int] = None
    num_pages: Optional[int] = None
    average_rating: Optional[float] = None
    ratings_count: Optional[int] = None
    price: Decimal = Field(gt=0, max_digits=10, decimal_places=2)
    stock: int = Field(ge=0, default=0)
    thumbnail: Optional[str] = None
    images: List[str] = Field(default_factory=list)
    is_featured: bool = False
    is_active: bool = True
    is_preorder: bool = False
    preorder_release_date: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    class Settings:
        name = "books"

    @model_validator(mode="before")
    @classmethod
    def _map_mongoose_schema(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data
        # Map old mongoose-style camelCase / alternate field names to Beanie Book schema
        mapped: dict[str, Any] = dict(data)

        if "authors" in mapped and isinstance(mapped["authors"], str):
            mapped["authors"] = [mapped["authors"]]
        if "author" in mapped and "authors" not in mapped:
            a = mapped.pop("author")
            if isinstance(a, list):
                mapped["authors"] = a
            elif isinstance(a, str):
                mapped["authors"] = [a]
            else:
                mapped["authors"] = []

        if "category" in mapped and isinstance(mapped["category"], str) and not mapped.get("category_names"):
            mapped["category_names"] = mapped["category"]

        if "blurb" in mapped and "description" not in mapped:
            mapped["description"] = mapped.pop("blurb")

        if "thumbnailUrl" in mapped and "thumbnail" not in mapped:
            mapped["thumbnail"] = mapped.pop("thumbnailUrl")

        if "cover" in mapped and "thumbnail" not in mapped:
            mapped["thumbnail"] = mapped.pop("cover")

        if "featured" in mapped and "is_featured" not in mapped:
            mapped["is_featured"] = mapped.pop("featured")
        if "isFeatured" in mapped and "is_featured" not in mapped:
            mapped["is_featured"] = mapped.pop("isFeatured")

        if "isPreorder" in mapped and "is_preorder" not in mapped:
            mapped["is_preorder"] = mapped.pop("isPreorder")

        if "releaseDate" in mapped and "preorder_release_date" not in mapped:
            mapped["preorder_release_date"] = mapped.pop("releaseDate")

        if "publishedYear" in mapped and "published_year" not in mapped:
            mapped["published_year"] = mapped.pop("publishedYear")

        if "numPages" in mapped and "num_pages" not in mapped:
            mapped["num_pages"] = mapped.pop("numPages")
        if "pages" in mapped and "num_pages" not in mapped:
            mapped["num_pages"] = mapped.pop("pages")

        if "averageRating" in mapped and "average_rating" not in mapped:
            mapped["average_rating"] = mapped.pop("averageRating")
        if "rating" in mapped and "average_rating" not in mapped:
            mapped["average_rating"] = mapped.pop("rating")

        if "ratingsCount" in mapped and "ratings_count" not in mapped:
            mapped["ratings_count"] = mapped.pop("ratingsCount")
        if "reviewCount" in mapped and "ratings_count" not in mapped:
            mapped["ratings_count"] = mapped.pop("reviewCount")

        if "quantity" in mapped and "stock" not in mapped:
            mapped["stock"] = mapped.pop("quantity")

        if "isbn" in mapped and "isbn13" not in mapped:
            mapped["isbn13"] = mapped.pop("isbn")

        if "createdAt" in mapped and "created_at" not in mapped:
            mapped["created_at"] = mapped.pop("createdAt")

        if "updatedAt" in mapped and "updated_at" not in mapped:
            mapped["updated_at"] = mapped.pop("updatedAt")

        if "isActive" in mapped and "is_active" not in mapped:
            mapped["is_active"] = mapped.pop("isActive")

        return mapped

    @field_validator("authors", "category_names", "images", mode="before")
    @classmethod
    def _list_str_fields(cls, v: Any) -> Any:
        return _to_list_of_str(v)

    @field_validator("categories", mode="before")
    @classmethod
    def _categories_links(cls, v: Any) -> Any:
        if v is None:
            return []
        if isinstance(v, list):
            return v
        return [v]

    @field_validator("price", mode="before")
    @classmethod
    def _price_to_decimal(cls, v: Any) -> Any:
        return _to_decimal(v)

    @field_validator("is_featured", "is_preorder", "is_active", mode="before")
    @classmethod
    def _bool_fields(cls, v: Any) -> Any:
        return _is_bool_or_any(v)

    @field_validator("created_at", "updated_at", "preorder_release_date", mode="before")
    @classmethod
    def _date_fields(cls, v: Any) -> Any:
        return _to_datetime(v)

    @property
    def is_adult(self) -> bool:
        for c in self.category_names or []:
            low = c.lower()
            for kw in ADULT_KEYWORDS:
                if kw in low:
                    return True
        return False

    @field_validator("updated_at")
    @classmethod
    def set_updated_at(cls, v: datetime) -> datetime:
        return v or datetime.utcnow()
