import { Link, useNavigate } from '../../utils/router-compat'

import { ShoppingCart, Eye, Calendar } from 'lucide-react'
import type { Book, CatalogProduct } from '../../types'
import { cleanImageUrl } from '../../utils/imageUrl'
import { cn } from '../../utils/cn'
import { formatCurrency } from '../../utils/formatCurrency'
import Badge from '../common/Badge'
import Rating from '../common/Rating'
import Button from '../common/Button'
import { useCart } from '../../hooks/useCart'

interface BookCardProps {
  book: Book | CatalogProduct
  className?: string
  unified?: boolean
}

export default function BookCard({ book, className, unified }: BookCardProps) {
  const navigate = useNavigate()
  const { addToCart } = useCart()
  const p = book as any
  const isPreorder = !!p.is_preorder || !!p.isPreorder
  const title = p.title || p.name || 'Product'
  const author = p.author || p.brand || undefined
  const explicitProductType = (p as any).productType
  const isBook =
    explicitProductType === 'book' ? true
      : explicitProductType === 'stationery' ? false
      : !!((p as any).author && !(p as any).brand && !(p as any).sku)
  const productType: 'book' | 'stationery' = explicitProductType || (isBook ? 'book' : 'stationery')
  const cover = cleanImageUrl(
    p.coverImage || p.image || p.thumbnail || (p.images && p.images[0]),
    title,
    productType,
  )
  const price = Number(p.price || 0)
  const originalPrice = p.originalPrice
  const discount =
    originalPrice && originalPrice > price
      ? Math.round(((originalPrice - price) / originalPrice) * 100)
      : 0
  const rating = p.rating || 0
  const reviewCount = p.reviewCount || 0
  const releaseDate = p.release_date || p.releaseDate

  const detailHref = isBook ? `/books/${p.id}` : `/browse?product=${p.id}`

  const addAny = (ev?: React.MouseEvent) => {
    ev?.preventDefault()
    addToCart({
      id: String(p.id),
      title,
      price,
      coverImage: cover,
      quantity: 1,
      author: author as any,
      stock: p.stock ?? 1,
      categoryId: p.categoryId,
      productType: (p as any).productType || (isBook ? 'book' : 'stationery'),
    } as any)
  }

  return (
    <div
      className={cn(
        'group relative bg-white rounded-2xl border border-cream-200 overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-primary-950/10 hover:border-primary-200',
        className,
      )}
    >
      <Link href={detailHref} className="block relative overflow-hidden">
        <div className={cn('relative bg-cream-100 overflow-hidden', unified ? 'aspect-square' : 'aspect-[2/3]')}>
          <img
            src={cover}
            alt={title}
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            onError={(e) => {
              ;(e.currentTarget as HTMLImageElement).src = cleanImageUrl('', title, productType)
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-primary-950/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

          <div className="absolute top-3 left-3 flex flex-col gap-1.5">
            {isPreorder && (
              <Badge variant="preorder" className="shadow-sm">
                PRE-ORDER
              </Badge>
            )}
            {p.isFeatured && (
              <Badge variant="accent" className="shadow-sm">
                Featured
              </Badge>
            )}
            {p.isBestseller && (
              <Badge variant="primary" className="shadow-sm">
                Bestseller
              </Badge>
            )}
            {discount > 0 && (
              <Badge variant="danger" className="shadow-sm">
                -{discount}%
              </Badge>
            )}
          </div>

          <div className="absolute bottom-3 right-3 flex flex-col gap-2 opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300">
            <Button
              variant="secondary"
              size="icon"
              className="w-9 h-9 rounded-full shadow-lg"
              onClick={(ev) => {
                ev?.preventDefault()
                ev?.stopPropagation()
                navigate(detailHref)
              }}
              aria-label="View details"
            >
              <Eye className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </Link>

      <div className="p-4 space-y-3">
        <div className="min-h-[56px]">
          <h3 className="font-serif text-base font-semibold text-primary-950 line-clamp-2 leading-tight group-hover:text-primary-700 transition-colors">
            <Link href={detailHref}>{title}</Link>
          </h3>
          {author && (
            <p className="text-sm text-primary-800/70 mt-1 truncate">{author}</p>
          )}
          {isPreorder && releaseDate && (
            <p className="text-xs text-purple-700 font-semibold mt-1 flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              Releases: {new Date(releaseDate).toLocaleDateString(undefined, { month: 'short', year: 'numeric' })}
            </p>
          )}
        </div>

        {rating > 0 && (
          <Rating value={rating} reviewCount={reviewCount} size="sm" />
        )}

        <div className="flex items-end justify-between pt-1">
          <div className="flex items-baseline gap-1.5">
            <span className="font-serif text-lg font-bold text-primary-800">
              {formatCurrency(price)}
            </span>
            {originalPrice && originalPrice > price && (
              <span className="text-sm text-primary-800/50 line-through">
                {formatCurrency(originalPrice)}
              </span>
            )}
          </div>
          <Button
            variant={isPreorder ? 'accent' : 'primary'}
            size="sm"
            className="gap-1.5 rounded-full h-9 px-3"
            onClick={addAny}
          >
            {isPreorder ? (
              <span className="text-xs font-bold">Pre-Order Now</span>
            ) : (
              <>
                <ShoppingCart className="w-3.5 h-3.5" />
                <span className="text-xs">Add</span>
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  )
}
