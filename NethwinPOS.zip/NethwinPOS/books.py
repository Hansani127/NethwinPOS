from fastapi import APIRouter, HTTPException, Depends, Query
from typing import Optional, Any
import math
from datetime import datetime
from bson import ObjectId
from beanie.odm.operators.find.comparison import GTE, LTE, GT, LT
from beanie.odm.operators.find.evaluation import RegEx as Regex
from beanie.odm.operators.find.logical import And, Or, Nor

from app.core.security import current_superuser, current_optional_user
from app.models.book import Book, ADULT_KEYWORDS
from app.models.category import Category
from app.models.user import User
from app.schemas import BookCreate, BookUpdate, BookRead, PaginatedBooks

router = APIRouter(prefix="/books", tags=["books"])


def _adult_exclude_filter() -> Any:
    """Return a MongoDB query that excludes books whose any category_name
    contains any of the adult/erotica keywords."""
    bad_patterns = []
    for kw in ADULT_KEYWORDS:
        pat = ".*" + kw.replace(" ", ".*") + ".*"
        bad_patterns.append(Regex(Book.category_names, pat, options="i"))
    if not bad_patterns:
        return None
    return Nor(*bad_patterns)


async def _book_to_read(book: Book) -> BookRead:
    from beanie import Link as BeanieLink

    category_names = list(book.category_names or [])
    first_category_id: Optional[str] = None
    seen_names = set(category_names)

    for cat in book.categories or []:
        cat_id: Optional[str] = None
        resolved_cat: Optional[Category] = None

        if isinstance(cat, BeanieLink):
            ref = getattr(cat, "ref", None)
            if ref is not None:
                cat_id = str(ref.id) if hasattr(ref, "id") else str(ref)
                if not first_category_id:
                    first_category_id = cat_id
                try:
                    if hasattr(cat, "fetch"):
                        resolved_cat = await cat.fetch()
                    else:
                        resolved_cat = await Category.get(cat_id) if cat_id else None
                except Exception:
                    resolved_cat = None
            elif hasattr(cat, "id"):
                cat_id = str(cat.id)
                if not first_category_id:
                    first_category_id = cat_id
                if hasattr(cat, "name"):
                    try:
                        nm = cat.name
                        if nm and nm not in seen_names:
                            category_names.append(nm)
                            seen_names.add(nm)
                    except Exception:
                        pass
        elif isinstance(cat, (str, ObjectId)):
            cat_id = str(cat)
            if not first_category_id:
                first_category_id = cat_id
            try:
                resolved_cat = await Category.get(cat_id)
            except Exception:
                resolved_cat = None
        else:
            try:
                cat_id = str(getattr(cat, "id", "")) or None
            except Exception:
                cat_id = None
            if cat_id and not first_category_id:
                first_category_id = cat_id
            nm = getattr(cat, "name", None)
            if nm and nm not in seen_names:
                category_names.append(nm)
                seen_names.add(nm)

        if resolved_cat is not None:
            nm = getattr(resolved_cat, "name", None)
            if nm and nm not in seen_names:
                category_names.append(nm)
                seen_names.add(nm)
            if not first_category_id and getattr(resolved_cat, "id", None):
                first_category_id = str(resolved_cat.id)

    author_str = book.authors[0] if book.authors else ""
    return BookRead(
        id=str(book.id),
        title=book.title,
        subtitle=book.subtitle,
        isbn13=book.isbn13,
        isbn10=book.isbn10,
        authors=book.authors,
        category_names=category_names,
        description=book.description,
        published_year=book.published_year,
        num_pages=book.num_pages,
        average_rating=book.average_rating,
        ratings_count=book.ratings_count,
        price=book.price,
        stock=book.stock,
        thumbnail=book.thumbnail,
        images=book.images,
        is_featured=book.is_featured,
        is_active=book.is_active,
        is_preorder=book.is_preorder,
        preorder_release_date=book.preorder_release_date,
        created_at=book.created_at,
        updated_at=book.updated_at,
        author=author_str,
        coverImage=book.thumbnail,
        rating=book.average_rating,
        reviewCount=book.ratings_count,
        pages=book.num_pages,
        isbn=book.isbn13,
        slug=book.isbn13 or str(book.id),
        categoryId=first_category_id or None,
        productType="book",
    )


@router.get("", response_model=PaginatedBooks)
async def list_books(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    search: Optional[str] = None,
    category: Optional[str] = None,
    min_price: Optional[float] = None,
    max_price: Optional[float] = None,
    featured: Optional[bool] = None,
    active: Optional[bool] = True,
    include_adult: bool = Query(False, description="If true, also include adult/erotica books"),
    _: Optional[User] = Depends(current_optional_user),
):
    query_filters = []

    if active is not None:
        query_filters.append(Book.is_active == active)
    if featured is not None:
        query_filters.append(Book.is_featured == featured)
    if min_price is not None:
        query_filters.append(GTE(Book.price, min_price))
    if max_price is not None:
        query_filters.append(LTE(Book.price, max_price))
    if search:
        escaped = search.replace("\\", "\\\\").replace(".", "\\.")
        search_q = Or(
            Regex(Book.title, escaped, options="i"),
            Regex(Book.authors, escaped, options="i"),
            Regex(Book.isbn13, escaped, options="i"),
            Regex(Book.isbn10, escaped, options="i"),
        )
        query_filters.append(search_q)
    if category:
        cat = await Category.find_one(Category.slug == category)
        if cat:
            query_filters.append(Book.categories == ObjectId(cat.id))
        else:
            # Allow matching by category name via category_names regex
            query_filters.append(
                Regex(Book.category_names, "^" + category.replace("-", ".*") + ".*$", options="i")
            )
    if not include_adult:
        af = _adult_exclude_filter()
        if af is not None:
            query_filters.append(af)

    find_query = And(*query_filters) if query_filters else {}

    total = await Book.find(find_query).count()
    total_pages = max(1, math.ceil(total / page_size))
    skip = (page - 1) * page_size

    books = await Book.find(find_query).sort(-Book.created_at).skip(skip).limit(page_size).to_list()
    items = [await _book_to_read(b) for b in books]

    return PaginatedBooks(
        total=total,
        page=page,
        page_size=page_size,
        pages=total_pages,
        items=items,
        data=items,
        limit=page_size,
        totalPages=total_pages,
    )


@router.get("/slug/{slug}", response_model=BookRead)
async def get_book_by_slug(slug: str):
    book = await Book.find_one(Book.slug == slug) if hasattr(Book, "slug") else None
    if not book:
        book = await Book.find_one(Book.isbn13 == slug)
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    return await _book_to_read(book)


@router.get("/{book_id}", response_model=BookRead)
async def get_book(book_id: str):
    book = await Book.get(book_id)
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    return await _book_to_read(book)


@router.post("", response_model=BookRead)
async def create_book(
    data: BookCreate,
    _: User = Depends(current_superuser),
):
    existing = None
    if data.isbn13:
        existing = await Book.find_one(Book.isbn13 == data.isbn13)
    if existing:
        raise HTTPException(status_code=400, detail="Book with this ISBN already exists")

    category_refs = []
    category_names = []
    for cat_ident in data.categories:
        cat = await Category.find_one(Or(Category.slug == cat_ident, Category.name == cat_ident))
        if cat:
            category_refs.append(cat)
            category_names.append(cat.name)
        else:
            category_names.append(cat_ident)

    book = Book(
        title=data.title,
        subtitle=data.subtitle,
        isbn13=data.isbn13,
        isbn10=data.isbn10,
        authors=data.authors,
        categories=category_refs,
        category_names=category_names,
        description=data.description,
        published_year=data.published_year,
        num_pages=data.num_pages,
        average_rating=data.average_rating,
        ratings_count=data.ratings_count,
        price=data.price,
        stock=data.stock,
        thumbnail=data.thumbnail,
        images=data.images,
        is_featured=data.is_featured,
        is_active=data.is_active,
    )
    await book.insert()
    return await _book_to_read(book)


@router.patch("/{book_id}", response_model=BookRead)
async def update_book(
    book_id: str,
    data: BookUpdate,
    _: User = Depends(current_superuser),
):
    book = await Book.get(book_id)
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")

    update_data = data.model_dump(exclude_unset=True)

    if "categories" in update_data:
        cat_idents = update_data.pop("categories")
        category_refs = []
        category_names = []
        for cat_ident in cat_idents:
            cat = await Category.find_one(Or(Category.slug == cat_ident, Category.name == cat_ident))
            if cat:
                category_refs.append(cat)
                category_names.append(cat.name)
            else:
                category_names.append(cat_ident)
        book.categories = category_refs
        book.category_names = category_names

    for key, value in update_data.items():
        setattr(book, key, value)

    book.updated_at = datetime.utcnow()
    await book.save()
    return await _book_to_read(book)


@router.delete("/{book_id}")
async def delete_book(
    book_id: str,
    _: User = Depends(current_superuser),
):
    book = await Book.get(book_id)
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    book.is_active = False
    book.updated_at = datetime.utcnow()
    await book.save()
    return {"detail": "Book deleted successfully"}
