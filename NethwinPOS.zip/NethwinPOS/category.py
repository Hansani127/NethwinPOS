from beanie import Document, Indexed, Link, BackLink
from datetime import datetime
from typing import Optional, List, ForwardRef
from pydantic import Field

Category = ForwardRef("Category")


class Category(Document):
    name: str
    slug: Indexed(str, unique=True)
    description: Optional[str] = None
    parent_category: Optional[Link["Category"]] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)

    class Settings:
        name = "categories"
