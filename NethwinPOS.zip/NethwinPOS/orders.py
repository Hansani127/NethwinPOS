from fastapi import APIRouter, HTTPException, Depends, Query
from typing import Optional
import math
from datetime import datetime
from decimal import Decimal
from bson import ObjectId

from app.core.security import current_user, current_superuser
from app.models.user import User
from app.models.cart import Cart, CartItem
from app.models.book import Book
from app.models.stationery import Stationery
from app.models.ledger import PointsTransaction, TransactionType
from app.models.order import (
    Order,
    OrderItem,
    OrderStatus,
    PaymentStatus,
    ShippingAddress,
)
from app.services import (
    generate_order_number,
    calculate_totals,
    tier_from_spent,
    points_earned_for,
    discount_from_points,
    max_points_for_order,
    send_order_confirmation,
)
from app.schemas import (
    OrderCreate,
    OrderRead,
    OrderUpdateStatus,
    PaginatedOrders,
    OrderItemRead,
    OrderItemCreate,
    ShippingAddressBase,
)

router = APIRouter(prefix="/orders", tags=["orders"])


def _order_to_read(order: Order) -> OrderRead:
    items = [
        OrderItemRead(
            product_type=getattr(item, "product_type", "book"),
            title=item.title,
            isbn=item.isbn,
            sku=getattr(item, "sku", None),
            quantity=item.quantity,
            unit_price=item.unit_price,
            subtotal=item.subtotal,
        )
        for item in order.items
    ]
    addr = None
    if order.shipping_address:
        addr = ShippingAddressBase(
            name=order.shipping_address.name,
            line1=order.shipping_address.line1,
            line2=order.shipping_address.line2,
            city=order.shipping_address.city,
            state=order.shipping_address.state,
            postal_code=order.shipping_address.postal_code,
            country=order.shipping_address.country,
            phone=order.shipping_address.phone,
        )
    user_id_str = None
    if order.user_id:
        if hasattr(order.user_id, "id"):
            user_id_str = str(order.user_id.id)
        else:
            user_id_str = str(order.user_id)
    return OrderRead(
        id=str(order.id),
        order_number=order.order_number,
        items=items,
        subtotal=order.subtotal,
        tax=order.tax,
        shipping=order.shipping,
        redeem_points_applied=order.redeem_points_applied,
        points_discount=order.points_discount,
        points_earned=order.points_earned,
        total=order.total,
        status=order.status,
        shipping_address=addr,
        payment_status=order.payment_status,
        tracking_number=order.tracking_number,
        notes=order.notes,
        source=getattr(order, "source", "web"),
        created_at=order.created_at,
        updated_at=order.updated_at,
        paid_at=order.paid_at,
        shipped_at=order.shipped_at,
        delivered_at=order.delivered_at,
        paymentMethod="stripe",
        userId=user_id_str,
        address=addr,
    )


@router.get("", response_model=PaginatedOrders)
async def list_my_orders(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    status: Optional[OrderStatus] = None,
    user: User = Depends(current_user),
):
    query_filters = [Order.user_id == ObjectId(user.id)]
    if status:
        query_filters.append(Order.status == status)

    total = await Order.find(*query_filters).count()
    total_pages = max(1, math.ceil(total / page_size))
    skip = (page - 1) * page_size
    orders = await Order.find(*query_filters).sort(-Order.created_at).skip(skip).limit(page_size).to_list()
    items = [_order_to_read(o) for o in orders]

    return PaginatedOrders(
        total=total,
        page=page,
        page_size=page_size,
        pages=total_pages,
        items=items,
        data=items,
        limit=page_size,
        totalPages=total_pages,
    )


@router.get("/admin/all", response_model=PaginatedOrders)
async def list_all_orders(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    status: Optional[OrderStatus] = None,
    _: User = Depends(current_superuser),
):
    query_filters = []
    if status:
        query_filters.append(Order.status == status)

    total = await Order.find(*query_filters).count()
    total_pages = max(1, math.ceil(total / page_size))
    skip = (page - 1) * page_size
    orders = await Order.find(*query_filters).sort(-Order.created_at).skip(skip).limit(page_size).to_list()
    items = [_order_to_read(o) for o in orders]

    return PaginatedOrders(
        total=total,
        page=page,
        page_size=page_size,
        pages=total_pages,
        items=items,
        data=items,
        limit=page_size,
        totalPages=total_pages,
    )


@router.get("/{order_id}", response_model=OrderRead)
async def get_order(order_id: str, user: User = Depends(current_user)):
    order = await Order.get(order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    user_oid = ObjectId(user.id)
    order_user_oid = None
    if order.user_id:
        if hasattr(order.user_id, "id"):
            order_user_oid = ObjectId(str(order.user_id.id))
        else:
            order_user_oid = ObjectId(str(order.user_id))
    if order_user_oid != user_oid and not user.is_superuser:
        raise HTTPException(status_code=403, detail="Forbidden")

    return _order_to_read(order)


async def deduct_stock_for_order(order: Order):
    for item in order.items:
        if getattr(item, "product_type", "book") == "stationery" and item.stationery_id:
            s_oid = ObjectId(str(item.stationery_id.id)) if hasattr(item.stationery_id, "id") else ObjectId(str(item.stationery_id))
            s = await Stationery.get(str(s_oid))
            if s and not s.is_preorder:
                s.stock = max(0, s.stock - item.quantity)
                s.updated_at = datetime.utcnow()
                await s.save()
        elif item.book_id:
            book_oid = ObjectId(str(item.book_id.id)) if hasattr(item.book_id, "id") else ObjectId(str(item.book_id))
            b = await Book.get(str(book_oid))
            if b and not b.is_preorder:
                b.stock = max(0, b.stock - item.quantity)
                b.updated_at = datetime.utcnow()
                await b.save()


async def award_loyalty_for_order(order: Order):
    user_oid = None
    if order.user_id:
        if hasattr(order.user_id, "id"):
            user_oid = ObjectId(str(order.user_id.id))
        else:
            user_oid = ObjectId(str(order.user_id))
    if user_oid is None:
        return
    u = await User.get(str(user_oid))
    if not u:
        return
    tier = tier_from_spent(u.total_spent)
    earned = points_earned_for(order.total, tier)
    if earned > 0:
        u.loyalty_points += earned
        u.points_earned_total += earned
    u.total_spent = (u.total_spent + order.total).quantize(Decimal("0.01"))
    new_tier = tier_from_spent(u.total_spent)
    u.membership_tier = new_tier
    await u.save()
    order.points_earned = earned
    await order.save()
    if earned > 0:
        tx = PointsTransaction(
            user_id=user_oid,
            type=TransactionType.EARN,
            points=earned,
            balance_after=u.loyalty_points,
            source=f"order:{order.order_number}",
            description=f"Points earned from order {order.order_number}",
        )
        await tx.insert()


@router.post("", response_model=OrderRead)
async def create_order(data: OrderCreate, user: User = Depends(current_user)):
    order_items = []

    if data.items and len(data.items) > 0:
        for item in data.items:
            if item.product_type == "stationery":
                st = await Stationery.get(item.product_id)
                if not st:
                    raise HTTPException(status_code=404, detail=f"Stationery not found: {item.product_id}")
                if not st.is_active:
                    raise HTTPException(status_code=400, detail=f"Stationery not available: {st.name}")
                if item.quantity > st.stock and not st.is_preorder:
                    raise HTTPException(status_code=400, detail=f"Insufficient stock for {st.name}")
                unit_price = item.price_at_time if item.price_at_time else st.price
                subtotal = (unit_price * item.quantity).quantize(Decimal("0.01"))
                order_items.append(OrderItem(
                    stationery_id=ObjectId(item.product_id),
                    product_type="stationery",
                    title=st.name,
                    isbn=None,
                    sku=st.sku,
                    quantity=item.quantity,
                    unit_price=unit_price,
                    subtotal=subtotal,
                ))
            else:
                book = await Book.get(item.product_id)
                if not book:
                    raise HTTPException(status_code=404, detail=f"Book not found: {item.product_id}")
                if not book.is_active:
                    raise HTTPException(status_code=400, detail=f"Book not available: {book.title}")
                if item.quantity > book.stock and not book.is_preorder:
                    raise HTTPException(status_code=400, detail=f"Insufficient stock for {book.title}")
                unit_price = item.price_at_time if item.price_at_time else book.price
                subtotal = (unit_price * item.quantity).quantize(Decimal("0.01"))
                order_items.append(OrderItem(
                    book_id=ObjectId(item.product_id),
                    product_type="book",
                    title=book.title,
                    isbn=book.isbn13,
                    sku=None,
                    quantity=item.quantity,
                    unit_price=unit_price,
                    subtotal=subtotal,
                ))
    else:
        cart = await Cart.find_one(Cart.user_id == ObjectId(user.id))
        if not cart or not cart.items:
            raise HTTPException(status_code=400, detail="Cart is empty")

        for item in cart.items:
            book_id = str(item.book_id.id) if hasattr(item.book_id, "id") else str(item.book_id)
            book = await Book.get(book_id)
            if not book:
                continue
            if item.quantity > book.stock and not book.is_preorder:
                raise HTTPException(status_code=400, detail=f"Insufficient stock for {book.title}")
            subtotal = (item.price_at_time * item.quantity).quantize(Decimal("0.01"))
            order_items.append(OrderItem(
                book_id=ObjectId(book_id),
                product_type="book",
                title=book.title,
                isbn=book.isbn13,
                sku=None,
                quantity=item.quantity,
                unit_price=item.price_at_time,
                subtotal=subtotal,
            ))

    if not order_items:
        raise HTTPException(status_code=400, detail="No valid items to order")

    totals = calculate_totals(order_items)
    subtotal_pre = totals["subtotal"]

    points_applied = 0
    points_discount = Decimal("0")
    if data.redeem_points and data.redeem_points > 0:
        max_allowed = max_points_for_order(subtotal_pre)
        points_applied = min(data.redeem_points, user.loyalty_points, max_allowed)
        if points_applied > 0:
            points_discount = discount_from_points(points_applied)

    discounted_subtotal = (subtotal_pre - points_discount).quantize(Decimal("0.01"))
    if discounted_subtotal < Decimal("0"):
        discounted_subtotal = Decimal("0")
    tax = totals["tax"]
    shipping = totals["shipping"]
    total = (discounted_subtotal + tax + shipping).quantize(Decimal("0.01"))
    if total <= Decimal("0"):
        total = Decimal("0.01")

    shipping_addr = None
    if data.shipping_address:
        shipping_addr = ShippingAddress(
            name=data.shipping_address.name,
            line1=data.shipping_address.line1,
            line2=data.shipping_address.line2,
            city=data.shipping_address.city,
            state=data.shipping_address.state,
            postal_code=data.shipping_address.postal_code,
            country=data.shipping_address.country,
            phone=data.shipping_address.phone,
        )

    order = Order(
        user_id=ObjectId(user.id),
        order_number=generate_order_number(),
        items=order_items,
        subtotal=subtotal_pre,
        tax=tax,
        shipping=shipping,
        redeem_points_applied=points_applied,
        points_discount=points_discount,
        points_earned=0,
        total=total,
        status=OrderStatus.PENDING,
        shipping_address=shipping_addr,
        payment_status=PaymentStatus.UNPAID,
        notes=data.notes,
        source="web",
    )
    await order.insert()

    if points_applied > 0:
        user.loyalty_points = max(0, user.loyalty_points - points_applied)
        user.points_redeemed_total += points_applied
        await user.save()
        tx = PointsTransaction(
            user_id=ObjectId(user.id),
            type=TransactionType.REDEEM,
            points=-points_applied,
            balance_after=user.loyalty_points,
            source=f"order:{order.order_number}",
            description=f"Points redeemed on order {order.order_number}",
        )
        await tx.insert()

    cart = await Cart.find_one(Cart.user_id == ObjectId(user.id))
    if cart and len(cart.items) > 0:
        cart.items = []
        cart.updated_at = datetime.utcnow()
        await cart.save()

    return _order_to_read(order)


@router.patch("/{order_id}/status", response_model=OrderRead)
async def update_order_status(
    order_id: str,
    data: OrderUpdateStatus,
    _: User = Depends(current_superuser),
):
    order = await Order.get(order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    was_paid = order.payment_status == PaymentStatus.PAID or order.status == OrderStatus.PAID
    order.status = data.status
    if data.tracking_number:
        order.tracking_number = data.tracking_number

    now = datetime.utcnow()
    if data.status == OrderStatus.PAID and order.paid_at is None:
        order.paid_at = now
    if data.status == OrderStatus.SHIPPED and order.shipped_at is None:
        order.shipped_at = now
    if data.status == OrderStatus.DELIVERED and order.delivered_at is None:
        order.delivered_at = now

    order.updated_at = now
    await order.save()

    if (data.status == OrderStatus.PAID) and not was_paid:
        order.payment_status = PaymentStatus.PAID
        await order.save()
        await deduct_stock_for_order(order)
        await award_loyalty_for_order(order)
        await send_order_confirmation(order)

    return _order_to_read(order)
