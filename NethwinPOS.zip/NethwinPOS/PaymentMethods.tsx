import type { PosPaymentMethod } from '../../types'
import { cn } from '../../utils/cn'
import { Banknote, CreditCard, Coins } from 'lucide-react'

interface PaymentMethodsProps {
  selected: PosPaymentMethod | null
  onChange: (m: PosPaymentMethod) => void
  disabled?: boolean
  pointsAvailable?: number
}

export default function PaymentMethods({ selected, onChange, disabled, pointsAvailable = 0 }: PaymentMethodsProps) {
  const methods: { key: PosPaymentMethod; label: string; icon: React.ReactNode; variant: string; disabled?: boolean }[] = [
    {
      key: 'cash',
      label: 'Cash',
      icon: <Banknote className="w-5 h-5" />,
      variant: 'emerald',
    },
    {
      key: 'card',
      label: 'Card',
      icon: <CreditCard className="w-5 h-5" />,
      variant: 'primary',
    },
    {
      key: 'points',
      label: 'Points',
      icon: <Coins className="w-5 h-5" />,
      variant: 'accent',
      disabled: pointsAvailable < 100,
    },
  ]

  const variantStyles: Record<string, { selected: string; hover: string; text: string }> = {
    emerald: {
      selected: 'border-emerald-500 bg-emerald-50 text-emerald-800 ring-2 ring-emerald-500/20',
      hover: 'hover:border-emerald-300 hover:text-emerald-700',
      text: 'text-emerald-700',
    },
    primary: {
      selected: 'border-primary-600 bg-primary-50 text-primary-800 ring-2 ring-primary-500/20',
      hover: 'hover:border-primary-300 hover:text-primary-700',
      text: 'text-primary-700',
    },
    accent: {
      selected: 'border-accent-500 bg-accent-50 text-accent-800 ring-2 ring-accent-500/20',
      hover: 'hover:border-accent-300 hover:text-accent-700',
      text: 'text-accent-700',
    },
  }

  return (
    <div className="grid grid-cols-3 gap-2">
      {methods.map((m) => {
        const vs = variantStyles[m.variant]
        const isDisabled = disabled || m.disabled
        return (
          <button
            key={m.key}
            onClick={() => !isDisabled && onChange(m.key)}
            disabled={isDisabled}
            className={cn(
              'flex flex-col items-center justify-center gap-1.5 h-16 rounded-xl border-2 transition-all',
              'disabled:opacity-40 disabled:cursor-not-allowed',
              selected === m.key
                ? vs.selected
                : `border-cream-200 bg-white text-primary-700 ${vs.hover}`,
            )}
          >
            <span className={selected === m.key ? vs.text : ''}>{m.icon}</span>
            <span className="text-xs font-bold uppercase tracking-wide">{m.label}</span>
          </button>
        )
      })}
    </div>
  )
}
