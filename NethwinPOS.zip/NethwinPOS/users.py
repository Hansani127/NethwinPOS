from fastapi import APIRouter, HTTPException, Depends, Query
from typing import Optional
import math

from app.core.security import current_user, current_superuser, user_to_response
from app.models.user import User
from app.schemas import UserProfileUpdate, UserRoleUpdate

router = APIRouter(prefix="/users", tags=["users"])


# ── Fixed-path routes MUST come before /{user_id} ────────────────────────────

@router.get("/me")
async def get_me(user: User = Depends(current_user)):
    return user_to_response(user)


@router.patch("/me")
async def update_me(
    data: UserProfileUpdate,
    user: User = Depends(current_user),
):
    update_data = data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(user, key, value)
    await user.save()
    return user_to_response(user)


@router.get("/staff")
async def list_staff(
    _: User = Depends(current_superuser),
):
    """List all manager and cashier accounts."""
    from beanie.odm.operators.find.comparison import In
    staff = await User.find(In(User.staff_role, ["manager", "cashier"])).to_list()
    return [user_to_response(u) for u in staff]


@router.post("/create-staff")
async def create_staff_account(
    data: dict,
    _: User = Depends(current_superuser),
    user_manager=Depends(__import__('app.core.security', fromlist=['get_user_manager']).get_user_manager),
):
    """Admin creates a manager or cashier account."""
    from app.core.security import UserCreate

    role = data.get("staff_role")
    if role not in ("manager", "cashier"):
        raise HTTPException(status_code=400, detail="staff_role must be 'manager' or 'cashier'")

    name = data.get("name", "")
    parts = name.split(" ", 1)
    first_name = parts[0] if parts else ""
    last_name = parts[1] if len(parts) > 1 else None

    existing = await User.find_one(User.email == data["email"])
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    user_create = UserCreate(
        email=data["email"],
        password=data["password"],
        first_name=first_name,
        last_name=last_name,
        is_active=True,
        is_superuser=False,
        is_verified=True,
    )
    user = await user_manager.create(user_create, safe=True)
    user.staff_role = role
    await user.save()
    return user_to_response(user)


@router.get("")
async def list_users(
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    search: Optional[str] = None,
    _: User = Depends(current_superuser),
):
    query_filters = []
    if search:
        from beanie.odm.operators.find.evaluation import RegEx as Regex
        from beanie.odm.operators.find.logical import Or
        escaped = search.replace("\\", "\\\\").replace(".", "\\.")
        query_filters.append(Or(
            Regex(User.email, escaped, options="i"),
            Regex(User.first_name, escaped, options="i"),
            Regex(User.last_name, escaped, options="i"),
        ))

    total = await User.find(*query_filters).count()
    total_pages = max(1, math.ceil(total / page_size))
    skip = (page - 1) * page_size
    users = await User.find(*query_filters).skip(skip).limit(page_size).to_list()
    items = [user_to_response(u) for u in users]

    return {
        "total": total,
        "page": page,
        "page_size": page_size,
        "pages": total_pages,
        "items": items,
        "data": items,
        "limit": page_size,
        "totalPages": total_pages,
    }


# ── Dynamic-path routes ───────────────────────────────────────────────────────

@router.get("/{user_id}")
async def get_user(
    user_id: str,
    _: User = Depends(current_superuser),
):
    user = await User.get(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user_to_response(user)


@router.patch("/{user_id}/role")
async def update_user_role(
    user_id: str,
    data: UserRoleUpdate,
    current: User = Depends(current_superuser),
):
    user = await User.get(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if str(user.id) == str(current.id):
        raise HTTPException(status_code=400, detail="Cannot change your own role")
    user.is_superuser = data.is_superuser
    await user.save()
    return user_to_response(user)


@router.delete("/staff/{user_id}")
async def delete_staff_account(
    user_id: str,
    current: User = Depends(current_superuser),
):
    """Admin deletes a staff account."""
    user = await User.get(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if str(user.id) == str(current.id):
        raise HTTPException(status_code=400, detail="Cannot delete your own account")
    if user.staff_role not in ("manager", "cashier"):
        raise HTTPException(status_code=400, detail="User is not a staff account")
    await user.delete()
    return {"detail": "Staff account deleted"}
