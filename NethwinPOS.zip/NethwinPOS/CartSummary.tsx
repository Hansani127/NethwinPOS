import { Link } from '../../utils/router-compat'
import { formatCurrency } from '../../utils/formatCurrency'
import { useCart } from '../../hooks/useCart'
import Button from '../common/Button'
import { ArrowRight, Truck, Gift, Coins } from 'lucide-react'
import Badge from '../common/Badge'


interface CartSummaryProps {
  showCheckoutButton?: boolean
  className?: string
  pointsDiscount?: number
  redeemedPoints?: number
}

export default function CartSummary({
  showCheckoutButton = true,
  className,
  pointsDiscount = 0,
  redeemedPoints = 0,
}: CartSummaryProps) {
  const { items, subtotal, tax, shipping, totalPrice, totalItems } = useCart()
  const adjustedTotal = Math.max(0, totalPrice - pointsDiscount)
  const freeShippingThreshold = 50
  const amountToFreeShipping = Math.max(0, freeShippingThreshold - subtotal)

  return (
    <div className={`bg-white rounded-2xl border border-cream-200 shadow-sm ${className}`}>
      <div className="p-6 border-b border-cream-100">
        <h3 className="font-serif text-xl font-semibold text-primary-950">
          Order Summary
        </h3>
        <p className="text-sm text-primary-800/60 mt-1">
          {totalItems} {totalItems === 1 ? 'item' : 'items'} in your cart
        </p>
      </div>

      <div className="p-6 space-y-4">
        {amountToFreeShipping > 0 && subtotal > 0 && (
          <div className="p-3.5 rounded-xl bg-accent-50 border border-accent-200">
            <div className="flex items-start gap-2.5">
              <Truck className="w-4.5 h-4.5 text-accent-700 mt-0.5 flex-shrink-0" />
              <div className="text-sm">
                <p className="font-medium text-accent-800">
                  You're {formatCurrency(amountToFreeShipping)} away from FREE shipping!
                </p>
                <Link href="/books"
                  className="text-accent-700 underline hover:text-accent-800 font-medium mt-0.5 inline-block"
                >
                  Continue browsing
                </Link>
              </div>
            </div>
          </div>
        )}

        {shipping === 0 && subtotal > 0 && (
          <div className="flex items-center gap-2 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800">
            <Gift className="w-4 h-4 flex-shrink-0" />
            <Badge variant="success" size="sm">
              Congrats!
            </Badge>
            <span className="text-sm font-medium">You qualify for free shipping</span>
          </div>
        )}

        <div className="space-y-3 text-sm">
          <div className="flex justify-between items-center text-primary-800/80">
            <span>Subtotal</span>
            <span className="font-medium text-primary-900 tabular-nums">
              {formatCurrency(subtotal)}
            </span>
          </div>
          <div className="flex justify-between items-center text-primary-800/80">
            <span>Tax (8%)</span>
            <span className="font-medium text-primary-900 tabular-nums">
              {formatCurrency(tax)}
            </span>
          </div>
          <div className="flex justify-between items-center text-primary-800/80">
            <span>Shipping</span>
            <span
              className={`font-medium tabular-nums ${
                shipping === 0 ? 'text-emerald-700' : 'text-primary-900'
              }`}
            >
              {shipping === 0 ? 'FREE' : formatCurrency(shipping)}
            </span>
          </div>
          {pointsDiscount > 0 && (
            <div className="flex justify-between items-center text-accent-700">
              <span className="flex items-center gap-1.5 font-medium">
                <Coins className="w-3.5 h-3.5" />
                Points ({redeemedPoints.toLocaleString()} pts)
              </span>
              <span className="font-bold tabular-nums">
                -{formatCurrency(pointsDiscount)}
              </span>
            </div>
          )}
        </div>

        <div className="pt-4 border-t border-cream-200">
          <div className="flex justify-between items-end">
            <div>
              <p className="text-xs uppercase tracking-wider text-primary-800/60 font-semibold">
                Total
              </p>
              <p className="text-xs text-primary-800/60 mt-0.5">
                including taxes & shipping
              </p>
            </div>
            <div className="text-right">
              {pointsDiscount > 0 && (
                <p className="text-xs text-primary-800/50 line-through tabular-nums mb-0.5">
                  {formatCurrency(totalPrice)}
                </p>
              )}
              <span className="font-serif text-3xl font-bold text-primary-800 tabular-nums">
                {formatCurrency(adjustedTotal)}
              </span>
            </div>
          </div>
        </div>

        {showCheckoutButton && items.length > 0 && (
          <Button
            asChild
            variant="accent"
            size="lg"
            className="w-full gap-2 rounded-xl"
          >
            <Link href="/checkout">
              Proceed to Checkout
              <ArrowRight className="w-4.5 h-4.5" />
            </Link>
          </Button>
        )}
      </div>
    </div>
  )
}
