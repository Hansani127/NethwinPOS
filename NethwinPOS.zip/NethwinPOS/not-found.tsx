"use client";

import { Link } from '../utils/router-compat'

import { BookOpen, Home, Search, ArrowRight } from 'lucide-react'
import Button from '../components/common/Button'

export default function NotFound() {
  return (
    <div className="bg-cream-100 min-h-[calc(100vh-5rem)] flex items-center justify-center relative overflow-hidden">
      <div
        className="absolute inset-0 opacity-40"
        style={{
          backgroundImage:
            'radial-gradient(circle at 15% 20%, rgba(99, 102, 241, 0.12) 0, transparent 40%), radial-gradient(circle at 85% 75%, rgba(251, 191, 36, 0.14) 0, transparent 40%)',
        }}
      />
      <div className="relative max-w-3xl w-full px-6 py-20 text-center">
        <div className="inline-flex items-center justify-center mb-10">
          <div className="w-28 h-28 relative flex items-center justify-center">
            <div className="absolute inset-0 bg-gradient-to-br from-primary-700 via-primary-600 to-primary-500 rounded-[2rem] rotate-[-6deg] shadow-xl shadow-primary-700/30" />
            <div className="absolute inset-0 bg-gradient-to-br from-accent-400 via-accent-500 to-accent-600 rounded-[2rem] rotate-[5deg] opacity-70 mix-blend-multiply" />
            <div className="relative text-white font-serif text-5xl font-bold tracking-tight">
              4<span className="text-accent-300">0</span>4
            </div>
          </div>
        </div>

        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-primary-50 border border-primary-100 text-primary-700 text-xs font-semibold uppercase tracking-wider mb-5">
          <BookOpen className="w-3.5 h-3.5" />
          Page Not Found
        </div>

        <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-semibold tracking-tight text-primary-950 mb-5 leading-tight">
          This chapter is <span className="italic text-primary-700">missing</span>.
        </h1>
        <p className="text-lg text-primary-800/75 max-w-xl mx-auto mb-10 leading-relaxed">
          The page you're looking for doesn't exist, has moved, or perhaps it's still being written. Let's get you back to the beginning of the story.
        </p>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-3 sm:gap-4">
          <Button
            asChild
            variant="accent"
            size="lg"
            className="gap-2 rounded-xl"
          >
            <Link href="/">
              <Home className="w-4.5 h-4.5" />
              Back to Home
            </Link>
          </Button>
          <Button
            asChild
            variant="outline"
            size="lg"
            className="gap-2 rounded-xl"
          >
            <Link href="/books">
              <Search className="w-4.5 h-4.5" />
              Browse Books
              <ArrowRight className="w-4 h-4" />
            </Link>
          </Button>
        </div>

        <div className="mt-14 pt-10 border-t border-cream-200">
          <p className="text-sm font-semibold uppercase tracking-wider text-primary-800/50 mb-4">
            Popular reads instead
          </p>
          <div className="flex flex-wrap justify-center gap-2">
            {['Fiction', 'Romance', 'Mystery', 'Sci-Fi', 'Classics', 'Poetry', 'Non-Fiction'].map((c) => (
              <Link
                key={c}
                to={`/books?category=${c.toLowerCase()}`}
                className="px-4 py-2 rounded-full bg-white border border-cream-200 text-sm font-medium text-primary-800 hover:bg-primary-50 hover:border-primary-200 hover:text-primary-900 transition-colors"
              >
                {c}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
