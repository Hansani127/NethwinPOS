from beanie import Document, Link
from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field
from decimal import Decimal

from app.models.user import User
from app.models.book import Book


class CartItem(BaseModel):
    book_id: Link[Book]
    quantity: int = Field(ge=1, default=1)
    price_at_time: Decimal = Field(gt=0, max_digits=10, decimal_places=2)


class Cart(Document):
    user_id: Link[User]
    items: List[CartItem] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    class Settings:
        name = "carts"
