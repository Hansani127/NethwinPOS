import { Quote, Star, UserCircle } from 'lucide-react'
import Badge from '../common/Badge'

const testimonials = [
  {
    name: 'Victoria Ashford',
    location: 'New York, NY',
    rating: 5,
    text: 'Nethwin has become my absolute favorite bookshop. The curation is impeccable, every recommendation has been a joy, and the editions themselves are beautiful objects worth treasuring.',
    title: 'Loyal Collector',
  },
  {
    name: 'Dr. Samuel Reeves',
    location: 'Boston, MA',
    rating: 5,
    text: 'The rare and collectible section is a treasure. I found a signed first edition I had been hunting for years. Packaging was extraordinary, shipping swift.',
    title: 'First Edition Hunter',
  },
  {
    name: 'Isabella Moreau',
    location: 'Paris, FR',
    rating: 5,
    text: 'The editor picks feel personal, like a friend who knows exactly what you need. Beautiful site, even more beautiful books. An experience every time.',
    title: 'Avid Reader',
  },
]

export default function TestimonialSection() {
  return (
    <section className="py-20 sm:py-24 bg-primary-950 relative overflow-hidden">
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage:
            'radial-gradient(circle at 80% 20%, rgba(251, 191, 36, 0.2) 0, transparent 45%), radial-gradient(circle at 10% 80%, rgba(99, 102, 241, 0.3) 0, transparent 40%)',
        }}
      />
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-14 max-w-2xl mx-auto">
          <Badge variant="accent" size="md" className="mb-5 uppercase tracking-wider">
            What Readers Say
          </Badge>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-white">
            Loved by <span className="italic text-accent-400">thousands</span> worldwide
          </h2>
          <p className="mt-4 text-cream-200/80 leading-relaxed">
            From casual readers to lifelong collectors, here are some voices from our community.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <figure
              key={i}
              className="relative bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-7 sm:p-8 transition-all duration-300 hover:bg-white/[0.08] hover:border-accent-400/30 hover:-translate-y-0.5"
            >
              <Quote className="absolute top-6 right-6 w-8 h-8 text-accent-400/30" />

              <div className="flex items-center gap-0.5 mb-5">
                {Array.from({ length: t.rating }).map((_, j) => (
                  <Star key={j} className="w-4 h-4 text-accent-400 fill-accent-400" />
                ))}
              </div>

              <blockquote className="text-cream-100/90 leading-relaxed mb-7 min-h-[7.5rem]">
                &ldquo;{t.text}&rdquo;
              </blockquote>

              <figcaption className="flex items-center gap-4 pt-5 border-t border-white/10">
                <div className="w-12 h-12 rounded-full bg-primary-900 border border-white/10 flex items-center justify-center text-cream-200">
                  <UserCircle className="w-7 h-7" />
                </div>
                <div>
                  <div className="font-semibold text-white">{t.name}</div>
                  <div className="text-sm text-cream-200/60">
                    {t.location} &middot; <span className="text-accent-400">{t.title}</span>
                  </div>
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  )
}
